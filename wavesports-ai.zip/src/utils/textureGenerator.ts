import * as THREE from 'three';

export class TextureGenerator {
  /**
   * Pacific Blue Tartan Track Texture for Skatbaen / Klemonserrat
   */
  public static createBlueTrackTexture(): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = 1024;
    canvas.height = 1024;
    const ctx = canvas.getContext('2d')!;

    // Blue track base
    ctx.fillStyle = '#0f4c81';
    ctx.fillRect(0, 0, 1024, 1024);

    // Rubber noise texture
    for (let i = 0; i < 60000; i++) {
      const x = Math.random() * 1024;
      const y = Math.random() * 1024;
      const val = Math.random() * 40 - 20;
      ctx.fillStyle = `rgba(${15 + val}, ${76 + val}, ${129 + val}, 0.15)`;
      ctx.fillRect(x, y, 2, 2);
    }

    // White lane markings
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 8;
    for (let l = 0; l <= 8; l++) {
      const y = (l / 8) * 1024;
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(1024, y);
      ctx.stroke();
    }

    const texture = new THREE.CanvasTexture(canvas);
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    return texture;
  }

  /**
   * Long Jump Sand Pit Texture
   */
  public static createSandTexture(): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 512;
    const ctx = canvas.getContext('2d')!;

    // Golden sand base
    ctx.fillStyle = '#d4b483';
    ctx.fillRect(0, 0, 512, 512);

    // Sand grain texture
    for (let i = 0; i < 30000; i++) {
      const x = Math.random() * 512;
      const y = Math.random() * 512;
      const shade = Math.floor(Math.random() * 60 - 30);
      ctx.fillStyle = `rgb(${212 + shade}, ${180 + shade}, ${131 + shade})`;
      ctx.fillRect(x, y, 1.5, 1.5);
    }

    // Raked sand ripples
    ctx.strokeStyle = 'rgba(180, 150, 100, 0.25)';
    ctx.lineWidth = 2;
    for (let y = 0; y < 512; y += 8) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.quadraticCurveTo(256, y + 3, 512, y);
      ctx.stroke();
    }

    const texture = new THREE.CanvasTexture(canvas);
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    return texture;
  }

  /**
   * Olympic Swimming Pool Tile & Grid Texture
   */
  public static createPoolTileTexture(): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = 1024;
    canvas.height = 1024;
    const ctx = canvas.getContext('2d')!;

    // Deep cyan tile background
    ctx.fillStyle = '#006699';
    ctx.fillRect(0, 0, 1024, 1024);

    // Tile grid lines
    ctx.strokeStyle = '#004466';
    ctx.lineWidth = 2;
    const tileSize = 32;
    for (let x = 0; x < 1024; x += tileSize) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, 1024);
      ctx.stroke();
    }
    for (let y = 0; y < 1024; y += tileSize) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(1024, y);
      ctx.stroke();
    }

    // Black center target lane lines (T-markers at ends)
    ctx.fillStyle = '#111111';
    for (let lane = 0; lane < 8; lane++) {
      const laneY = (lane + 0.5) * (1024 / 8);
      // Main center line
      ctx.fillRect(40, laneY - 6, 944, 12);
      // T-bar at ends
      ctx.fillRect(100, laneY - 24, 16, 48);
      ctx.fillRect(900, laneY - 24, 16, 48);
    }

    const texture = new THREE.CanvasTexture(canvas);
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    return texture;
  }

  /**
   * Water Surface Caustics / Ripple Texture
   */
  public static createWaterTexture(): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 512;
    const ctx = canvas.getContext('2d')!;

    // Semi-transparent blue water
    ctx.fillStyle = '#00aaff';
    ctx.fillRect(0, 0, 512, 512);

    // Sun caustics mesh
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.4)';
    ctx.lineWidth = 3;

    for (let i = 0; i < 40; i++) {
      const cx = Math.random() * 512;
      const cy = Math.random() * 512;
      const rad = 20 + Math.random() * 50;

      ctx.beginPath();
      ctx.arc(cx, cy, rad, 0, Math.PI * 2);
      ctx.stroke();
    }

    const texture = new THREE.CanvasTexture(canvas);
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    return texture;
  }
}
