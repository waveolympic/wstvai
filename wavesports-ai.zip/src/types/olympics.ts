export type VenueId = 'klemonserrat' | 'skatbaen' | 'vlaskovich';

export interface VenueMetadata {
  id: VenueId;
  name: string;
  zipFile: string;
  location: string;
  capacity: number;
  description: string;
  supportedEvents: EventId[];
}

export type EventId =
  // Klemonserrat Stadium (Track)
  | 'm-100m'
  | 'w-100m'
  | 'm-200m'
  | 'w-200m'
  | 'm-400m'
  | 'w-400m'
  | 'm-800m'
  | 'w-800m'
  // Skatbaen Stadium (Long Jump)
  | 'm-ljump'
  | 'w-ljump'
  // Vlaskovich Indoor Arena (Swimming)
  | 'm-100m-swim'
  | 'w-100m-swim';

export type EventDiscipline = 'sprint' | 'middle-distance' | 'long-jump' | 'swimming';

export interface Athlete {
  id: string;
  name: string;
  country: string;
  code: string;
  laneOrPosition: number;
  personalBest: string;
  seasonBest: string;
  bibNumber: number;
  primaryColor: string;
  secondaryColor: string;
}

export interface OlympicEvent {
  id: EventId;
  name: string;
  venueId: VenueId;
  venueName: string;
  discipline: EventDiscipline;
  gender: 'men' | 'women';
  distanceMeters: number;
  lapsOrAttempts: number;
  lanes: number;
  worldRecord: string;
  olympicRecord: string;
  athletes: Athlete[];
}

export interface ValidationStep {
  id: number;
  title: string;
  subsystem: string;
  description: string;
  status: 'pending' | 'running' | 'success' | 'warning' | 'error';
  diagnosticDetails?: string;
  repairApplied?: boolean;
}

export interface AIMonitorMetrics {
  gpuFps: number;
  gpuFrameTimeMs: number;
  ramUsageMb: number;
  vramUsageMb: number;
  activeVenue: string;
  activeVenueZip: string;
  dormantVenuesCount: number;
  active3DMeshCount: number;
  activeVerticesCount: number;
  textureMemoryMb: number;
  subsystemsHealth: {
    modelIntegrity: 'optimal' | 'repaired' | 'failed';
    textures: 'optimal' | 'repaired' | 'failed';
    materials: 'optimal' | 'repaired' | 'failed';
    animations: 'optimal' | 'repaired' | 'failed';
    physics: 'optimal' | 'repaired' | 'failed';
    collisions: 'optimal' | 'repaired' | 'failed';
    memoryGPU: 'optimal' | 'repaired' | 'failed';
    timing: 'optimal' | 'repaired' | 'failed';
    aiServices: 'optimal' | 'repaired' | 'failed';
  };
}

export interface TelemetryFrame {
  progressRatio: number;
  simTimeMs: number;
  phase: string;
  telemetryValue: number;
  timestampMs: number;
}

export interface HighlightClip {
  id: string;
  title: string;
  eventName: string;
  venueName: string;
  durationMs: number;
  videoBlobUrl?: string;
  snapshotDataUrl?: string;
  recordedAt: string;
  telemetryValue: number;
  unitLabel: string;
}

export interface DiagnosticLog {
  timestamp: string;
  level: 'INFO' | 'SUCCESS' | 'WARN' | 'REPAIR' | 'ERROR';
  subsystem: string;
  message: string;
  venueZip?: string;
}
