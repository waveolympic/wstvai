import * as THREE from 'three';
import { OlympicEvent, VenueId } from '../types/olympics';
import { StadiumBuilder } from '../components/3d/Stadium';
import { Track100mBuilder } from '../components/3d/Track100m';
import { ForecourtBuilder } from '../components/3d/Forecourt';
import { CitySkylineBuilder } from '../components/3d/CitySkyline';
import { TrafficBuilder } from '../components/3d/Traffic';
import { EnvironmentBuilder } from '../components/3d/Environment';
import { CrowdBuilder } from '../components/3d/Crowd';
import { SkatbaenVenueBuilder } from './skatbaen/SkatbaenVenueBuilder';
import { VlaskovichVenueBuilder } from './vlaskovich/VlaskovichVenueBuilder';

export interface CameraPreset {
  id: string;
  label: string;
  category: 'venue' | 'athletes' | 'interactive';
  description: string;
  position: THREE.Vector3;
  target: THREE.Vector3;
}

export class VenueManager {
  private scene: THREE.Scene;
  private currentVenueId: VenueId | null = null;
  private currentVenueGroup: THREE.Group | null = null;

  // Sub-builders
  private klemonserratGroup: THREE.Group | null = null;
  private track100mBuilder: Track100mBuilder | null = null;
  private forecourtBuilder: ForecourtBuilder | null = null;
  private citySkylineBuilder: CitySkylineBuilder | null = null;
  private trafficBuilder: TrafficBuilder | null = null;
  private environmentBuilder: EnvironmentBuilder | null = null;
  private crowdBuilder: CrowdBuilder | null = null;

  private skatbaenBuilder: SkatbaenVenueBuilder | null = null;
  private vlaskovichBuilder: VlaskovichVenueBuilder | null = null;

  constructor(scene: THREE.Scene) {
    this.scene = scene;
  }

  /**
   * Load the venue required for the specified Olympic Event.
   * Bypasses and unloads dormant venue assets to maximize GPU & memory performance.
   */
  public loadVenueForEvent(event: OlympicEvent): {
    venueId: VenueId;
    presets: CameraPreset[];
  } {
    const targetVenueId = event.venueId;

    if (this.currentVenueId === targetVenueId && this.currentVenueGroup) {
      // Re-spawn athletes in active venue
      this.populateAthletes(event);
      return {
        venueId: targetVenueId,
        presets: this.getCameraPresetsForVenue(targetVenueId),
      };
    }

    // Unload dormant venue from Three.js scene graph
    if (this.currentVenueGroup) {
      this.scene.remove(this.currentVenueGroup);
      this.currentVenueGroup = null;
    }

    this.currentVenueId = targetVenueId;

    if (targetVenueId === 'klemonserrat') {
      // 1. Build Klemonserrat Stadium (Track Sprints & Middle Distance)
      const group = new THREE.Group();
      group.name = 'KlemonserratVenue';

      this.environmentBuilder = new EnvironmentBuilder();
      this.environmentBuilder.setupEnvironment(this.scene);

      const stadium = StadiumBuilder.buildStadium();
      group.add(stadium);

      this.track100mBuilder = new Track100mBuilder();
      const track100m = this.track100mBuilder.build100mVenue();
      group.add(track100m);

      this.forecourtBuilder = new ForecourtBuilder();
      const forecourt = this.forecourtBuilder.buildForecourt();
      group.add(forecourt);

      this.citySkylineBuilder = new CitySkylineBuilder();
      const citySkyline = this.citySkylineBuilder.buildCitySkyline();
      group.add(citySkyline);

      this.trafficBuilder = new TrafficBuilder();
      const traffic = this.trafficBuilder.buildTraffic();
      group.add(traffic);

      this.crowdBuilder = new CrowdBuilder();
      const crowd = this.crowdBuilder.buildCrowd();
      group.add(crowd);

      this.klemonserratGroup = group;
      this.currentVenueGroup = group;
      this.scene.add(group);

    } else if (targetVenueId === 'skatbaen') {
      // 2. Build Skatbaen Stadium (Long Jump)
      this.skatbaenBuilder = new SkatbaenVenueBuilder();
      const group = this.skatbaenBuilder.getGroup();
      this.currentVenueGroup = group;
      this.scene.add(group);

    } else if (targetVenueId === 'vlaskovich') {
      // 3. Build Vlaskovich Indoor Arena (Swimming)
      this.vlaskovichBuilder = new VlaskovichVenueBuilder();
      const group = this.vlaskovichBuilder.getGroup();
      this.currentVenueGroup = group;
      this.scene.add(group);
    }

    this.populateAthletes(event);

    return {
      venueId: targetVenueId,
      presets: this.getCameraPresetsForVenue(targetVenueId),
    };
  }

  private populateAthletes(event: OlympicEvent): void {
    if (event.venueId === 'skatbaen' && this.skatbaenBuilder) {
      this.skatbaenBuilder.spawnAthletes(event.athletes);
    } else if (event.venueId === 'vlaskovich' && this.vlaskovichBuilder) {
      this.vlaskovichBuilder.spawnSwimmers(event.athletes);
    }
  }

  public updateAnimation(elapsedTime: number, delta: number, progressRatio: number, event: OlympicEvent): {
    phase: string;
    telemetryValue: number;
    activePos: THREE.Vector3;
  } {
    if (event.venueId === 'klemonserrat') {
      if (this.forecourtBuilder) this.forecourtBuilder.update(elapsedTime);
      if (this.citySkylineBuilder) this.citySkylineBuilder.update(elapsedTime);
      if (this.trafficBuilder) this.trafficBuilder.update(delta);
      if (this.environmentBuilder) this.environmentBuilder.update(delta);
      if (this.crowdBuilder) this.crowdBuilder.update(elapsedTime);

      const distance = +(progressRatio * event.distanceMeters).toFixed(1);
      const phase = progressRatio < 0.1 ? 'On Your Marks (Blocks)'
        : progressRatio < 0.25 ? 'Drive Acceleration Phase'
        : progressRatio < 0.85 ? 'Max Velocity Stride Phase'
        : 'Photofinish Torso Dip';

      return {
        phase,
        telemetryValue: distance,
        activePos: new THREE.Vector3(-50 + progressRatio * 100, 1.2, 0),
      };

    } else if (event.venueId === 'skatbaen' && this.skatbaenBuilder) {
      const animRes = this.skatbaenBuilder.updateLongJumpAnimation(progressRatio, 0);
      return {
        phase: animRes.phase,
        telemetryValue: animRes.distanceMeters,
        activePos: animRes.athletePos,
      };

    } else if (event.venueId === 'vlaskovich' && this.vlaskovichBuilder) {
      const animRes = this.vlaskovichBuilder.updateSwimmingAnimation(progressRatio, 0);
      return {
        phase: animRes.phase,
        telemetryValue: animRes.distanceMeters,
        activePos: animRes.swimmerPos,
      };
    }

    return {
      phase: 'Standby',
      telemetryValue: 0,
      activePos: new THREE.Vector3(),
    };
  }

  public getCameraPresetsForVenue(venueId: VenueId): CameraPreset[] {
    if (venueId === 'klemonserrat') {
      return [
        { id: 'track-overview', label: '100m Track Overview', category: 'venue', description: 'Broadcast angle showing full 100m straightaway', position: new THREE.Vector3(0, 32, 48), target: new THREE.Vector3(0, 1.2, 0) },
        { id: 'start-line', label: 'Start Line View', category: 'venue', description: 'Facing sprinters lined up on starting blocks', position: new THREE.Vector3(-62, 3.2, 0), target: new THREE.Vector3(-49, 1.2, 0) },
        { id: 'finish-line', label: 'Photofinish Gate', category: 'venue', description: 'High-speed camera aligned precisely along finish line plane', position: new THREE.Vector3(51.2, 2.5, 18), target: new THREE.Vector3(50, 1.2, -18) },
        { id: 'overhead', label: "Bird's-Eye Overhead", category: 'venue', description: 'Top-down view of all 8 competition lanes', position: new THREE.Vector3(0, 68, 0.1), target: new THREE.Vector3(0, 0, 0) },
        { id: 'exterior-skyline', label: 'Bay & City Skyline', category: 'venue', description: 'Panoramic view looking across the bay bridge', position: new THREE.Vector3(260, 90, 180), target: new THREE.Vector3(-80, 20, -200) },
      ];
    } else if (venueId === 'skatbaen') {
      return [
        { id: 'runway-overview', label: 'Long Jump Overview', category: 'venue', description: 'Wide broadcast view of runway and sand pit', position: new THREE.Vector3(-10, 15, 25), target: new THREE.Vector3(0, 1.0, 0) },
        { id: 'takeoff-board', label: 'Take-off Board Zoom', category: 'venue', description: 'Close-up camera on plasticine foul line indicator', position: new THREE.Vector3(7.4, 2.0, 4.5), target: new THREE.Vector3(7.4, 0.2, 0) },
        { id: 'sandpit-landing', label: 'Sand Pit Landing', category: 'venue', description: 'Tracking camera facing impact area', position: new THREE.Vector3(18.0, 3.5, 6.0), target: new THREE.Vector3(12.5, 0.5, 0) },
        { id: 'skatbaen-overhead', label: 'Skatbaen Aerial', category: 'venue', description: 'Top-down view of Skatbaen Stadium bowl', position: new THREE.Vector3(0, 55, 0.1), target: new THREE.Vector3(0, 0, 0) },
      ];
    } else {
      return [
        { id: 'pool-overview', label: '50m Pool Overview', category: 'venue', description: 'Broadcast angle showing full 8-lane competition pool', position: new THREE.Vector3(0, 20, 32), target: new THREE.Vector3(0, -1.0, 0) },
        { id: 'starting-blocks', label: 'Starting Blocks', category: 'venue', description: 'Close-up on swimmers on blocks before reaction dive', position: new THREE.Vector3(-25.5, 3.5, 12.0), target: new THREE.Vector3(-25.5, 0.5, 0) },
        { id: '50m-turn-wall', label: '50m Flip Turn Wall', category: 'venue', description: 'Underwater angle at the 50m turn touch pads', position: new THREE.Vector3(24.5, 1.5, -8.0), target: new THREE.Vector3(24.9, -1.0, 0) },
        { id: 'aquatic-aerial', label: 'Vlaskovich Arena Roof', category: 'venue', description: 'High angle showing arena seating bowl and pool deck', position: new THREE.Vector3(0, 45, 0.1), target: new THREE.Vector3(0, 0, 0) },
      ];
    }
  }

  public getCurrentVenueId(): VenueId | null {
    return this.currentVenueId;
  }
}
