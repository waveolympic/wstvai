import * as THREE from 'three';
import { TextureGenerator } from '../../utils/textureGenerator';
import { Athlete } from '../../types/olympics';

export class SkatbaenVenueBuilder {
  private group: THREE.Group;
  private sandTexture: THREE.CanvasTexture;
  private trackTexture: THREE.CanvasTexture;
  private athleteMeshes: THREE.Group[] = [];

  constructor() {
    this.group = new THREE.Group();
    this.group.name = 'SkatbaenStadiumVenue';

    this.sandTexture = TextureGenerator.createSandTexture();
    this.trackTexture = TextureGenerator.createBlueTrackTexture();

    this.buildVenue();
  }

  public getGroup(): THREE.Group {
    return this.group;
  }

  private buildVenue() {
    this.buildStadiumBowl();
    this.buildLongJumpRunwayAndSandPit();
    this.buildMeasurementEquipmentAndJudges();
  }

  /**
   * 45,000 seat Skatbaen Athletics Stadium structure
   */
  private buildStadiumBowl() {
    // Stadium Ground Field Grass
    const grassGeo = new THREE.PlaneGeometry(160, 100);
    const grassMat = new THREE.MeshStandardMaterial({
      color: 0x2e7d32,
      roughness: 0.8,
    });
    const grassMesh = new THREE.Mesh(grassGeo, grassMat);
    grassMesh.rotation.x = -Math.PI / 2;
    grassMesh.receiveShadow = true;
    this.group.add(grassMesh);

    // Oval Stadium Seating Tiers
    const seatMat = new THREE.MeshStandardMaterial({
      color: 0x0284c7,
      roughness: 0.4,
    });

    const tierCount = 12;
    for (let t = 0; t < tierCount; t++) {
      const radiusX = 65 + t * 2.5;
      const radiusZ = 45 + t * 2.0;
      const height = t * 1.8;

      const ringGeo = new THREE.TorusGeometry((radiusX + radiusZ) / 2, 0.9, 6, 64);
      const ringMesh = new THREE.Mesh(ringGeo, seatMat);
      ringMesh.rotation.x = Math.PI / 2;
      ringMesh.position.y = height + 1.5;
      ringMesh.scale.set(radiusX / ((radiusX + radiusZ) / 2), radiusZ / ((radiusX + radiusZ) / 2), 1);
      ringMesh.castShadow = true;
      ringMesh.receiveShadow = true;
      this.group.add(ringMesh);
    }

    // Stadium Floodlight Towers (4 corners)
    const towerGeo = new THREE.CylinderGeometry(0.6, 1.2, 35, 8);
    const towerMat = new THREE.MeshStandardMaterial({ color: 0x475569, metalness: 0.8, roughness: 0.2 });
    const lampMat = new THREE.MeshBasicMaterial({ color: 0xffffff });

    const towerCoords = [
      [-65, 45],
      [65, 45],
      [-65, -45],
      [65, -45],
    ];

    towerCoords.forEach(([x, z]) => {
      const tower = new THREE.Mesh(towerGeo, towerMat);
      tower.position.set(x, 17.5, z);
      tower.castShadow = true;
      this.group.add(tower);

      // Light Panel at top
      const panelGeo = new THREE.BoxGeometry(6, 4, 1);
      const panel = new THREE.Mesh(panelGeo, lampMat);
      panel.position.set(x, 34, z);
      panel.lookAt(0, 5, 0);
      this.group.add(panel);
    });

    // Stadium Canopy Roof Structure
    const roofGeo = new THREE.TorusGeometry(80, 8, 4, 32, Math.PI);
    const roofMat = new THREE.MeshStandardMaterial({
      color: 0xe2e8f0,
      metalness: 0.5,
      roughness: 0.3,
      transparent: true,
      opacity: 0.75,
    });
    const roofMesh = new THREE.Mesh(roofGeo, roofMat);
    roofMesh.rotation.x = Math.PI / 2;
    roofMesh.position.set(0, 24, 0);
    this.group.add(roofMesh);
  }

  /**
   * Dedicated Long Jump Runway (45m length), Take-Off Board, Sand Pit (10m x 3.5m)
   */
  private buildLongJumpRunwayAndSandPit() {
    // 1. Runway Surface (45m x 1.22m)
    const runwayGeo = new THREE.BoxGeometry(45, 0.04, 1.22);
    const runwayMat = new THREE.MeshStandardMaterial({
      map: this.trackTexture,
      roughness: 0.6,
    });
    const runwayMesh = new THREE.Mesh(runwayGeo, runwayMat);
    runwayMesh.position.set(-15, 0.02, 0);
    runwayMesh.receiveShadow = true;
    this.group.add(runwayMesh);

    // Distance Markers alongside runway (10m, 20m, 30m, 40m)
    const textMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    [-35, -25, -15, -5].forEach((xPos, idx) => {
      const markerGeo = new THREE.BoxGeometry(0.3, 0.15, 0.3);
      const marker = new THREE.Mesh(markerGeo, textMat);
      marker.position.set(xPos, 0.08, -0.9);
      this.group.add(marker);
    });

    // 2. Take-off Board (1.22m x 20cm white wood board + 10cm red plasticine indicator strip)
    const boardGeo = new THREE.BoxGeometry(0.2, 0.05, 1.22);
    const boardMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.3 });
    const boardMesh = new THREE.Mesh(boardGeo, boardMat);
    boardMesh.position.set(7.4, 0.03, 0);
    this.group.add(boardMesh);

    // Red Plasticine Foul Line Indicator
    const foulGeo = new THREE.BoxGeometry(0.1, 0.052, 1.22);
    const foulMat = new THREE.MeshStandardMaterial({ color: 0xdc2626, roughness: 0.5 });
    const foulMesh = new THREE.Mesh(foulGeo, foulMat);
    foulMesh.position.set(7.55, 0.031, 0);
    this.group.add(foulMesh);

    // 3. Sand Pit (10m length x 3.5m width x 0.3m depth)
    const pitGeo = new THREE.BoxGeometry(10, 0.02, 3.5);
    const pitMat = new THREE.MeshStandardMaterial({
      map: this.sandTexture,
      roughness: 0.9,
    });
    const pitMesh = new THREE.Mesh(pitGeo, pitMat);
    pitMesh.position.set(12.5, 0.01, 0);
    pitMesh.receiveShadow = true;
    this.group.add(pitMesh);

    // Sand Pit Border Curbing (Padded Rubber Border)
    const borderGeo = new THREE.BoxGeometry(10.4, 0.12, 0.2);
    const borderMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.4 });

    const borderNorth = new THREE.Mesh(borderGeo, borderMat);
    borderNorth.position.set(12.5, 0.06, 1.85);
    const borderSouth = new THREE.Mesh(borderGeo, borderMat);
    borderSouth.position.set(12.5, 0.06, -1.85);

    this.group.add(borderNorth, borderSouth);
  }

  /**
   * Measurement laser tripod, wind gauge, judges & scoreboard
   */
  private buildMeasurementEquipmentAndJudges() {
    // Electronic Laser Distance Meter on Tripod
    const tripodGeo = new THREE.CylinderGeometry(0.05, 0.4, 1.2, 3);
    const tripodMat = new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.8 });
    const tripod = new THREE.Mesh(tripodGeo, tripodMat);
    tripod.position.set(12.5, 0.6, 2.3);
    this.group.add(tripod);

    const laserBoxGeo = new THREE.BoxGeometry(0.3, 0.2, 0.2);
    const laserMat = new THREE.MeshStandardMaterial({ color: 0xeab308, metalness: 0.5 });
    const laserBox = new THREE.Mesh(laserBoxGeo, laserMat);
    laserBox.position.set(12.5, 1.3, 2.3);
    laserBox.lookAt(12.5, 0, 0);
    this.group.add(laserBox);

    // Digital LED Distance Display Sign
    const signGeo = new THREE.BoxGeometry(2.5, 1.2, 0.2);
    const signFrameMat = new THREE.MeshStandardMaterial({ color: 0x0f172a });
    const signFrame = new THREE.Mesh(signGeo, signFrameMat);
    signFrame.position.set(12.5, 1.8, -3.2);

    const ledGeo = new THREE.PlaneGeometry(2.3, 1.0);
    const ledMat = new THREE.MeshBasicMaterial({ color: 0x00ffcc });
    const ledMesh = new THREE.Mesh(ledGeo, ledMat);
    ledMesh.position.set(12.5, 1.8, -3.09);
    this.group.add(signFrame, ledMesh);

    // Field Event Referees (3 judges)
    const judgeMat = new THREE.MeshStandardMaterial({ color: 0xffffff });
    const capMat = new THREE.MeshStandardMaterial({ color: 0x0284c7 });

    const judgePositions = [
      [7.5, 0, 1.5], // Take-off board judge with white/red flag
      [10.0, 0, -2.0], // Measurement judge
      [15.0, 0, -2.0], // Rake judge
    ];

    judgePositions.forEach(([x, y, z]) => {
      const judgeGroup = new THREE.Group();
      // Body
      const bodyGeo = new THREE.CylinderGeometry(0.25, 0.2, 1.4, 8);
      const body = new THREE.Mesh(bodyGeo, judgeMat);
      body.position.y = 0.7;

      // Head
      const headGeo = new THREE.SphereGeometry(0.14, 12, 12);
      const head = new THREE.Mesh(headGeo, judgeMat);
      head.position.y = 1.5;

      // Cap
      const capGeo = new THREE.CylinderGeometry(0.16, 0.16, 0.08, 12);
      const cap = new THREE.Mesh(capGeo, capMat);
      cap.position.y = 1.6;

      judgeGroup.add(body, head, cap);
      judgeGroup.position.set(x, y, z);
      this.group.add(judgeGroup);
    });
  }

  /**
   * Spawn Athletes for Long Jump Competition
   */
  public spawnAthletes(athletes: Athlete[]): void {
    // Clear existing
    this.athleteMeshes.forEach(m => this.group.remove(m));
    this.athleteMeshes = [];

    athletes.forEach((athlete, index) => {
      const group = new THREE.Group();

      // Shirt
      const shirtMat = new THREE.MeshStandardMaterial({
        color: athlete.primaryColor,
        roughness: 0.5,
      });

      // Skin
      const skinMat = new THREE.MeshStandardMaterial({
        color: 0xd2b48c,
        roughness: 0.7,
      });

      // Torso
      const torsoGeo = new THREE.CylinderGeometry(0.22, 0.18, 0.7, 8);
      const torso = new THREE.Mesh(torsoGeo, shirtMat);
      torso.position.y = 0.95;
      torso.castShadow = true;

      // Head
      const headGeo = new THREE.SphereGeometry(0.13, 12, 12);
      const head = new THREE.Mesh(headGeo, skinMat);
      head.position.y = 1.45;
      head.castShadow = true;

      // Legs
      const legMat = new THREE.MeshStandardMaterial({ color: athlete.secondaryColor });
      const legGeo = new THREE.CylinderGeometry(0.08, 0.07, 0.6, 8);

      const legL = new THREE.Mesh(legGeo, legMat);
      legL.position.set(-0.1, 0.3, 0);
      const legR = new THREE.Mesh(legGeo, legMat);
      legR.position.set(0.1, 0.3, 0);

      group.add(torso, head, legL, legR);

      // Stagger athletes along the waiting area (x = -38 + index * 2.5)
      group.position.set(-38 + index * 3.0, 0, -2.5);
      this.group.add(group);
      this.athleteMeshes.push(group);
    });
  }

  /**
   * Animate Long Jumper along runway, board hit, sail flight, and sand pit landing
   */
  public updateLongJumpAnimation(progressRatio: number, activeAthleteIndex: number = 0): {
    phase: string;
    distanceMeters: number;
    athletePos: THREE.Vector3;
  } {
    if (this.athleteMeshes.length === 0) {
      return { phase: 'ready', distanceMeters: 0, athletePos: new THREE.Vector3() };
    }

    const athlete = this.athleteMeshes[activeAthleteIndex % this.athleteMeshes.length];
    let phase = 'Runway Approach (0-40m Sprint)';
    let xPos = -35 + progressRatio * 42.4; // Board at x = 7.4
    let yPos = 0;
    let distanceMeters = 0;

    if (progressRatio < 0.6) {
      // 1. Runway Sprint Phase
      phase = 'Runway Acceleration (35m Sprint)';
      xPos = -35 + (progressRatio / 0.6) * 42.4;
      yPos = 0;
      distanceMeters = 0;
    } else if (progressRatio < 0.85) {
      // 2. Flight / Sail Phase (In-Air Elevation Leap)
      phase = 'Elevation Flight Phase (In-Air Sail)';
      const flightProgress = (progressRatio - 0.6) / 0.25;
      xPos = 7.4 + flightProgress * 8.2; // Leap up to ~8.2m into pit
      yPos = Math.sin(flightProgress * Math.PI) * 2.4; // Parabolic jump arc
      distanceMeters = +(7.4 + flightProgress * 8.2 - 7.4).toFixed(2);
    } else {
      // 3. Sand Pit Landing & Impact Phase
      phase = 'Sand Pit Impact & Distance Measure';
      const landingProgress = (progressRatio - 0.85) / 0.15;
      xPos = 15.6 + landingProgress * 0.8;
      yPos = Math.max(0, 0.3 - landingProgress * 0.3);
      distanceMeters = 8.24;
    }

    athlete.position.set(xPos, yPos, 0);
    athlete.rotation.y = Math.PI / 2; // Face forward down runway

    return {
      phase,
      distanceMeters,
      athletePos: athlete.position.clone(),
    };
  }
}
