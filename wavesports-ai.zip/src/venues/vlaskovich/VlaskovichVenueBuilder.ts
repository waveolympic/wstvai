import * as THREE from 'three';
import { TextureGenerator } from '../../utils/textureGenerator';
import { Athlete } from '../../types/olympics';

export class VlaskovichVenueBuilder {
  private group: THREE.Group;
  private poolTileTexture: THREE.CanvasTexture;
  private waterTexture: THREE.CanvasTexture;
  private swimmerMeshes: THREE.Group[] = [];

  constructor() {
    this.group = new THREE.Group();
    this.group.name = 'VlaskovichIndoorArenaVenue';

    this.poolTileTexture = TextureGenerator.createPoolTileTexture();
    this.waterTexture = TextureGenerator.createWaterTexture();

    this.buildVenue();
  }

  public getGroup(): THREE.Group {
    return this.group;
  }

  private buildVenue() {
    this.buildArenaStructure();
    this.build50mOlympicPool();
    this.buildLaneRopesAndStartingBlocks();
    this.buildTurnFlagsAndDeckOfficials();
  }

  /**
   * 22,000 Seat Indoor Aquatic Arena Enclosure & Roof Trusses
   */
  private buildArenaStructure() {
    // Indoor Arena Concourse Floor
    const floorGeo = new THREE.BoxGeometry(100, 0.2, 70);
    const floorMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.5 });
    const floorMesh = new THREE.Mesh(floorGeo, floorMat);
    floorMesh.position.y = -0.1;
    floorMesh.receiveShadow = true;
    this.group.add(floorMesh);

    // Indoor Arena Seating Tiers (Ocean Cyan to Slate Gradient)
    const seatMat = new THREE.MeshStandardMaterial({ color: 0x0284c7, roughness: 0.4 });
    const tierCount = 10;
    for (let t = 0; t < tierCount; t++) {
      const width = 64 + t * 2.5;
      const depth = 38 + t * 2.2;
      const height = t * 1.6;

      const ringGeo = new THREE.TorusGeometry((width + depth) / 2, 0.8, 4, 32);
      const ringMesh = new THREE.Mesh(ringGeo, seatMat);
      ringMesh.rotation.x = Math.PI / 2;
      ringMesh.position.y = height + 1.2;
      ringMesh.scale.set(width / ((width + depth) / 2), depth / ((width + depth) / 2), 1);
      this.group.add(ringMesh);
    }

    // Overhead Structural Steel Roof Trusses & Spotlights
    const trussMat = new THREE.MeshStandardMaterial({ color: 0x475569, metalness: 0.8 });
    for (let x = -35; x <= 35; x += 17.5) {
      const trussGeo = new THREE.BoxGeometry(0.6, 1.2, 45);
      const truss = new THREE.Mesh(trussGeo, trussMat);
      truss.position.set(x, 18, 0);
      this.group.add(truss);

      // Arena Spotlights hung on trusses
      for (let z = -15; z <= 15; z += 10) {
        const spotGeo = new THREE.CylinderGeometry(0.3, 0.4, 0.6, 8);
        const spotMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
        const spot = new THREE.Mesh(spotGeo, spotMat);
        spot.position.set(x, 17.2, z);
        spot.rotation.x = Math.PI;
        this.group.add(spot);
      }
    }
  }

  /**
   * 50m Olympic Competition Pool (50m x 25m x 3m deep)
   */
  private build50mOlympicPool() {
    // 1. Pool Floor Tile Base (3m below deck level)
    const poolFloorGeo = new THREE.PlaneGeometry(50, 25);
    const poolFloorMat = new THREE.MeshStandardMaterial({
      map: this.poolTileTexture,
      roughness: 0.2,
      metalness: 0.1,
    });
    const poolFloor = new THREE.Mesh(poolFloorGeo, poolFloorMat);
    poolFloor.rotation.x = -Math.PI / 2;
    poolFloor.position.set(0, -3.0, 0);
    poolFloor.receiveShadow = true;
    this.group.add(poolFloor);

    // 2. Tile Pool Side Walls
    const wallMat = new THREE.MeshStandardMaterial({ color: 0x0088cc, roughness: 0.2 });

    // North/South Walls (50m x 3m)
    const longWallGeo = new THREE.BoxGeometry(50, 3, 0.2);
    const wallNorth = new THREE.Mesh(longWallGeo, wallMat);
    wallNorth.position.set(0, -1.5, 12.5);
    const wallSouth = new THREE.Mesh(longWallGeo, wallMat);
    wallSouth.position.set(0, -1.5, -12.5);

    // East/West End Walls (25m x 3m)
    const endWallGeo = new THREE.BoxGeometry(0.2, 3, 25);
    const wallEast = new THREE.Mesh(endWallGeo, wallMat);
    wallEast.position.set(25, -1.5, 0);
    const wallWest = new THREE.Mesh(endWallGeo, wallMat);
    wallWest.position.set(-25, -1.5, 0);

    this.group.add(wallNorth, wallSouth, wallEast, wallWest);

    // 3. Translucent Water Surface Shader Mesh (at y = 0.0m)
    const waterGeo = new THREE.PlaneGeometry(50, 25, 32, 16);
    const waterMat = new THREE.MeshStandardMaterial({
      map: this.waterTexture,
      color: 0x00bfff,
      transparent: true,
      opacity: 0.65,
      roughness: 0.1,
      metalness: 0.2,
      side: THREE.DoubleSide,
    });
    const waterMesh = new THREE.Mesh(waterGeo, waterMat);
    waterMesh.rotation.x = -Math.PI / 2;
    waterMesh.position.set(0, -0.05, 0);
    this.group.add(waterMesh);
  }

  /**
   * 8 Competition Lanes with Anti-Wave Float Ropes & Starting Blocks
   */
  private buildLaneRopesAndStartingBlocks() {
    const laneWidth = 3.125; // 25m / 8 lanes

    // 1. Anti-Wave Float Ropes separating 8 lanes
    const ropeColors = [0xdc2626, 0x0284c7, 0x0284c7, 0xeab308, 0xeab308, 0x0284c7, 0x0284c7, 0xdc2626];

    for (let r = 0; r <= 8; r++) {
      const zPos = -12.5 + r * laneWidth;
      const ropeColor = ropeColors[Math.min(r, 7)];

      // Rope line cable
      const ropeGeo = new THREE.CylinderGeometry(0.04, 0.04, 50, 8);
      const ropeMat = new THREE.MeshStandardMaterial({ color: ropeColor, roughness: 0.3 });
      const rope = new THREE.Mesh(ropeGeo, ropeMat);
      rope.rotation.z = Math.PI / 2;
      rope.position.set(0, 0.02, zPos);
      this.group.add(rope);

      // Float disks along rope
      for (let x = -24; x <= 24; x += 0.8) {
        const floatGeo = new THREE.CylinderGeometry(0.08, 0.08, 0.15, 8);
        const floatMesh = new THREE.Mesh(floatGeo, ropeMat);
        floatMesh.rotation.z = Math.PI / 2;
        floatMesh.position.set(x, 0.02, zPos);
        this.group.add(floatMesh);
      }
    }

    // 2. Starting Blocks at Start Wall (x = -25.5m)
    const blockMat = new THREE.MeshStandardMaterial({ color: 0x0284c7, roughness: 0.3, metalness: 0.5 });
    const topMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.8 }); // Non-slip top

    for (let lane = 1; lane <= 8; lane++) {
      const zPos = -12.5 + (lane - 0.5) * laneWidth;

      const blockGroup = new THREE.Group();

      // Base pedestal
      const baseGeo = new THREE.BoxGeometry(0.8, 0.7, 0.7);
      const base = new THREE.Mesh(baseGeo, blockMat);
      base.position.set(0, 0.35, 0);

      // Angled platform top with wedge
      const topGeo = new THREE.BoxGeometry(0.9, 0.08, 0.75);
      const top = new THREE.Mesh(topGeo, topMat);
      top.position.set(0.05, 0.74, 0);
      top.rotation.z = -0.15; // 10 degree inclination toward pool

      // Lane Number Sign on front & back
      const numGeo = new THREE.BoxGeometry(0.05, 0.3, 0.3);
      const numMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
      const numMesh = new THREE.Mesh(numGeo, numMat);
      numMesh.position.set(-0.41, 0.45, 0);

      blockGroup.add(base, top, numMesh);
      blockGroup.position.set(-25.6, 0.0, zPos);
      this.group.add(blockGroup);
    }

    // 3. Wall Electronic Touch Pads at both ends (0m and 50m)
    const padMat = new THREE.MeshStandardMaterial({ color: 0xeab308, roughness: 0.4 });
    for (let lane = 1; lane <= 8; lane++) {
      const zPos = -12.5 + (lane - 0.5) * laneWidth;
      const padGeo = new THREE.BoxGeometry(0.04, 0.9, 2.4);

      // Start wall pad
      const padStart = new THREE.Mesh(padGeo, padMat);
      padStart.position.set(-24.96, -0.4, zPos);

      // Turn wall pad
      const padTurn = new THREE.Mesh(padGeo, padMat);
      padTurn.position.set(24.96, -0.4, zPos);

      this.group.add(padStart, padTurn);
    }
  }

  /**
   * Backstroke Turn Flags & Poolside Deck Officials
   */
  private buildTurnFlagsAndDeckOfficials() {
    // Backstroke Turn Indicator Flags suspended 5m from each end wall at height 1.8m
    const flagColorMat = new THREE.MeshStandardMaterial({ color: 0xdc2626 });

    [-20, 20].forEach((xPos) => {
      // Suspension poles on deck
      const poleGeo = new THREE.CylinderGeometry(0.06, 0.06, 3.5, 8);
      const poleMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.8 });

      const poleL = new THREE.Mesh(poleGeo, poleMat);
      poleL.position.set(xPos, 1.75, 13.5);
      const poleR = new THREE.Mesh(poleGeo, poleMat);
      poleR.position.set(xPos, 1.75, -13.5);

      // Cable across
      const cableGeo = new THREE.CylinderGeometry(0.02, 0.02, 27, 8);
      const cable = new THREE.Mesh(cableGeo, poleMat);
      cable.rotation.x = Math.PI / 2;
      cable.position.set(xPos, 2.8, 0);

      this.group.add(poleL, poleR, cable);

      // Triangular Flags hanging on cable
      for (let z = -12; z <= 12; z += 1.5) {
        const flagGeo = new THREE.ConeGeometry(0.2, 0.4, 3);
        const flag = new THREE.Mesh(flagGeo, flagColorMat);
        flag.rotation.x = Math.PI;
        flag.position.set(xPos, 2.5, z);
        this.group.add(flag);
      }
    });

    // Poolside Deck Referees & Stroke Judges (White uniforms)
    const judgeMat = new THREE.MeshStandardMaterial({ color: 0xffffff });
    [-15, 0, 15].forEach((xPos) => {
      const judge = new THREE.Group();
      const body = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.18, 1.3, 8), judgeMat);
      body.position.y = 0.65;
      const head = new THREE.Mesh(new THREE.SphereGeometry(0.12, 12, 12), judgeMat);
      head.position.y = 1.35;
      judge.add(body, head);
      judge.position.set(xPos, 0, 14.2);
      this.group.add(judge);
    });
  }

  /**
   * Spawn 8 Swimmers on Starting Blocks with caps & goggles
   */
  public spawnSwimmers(athletes: Athlete[]): void {
    this.swimmerMeshes.forEach(m => this.group.remove(m));
    this.swimmerMeshes = [];

    const laneWidth = 3.125;

    athletes.forEach((athlete) => {
      const zPos = -12.5 + (athlete.laneOrPosition - 0.5) * laneWidth;

      const swimmerGroup = new THREE.Group();

      // Swim Cap
      const capMat = new THREE.MeshStandardMaterial({ color: athlete.primaryColor, roughness: 0.3 });
      // Skin
      const skinMat = new THREE.MeshStandardMaterial({ color: 0xd2b48c, roughness: 0.6 });
      // Trunks / Suit
      const suitMat = new THREE.MeshStandardMaterial({ color: athlete.secondaryColor, roughness: 0.4 });

      // Torso
      const torsoGeo = new THREE.CylinderGeometry(0.22, 0.17, 0.65, 8);
      const torso = new THREE.Mesh(torsoGeo, suitMat);
      torso.position.y = 0.95;

      // Head with Swim Cap
      const headGeo = new THREE.SphereGeometry(0.13, 12, 12);
      const head = new THREE.Mesh(headGeo, capMat);
      head.position.y = 1.4;

      // Goggles strap line
      const goggleGeo = new THREE.TorusGeometry(0.11, 0.02, 4, 12);
      const goggleMat = new THREE.MeshBasicMaterial({ color: 0x111111 });
      const goggles = new THREE.Mesh(goggleGeo, goggleMat);
      goggles.position.set(0.05, 1.4, 0);
      goggles.rotation.y = Math.PI / 2;

      swimmerGroup.add(torso, head, goggles);
      // Position on block top at start
      swimmerGroup.position.set(-25.5, 0.1, zPos);
      this.group.add(swimmerGroup);

      this.swimmerMeshes.push(swimmerGroup);
    });
  }

  /**
   * Animate Swimming event: block dive -> underwater dolphin kick -> freestyle stroke -> flip turn -> wall touch finish
   */
  public updateSwimmingAnimation(progressRatio: number, activeSwimmerIndex: number = 0): {
    phase: string;
    distanceMeters: number;
    swimmerPos: THREE.Vector3;
  } {
    if (this.swimmerMeshes.length === 0) {
      return { phase: 'ready', distanceMeters: 0, swimmerPos: new THREE.Vector3() };
    }

    const swimmer = this.swimmerMeshes[activeSwimmerIndex % this.swimmerMeshes.length];

    let phase = 'On Blocks (Ready Stance)';
    let xPos = -25.5;
    let yPos = 0.1;
    let distanceMeters = 0;

    if (progressRatio < 0.05) {
      // 1. Block Reaction Dive
      phase = 'Reaction Dive Off Block';
      const diveP = progressRatio / 0.05;
      xPos = -25.5 + diveP * 4.5;
      yPos = 0.7 - diveP * 1.2; // Arc into water
      distanceMeters = 4.5;
    } else if (progressRatio < 0.20) {
      // 2. Underwater Streamline & Dolphin Kicks (4.5m - 15m)
      phase = 'Underwater Streamline & Dolphin Kicks';
      const streamP = (progressRatio - 0.05) / 0.15;
      xPos = -21.0 + streamP * 10.5;
      yPos = -0.8 + Math.sin(streamP * Math.PI * 6) * 0.15; // Subsurface glide
      distanceMeters = +(4.5 + streamP * 10.5).toFixed(1);
    } else if (progressRatio < 0.48) {
      // 3. Lap 1 Surface Freestyle Stroke (15m - 50m turn wall)
      phase = 'Lap 1 High-Cadence Freestyle Stroke';
      const strokeP = (progressRatio - 0.20) / 0.28;
      xPos = -10.5 + strokeP * 35.0; // Up to x = +24.5 (50m wall)
      yPos = -0.2 + Math.sin(strokeP * Math.PI * 18) * 0.05;
      distanceMeters = +(15.0 + strokeP * 35.0).toFixed(1);
    } else if (progressRatio < 0.54) {
      // 4. 50m Wall Flip Turn Execution
      phase = '50m Flip Turn & Explosive Wall Push';
      const turnP = (progressRatio - 0.48) / 0.06;
      xPos = 24.5 - turnP * 3.5;
      yPos = -0.6;
      swimmer.rotation.z = Math.PI * turnP; // 180 degree turn
      distanceMeters = 50.0;
    } else if (progressRatio < 0.70) {
      // 5. Lap 2 Underwater Streamline (50m - 65m)
      phase = 'Lap 2 Subsurface Streamline Breakout';
      const lap2StreamP = (progressRatio - 0.54) / 0.16;
      xPos = 21.0 - lap2StreamP * 10.5;
      yPos = -0.8 + Math.sin(lap2StreamP * Math.PI * 4) * 0.12;
      distanceMeters = +(50.0 + lap2StreamP * 15.0).toFixed(1);
    } else {
      // 6. Lap 2 Final Sprint & Touch Pad Contact (65m - 100m)
      phase = 'Final 35m Sprint & Touch Pad Contact';
      const finishP = (progressRatio - 0.70) / 0.30;
      xPos = 10.5 - finishP * 35.0; // Down to x = -24.5 (0m finish pad)
      yPos = -0.2 + Math.sin(finishP * Math.PI * 20) * 0.05;
      distanceMeters = +(65.0 + finishP * 35.0).toFixed(1);
    }

    swimmer.position.set(xPos, yPos, swimmer.position.z);

    return {
      phase,
      distanceMeters,
      swimmerPos: swimmer.position.clone(),
    };
  }
}
