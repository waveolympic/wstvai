import React, { useState, useMemo, useEffect, useRef } from 'react';
import { Layers, Maximize2, Trophy, Film } from 'lucide-react';
import { OlympicEvent, AIMonitorMetrics, TelemetryFrame, HighlightClip } from './types/olympics';
import { OFFICIAL_EVENTS, OFFICIAL_VENUES } from './data/officialEvents';
import { MainSimulationCanvas } from './components/3d/MainSimulationCanvas';
import { HeaderBranding } from './components/ui/HeaderBranding';
import { EventSelector } from './components/ui/EventSelector';
import { PreparationEngineModal } from './components/ui/PreparationEngineModal';
import { SimulationControls } from './components/ui/SimulationControls';
import { PhotofinishLeaderboard } from './components/ui/PhotofinishLeaderboard';
import { AIMonitoringPanel } from './components/ui/AIMonitoringPanel';
import { LiveCommentaryTicker } from './components/ui/LiveCommentaryTicker';
import { HighlightGalleryModal } from './components/ui/HighlightGalleryModal';
import { CameraPreset } from './venues/VenueManager';
import { WavesportsIntegrationLayer } from './integration/WavesportsIntegrationLayer';

export default function App() {
  // Run Integration Layer startup validation
  useEffect(() => {
    const report = WavesportsIntegrationLayer.validateSystemConfiguration();
    console.log('[WavesportsIntegrationLayer] System Validation Audit:', report);
  }, []);
  // State
  const [activeEvent, setActiveEvent] = useState<OlympicEvent>(OFFICIAL_EVENTS[0]); // Default: Men's 100m
  const [isSimulating, setIsSimulating] = useState<boolean>(false);
  const [simSpeed, setSimSpeed] = useState<number>(1.0);
  const [activePresetId, setActivePresetId] = useState<string>('track-overview');
  const [cameraPresets, setCameraPresets] = useState<CameraPreset[]>([]);

  // Telemetry & Monitor state
  const [activePhase, setActivePhase] = useState<string>('On Your Marks (Ready Stance)');
  const [telemetryValue, setTelemetryValue] = useState<number>(0);
  const [simTimeMs, setSimTimeMs] = useState<number>(0);
  const [gpuFps, setGpuFps] = useState<number>(60);
  const [meshCount, setMeshCount] = useState<number>(42);
  const [vertexCount, setVertexCount] = useState<number>(185000);

  // Replay System State
  const [recordedTelemetryLog, setRecordedTelemetryLog] = useState<TelemetryFrame[]>([]);
  const [isReplaying, setIsReplaying] = useState<boolean>(false);
  const [replayProgressRatio, setReplayProgressRatio] = useState<number>(0);
  const [replaySpeed, setReplaySpeed] = useState<number>(0.25); // Default slow-mo for analysis

  // Highlight Recording State
  const [isRecording, setIsRecording] = useState<boolean>(false);
  const [recordingDurationMs, setRecordingDurationMs] = useState<number>(0);
  const [savedClips, setSavedClips] = useState<HighlightClip[]>([]);
  const [showHighlightsGallery, setShowHighlightsGallery] = useState<boolean>(false);

  // UI Panels State
  const [showEventSelector, setShowEventSelector] = useState<boolean>(false);
  const [showPrepModal, setShowPrepModal] = useState<boolean>(false);
  const [showAIMonitor, setShowAIMonitor] = useState<boolean>(false);
  const [showLeaderboard, setShowLeaderboard] = useState<boolean>(true);
  const [isControlsExpanded, setIsControlsExpanded] = useState<boolean>(true);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);

  // Refs
  const takeSnapshotRef = useRef<(() => string | null) | null>(null);
  const recordingTimerRef = useRef<number | null>(null);

  const activeVenue = useMemo(() => OFFICIAL_VENUES[activeEvent.venueId], [activeEvent.venueId]);

  // Handle live recording timer
  useEffect(() => {
    if (isRecording) {
      setRecordingDurationMs(0);
      const startTime = Date.now();
      recordingTimerRef.current = window.setInterval(() => {
        setRecordingDurationMs(Date.now() - startTime);
      }, 200);
    } else {
      if (recordingTimerRef.current) {
        clearInterval(recordingTimerRef.current);
        recordingTimerRef.current = null;
      }
    }
    return () => {
      if (recordingTimerRef.current) clearInterval(recordingTimerRef.current);
    };
  }, [isRecording]);

  // Handle Replay Playback animation loop
  useEffect(() => {
    let animId: number;
    let lastTime = performance.now();

    const replayLoop = (now: number) => {
      const deltaSec = (now - lastTime) / 1000;
      lastTime = now;

      if (isReplaying && isSimulating) {
        const durationSec = activeEvent.distanceMeters <= 100 ? 10 : activeEvent.distanceMeters <= 400 ? 44 : 105;
        setReplayProgressRatio((prev) => {
          const next = prev + (deltaSec * replaySpeed) / durationSec;
          if (next >= 1.0) {
            setIsSimulating(false);
            return 1.0;
          }
          return next;
        });
      }
      animId = requestAnimationFrame(replayLoop);
    };

    if (isReplaying && isSimulating) {
      animId = requestAnimationFrame(replayLoop);
    }

    return () => {
      if (animId) cancelAnimationFrame(animId);
    };
  }, [isReplaying, isSimulating, replaySpeed, activeEvent.distanceMeters]);

  // Sync Telemetry UI during Replay Scrubbing
  useEffect(() => {
    if (isReplaying && recordedTelemetryLog.length > 0) {
      // Find closest telemetry frame to replayProgressRatio
      let closest = recordedTelemetryLog[0];
      let minDiff = 999;
      for (const frame of recordedTelemetryLog) {
        const diff = Math.abs(frame.progressRatio - replayProgressRatio);
        if (diff < minDiff) {
          minDiff = diff;
          closest = frame;
        }
      }
      if (closest) {
        setActivePhase(`[REPLAY ${replaySpeed}x] ${closest.phase}`);
        setTelemetryValue(closest.telemetryValue);
        setSimTimeMs(closest.simTimeMs);
      }
    }
  }, [isReplaying, replayProgressRatio, recordedTelemetryLog, replaySpeed]);

  const metrics: AIMonitorMetrics = {
    gpuFps,
    gpuFrameTimeMs: +(1000 / Math.max(1, gpuFps)).toFixed(1),
    ramUsageMb: 248,
    vramUsageMb: 480,
    activeVenue: activeVenue.name,
    activeVenueZip: activeVenue.zipFile,
    dormantVenuesCount: 2,
    active3DMeshCount: meshCount,
    activeVerticesCount: vertexCount,
    textureMemoryMb: 128,
    subsystemsHealth: {
      modelIntegrity: 'optimal',
      textures: 'optimal',
      materials: 'optimal',
      animations: 'optimal',
      physics: 'optimal',
      collisions: 'optimal',
      memoryGPU: 'optimal',
      timing: 'optimal',
      aiServices: 'optimal',
    },
  };

  const handleSelectEvent = (event: OlympicEvent) => {
    setActiveEvent(event);
    setIsSimulating(false);
    setIsReplaying(false);
    setRecordedTelemetryLog([]);
    setShowEventSelector(false);
  };

  const handleTelemetryFrameRecorded = (frame: TelemetryFrame) => {
    setRecordedTelemetryLog((prev) => {
      // Keep up to 500 frames max per event simulation
      if (prev.length >= 500) {
        return [...prev.slice(1), frame];
      }
      return [...prev, frame];
    });
  };

  const handleToggleReplay = () => {
    if (isReplaying) {
      setIsReplaying(false);
    } else {
      if (recordedTelemetryLog.length === 0) return;
      setIsReplaying(true);
      setReplayProgressRatio(0);
      setIsSimulating(true);
    }
  };

  const handleScrubReplay = (ratio: number) => {
    setReplayProgressRatio(Math.max(0, Math.min(1, ratio)));
  };

  const handleStepReplay = (deltaRatio: number) => {
    setReplayProgressRatio((prev) => Math.max(0, Math.min(1, prev + deltaRatio)));
  };

  const handleToggleRecording = () => {
    setIsRecording((prev) => !prev);
  };

  const handleQuick5sRecord = () => {
    setIsRecording(true);
    setTimeout(() => {
      setIsRecording(false);
      setShowHighlightsGallery(true);
    }, 5000);
  };

  const handleClipRecorded = (clip: HighlightClip) => {
    setSavedClips((prev) => [clip, ...prev]);
  };

  const handleTakeSnapshot = () => {
    if (takeSnapshotRef.current) {
      const dataUrl = takeSnapshotRef.current();
      if (dataUrl) {
        const snapshotClip: HighlightClip = {
          id: `snap-${Date.now()}`,
          title: `Photofinish Snapshot: ${activeEvent.name}`,
          eventName: activeEvent.name,
          venueName: activeEvent.venueName,
          durationMs: 0,
          snapshotDataUrl: dataUrl,
          recordedAt: new Date().toLocaleTimeString(),
          telemetryValue: telemetryValue,
          unitLabel: activeEvent.discipline === 'long-jump' ? 'm' : 'm',
        };
        setSavedClips((prev) => [snapshotClip, ...prev]);
        setShowHighlightsGallery(true);
      }
    }
  };

  const handleDeleteClip = (id: string) => {
    setSavedClips((prev) => prev.filter((c) => c.id !== id));
  };

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().then(() => setIsFullscreen(true)).catch(() => {});
    } else {
      document.exitFullscreen().then(() => setIsFullscreen(false)).catch(() => {});
    }
  };

  return (
    <div className="w-full h-full fixed inset-0 overflow-hidden bg-[#0b111e] text-slate-100 font-sans select-none">
      {/* 3D Simulation Canvas */}
      <MainSimulationCanvas
        activeEvent={activeEvent}
        isSimulating={isSimulating}
        isReplaying={isReplaying}
        replayProgressRatio={replayProgressRatio}
        simSpeed={simSpeed}
        activePresetId={activePresetId}
        isRecording={isRecording}
        onPresetsLoaded={(presets) => {
          setCameraPresets(presets);
          if (presets.length > 0) {
            setActivePresetId(presets[0].id);
          }
        }}
        onTelemetryUpdate={(telemetry) => {
          if (!isReplaying) {
            setActivePhase(telemetry.phase);
            setTelemetryValue(telemetry.telemetryValue);
            setSimTimeMs(telemetry.elapsedSimTimeMs);
            WavesportsIntegrationLayer.syncTelemetryState(
              telemetry.phase,
              telemetry.telemetryValue,
              telemetry.elapsedSimTimeMs
            );
          }
          setGpuFps(telemetry.fps);
          setMeshCount(telemetry.meshCount);
          setVertexCount(telemetry.vertexCount);
        }}
        onTelemetryFrameRecorded={handleTelemetryFrameRecorded}
        onClipRecorded={handleClipRecorded}
        takeSnapshotRef={takeSnapshotRef}
      />

      {/* Top Header Overlay */}
      <HeaderBranding
        activeEvent={activeEvent}
        activeVenue={activeVenue}
        isSimulating={isSimulating}
        onOpenValidationModal={() => setShowPrepModal(true)}
        onOpenAIMonitor={() => setShowAIMonitor(true)}
      />

      {/* Floating Left Bar: Event Selector, Leaderboard, Highlights Toggle */}
      <div className="absolute top-24 left-4 z-20 flex flex-col gap-2">
        <button
          onClick={() => setShowEventSelector(!showEventSelector)}
          className={`flex items-center gap-2 px-3.5 py-2.5 rounded-xl backdrop-blur-md border text-xs font-bold transition-all shadow-xl cursor-pointer ${
            showEventSelector
              ? 'bg-sky-500 text-slate-950 border-sky-400 shadow-sky-500/20'
              : 'bg-slate-900/85 border-white/15 text-slate-200 hover:bg-slate-800'
          }`}
        >
          <Layers className="w-4 h-4 text-sky-400" />
          <span>Select Competition</span>
        </button>

        <button
          onClick={() => setShowLeaderboard(!showLeaderboard)}
          className={`flex items-center gap-2 px-3.5 py-2.5 rounded-xl backdrop-blur-md border text-xs font-bold transition-all shadow-xl cursor-pointer ${
            showLeaderboard
              ? 'bg-amber-500/25 border-amber-400/50 text-amber-200 shadow-amber-500/20'
              : 'bg-slate-900/85 border-white/15 text-slate-300 hover:bg-slate-800'
          }`}
        >
          <Trophy className="w-4 h-4 text-amber-400" />
          <span>Photofinish Gate</span>
        </button>

        <button
          onClick={() => setShowHighlightsGallery(true)}
          className="flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-slate-900/85 backdrop-blur-md border border-white/15 text-slate-200 hover:bg-slate-800 text-xs font-bold transition-all shadow-xl cursor-pointer relative"
        >
          <Film className="w-4 h-4 text-purple-400" />
          <span>Highlight Reels</span>
          {savedClips.length > 0 && (
            <span className="bg-purple-500 text-white px-1.5 py-0.2 rounded-full text-[10px] font-bold">
              {savedClips.length}
            </span>
          )}
        </button>

        <button
          onClick={toggleFullscreen}
          className="p-2.5 rounded-xl bg-slate-900/85 backdrop-blur-md border border-white/15 text-slate-300 hover:text-white transition-all shadow-xl cursor-pointer"
          title={isFullscreen ? "Exit Fullscreen" : "Fullscreen View"}
        >
          <Maximize2 className="w-4 h-4" />
        </button>
      </div>

      {/* Floating Event Selector Panel */}
      {showEventSelector && (
        <div className="absolute top-36 left-4 z-30 w-80 max-h-[70vh] overflow-y-auto">
          <EventSelector
            activeEvent={activeEvent}
            onSelectEvent={handleSelectEvent}
          />
        </div>
      )}

      {/* Floating Right Leaderboard Drawer */}
      {showLeaderboard && (
        <div className="absolute top-24 right-4 z-20 w-80 max-h-[60vh] overflow-y-auto">
          <PhotofinishLeaderboard
            event={activeEvent}
            simTimeMs={simTimeMs}
            isSimulating={isSimulating}
            telemetryValue={telemetryValue}
          />
        </div>
      )}

      {/* Gemini Live Stadium Commentary Ticker */}
      <div className="absolute bottom-40 sm:bottom-36 left-1/2 -translate-x-1/2 z-20 w-[94%] max-w-2xl pointer-events-auto">
        <LiveCommentaryTicker
          event={activeEvent}
          activePhase={activePhase}
          telemetryValue={telemetryValue}
          simTimeMs={simTimeMs}
          isSimulating={isSimulating}
        />
      </div>

      {/* Bottom Main Simulation Controls Bar */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-20 w-[94%] max-w-3xl">
        <SimulationControls
          isSimulating={isSimulating}
          simSpeed={simSpeed}
          activePhase={activePhase}
          telemetryValue={telemetryValue}
          simTimeMs={simTimeMs}
          unitLabel={activeEvent.discipline === 'long-jump' ? 'm' : 'm'}
          cameraPresets={cameraPresets}
          activePresetId={activePresetId}
          isControlsExpanded={isControlsExpanded}
          isReplaying={isReplaying}
          replayProgressRatio={replayProgressRatio}
          hasRecordedTelemetry={recordedTelemetryLog.length > 0}
          replaySpeed={replaySpeed}
          isRecording={isRecording}
          recordingDurationMs={recordingDurationMs}
          savedClipsCount={savedClips.length}
          onTogglePlay={() => setIsSimulating(!isSimulating)}
          onStartPreparation={() => {
            setIsReplaying(false);
            setRecordedTelemetryLog([]);
            setShowPrepModal(true);
          }}
          onSetSpeed={setSimSpeed}
          onSelectPreset={setActivePresetId}
          onToggleExpand={() => setIsControlsExpanded(!isControlsExpanded)}
          onToggleReplay={handleToggleReplay}
          onScrubReplay={handleScrubReplay}
          onStepReplay={handleStepReplay}
          onSetReplaySpeed={setReplaySpeed}
          onToggleRecording={handleToggleRecording}
          onQuick5sRecord={handleQuick5sRecord}
          onOpenHighlightsGallery={() => setShowHighlightsGallery(true)}
        />
      </div>

      {/* 13-Step Event Preparation Engine Modal */}
      {showPrepModal && (
        <PreparationEngineModal
          event={activeEvent}
          onClose={() => setShowPrepModal(false)}
          onStartSimulation={() => setIsSimulating(true)}
        />
      )}

      {/* Highlight Reels Gallery Modal */}
      {showHighlightsGallery && (
        <HighlightGalleryModal
          clips={savedClips}
          onClose={() => setShowHighlightsGallery(false)}
          onDeleteClip={handleDeleteClip}
          onTakeSnapshot={handleTakeSnapshot}
        />
      )}

      {/* Gemini 3.6 Flash AI System Monitor Sidebar */}
      {showAIMonitor && (
        <AIMonitoringPanel
          activeEvent={activeEvent}
          activeVenue={activeVenue}
          metrics={metrics}
          onClose={() => setShowAIMonitor(false)}
        />
      )}
    </div>
  );
}

