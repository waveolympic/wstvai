import React, { useState } from 'react';
import {
  Cpu,
  Activity,
  HardDrive,
  Layers,
  Send,
  X,
  Wrench,
  Bot
} from 'lucide-react';
import { OlympicEvent, AIMonitorMetrics, VenueMetadata } from '../../types/olympics';
import { GeminiIntelligenceCore } from '../../services/geminiService';
import { OFFICIAL_VENUES } from '../../data/officialEvents';

interface Props {
  activeEvent: OlympicEvent;
  activeVenue: VenueMetadata;
  metrics: AIMonitorMetrics;
  onClose: () => void;
}

export const AIMonitoringPanel: React.FC<Props> = ({
  activeEvent,
  activeVenue,
  metrics,
  onClose,
}) => {
  const [userQuery, setUserQuery] = useState<string>('');
  const [aiResponses, setAiResponses] = useState<{ sender: 'user' | 'gemini'; text: string }[]>([
    {
      sender: 'gemini',
      text: `Hello! I am Google Gemini 3.6 Flash, the permanent intelligence core of WAVESPORTS AI. Venue "${activeVenue.name}" (${activeVenue.zipFile}) is fully loaded and operating at ${metrics.gpuFps} FPS. How can I assist with simulation diagnostics?`,
    },
  ]);
  const [isQuerying, setIsQuerying] = useState<boolean>(false);

  const handleSendQuery = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userQuery.trim() || isQuerying) return;

    const queryText = userQuery.trim();
    setUserQuery('');
    setAiResponses((prev) => [...prev, { sender: 'user', text: queryText }]);
    setIsQuerying(true);

    try {
      const answer = await GeminiIntelligenceCore.queryGeminiDiagnostics(queryText, metrics, activeEvent);
      setAiResponses((prev) => [...prev, { sender: 'gemini', text: answer }]);
    } catch (err) {
      setAiResponses((prev) => [
        ...prev,
        { sender: 'gemini', text: `[Gemini AI Error] Telemetry query processed with fallback logic.` },
      ]);
    } finally {
      setIsQuerying(false);
    }
  };

  const dormantVenues = Object.values(OFFICIAL_VENUES).filter(v => v.id !== activeVenue.id);

  return (
    <div className="fixed inset-y-0 right-0 z-50 w-full max-w-md bg-slate-900/95 backdrop-blur-2xl border-l border-white/15 p-5 shadow-2xl flex flex-col justify-between space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-white/10 pb-3 shrink-0">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-sky-500/20 border border-sky-400/40 flex items-center justify-center text-sky-400">
            <Cpu className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              Gemini 3.6 Flash Monitor
            </h2>
            <p className="text-[11px] text-slate-400">WAVESPORTS AI Telemetry & Diagnostics</p>
          </div>
        </div>
        <button
          onClick={onClose}
          className="p-1 rounded-xl hover:bg-white/10 text-slate-400 hover:text-white cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Main Scrollable Content */}
      <div className="flex-1 overflow-y-auto space-y-4 pr-1">
        {/* Real-time Hardware & Performance Metrics */}
        <div className="grid grid-cols-2 gap-2.5">
          <div className="bg-slate-950 p-3 rounded-2xl border border-white/5 space-y-1">
            <span className="text-[10px] text-slate-400 font-bold uppercase flex items-center gap-1">
              <Activity className="w-3 h-3 text-emerald-400" />
              Frame Performance
            </span>
            <div className="text-lg font-black font-mono text-emerald-400">
              {metrics.gpuFps} <span className="text-xs font-normal text-slate-400">FPS</span>
            </div>
            <p className="text-[10px] text-slate-400">Target: 60 FPS • {metrics.gpuFrameTimeMs.toFixed(1)}ms/frame</p>
          </div>

          <div className="bg-slate-950 p-3 rounded-2xl border border-white/5 space-y-1">
            <span className="text-[10px] text-slate-400 font-bold uppercase flex items-center gap-1">
              <HardDrive className="w-3 h-3 text-sky-400" />
              Memory & VRAM
            </span>
            <div className="text-lg font-black font-mono text-sky-400">
              {metrics.vramUsageMb} <span className="text-xs font-normal text-slate-400">MB</span>
            </div>
            <p className="text-[10px] text-slate-400">RAM: {metrics.ramUsageMb} MB Allocated</p>
          </div>
        </div>

        {/* Automatic Asset Optimization Status */}
        <div className="bg-slate-950 p-3.5 rounded-2xl border border-white/5 space-y-2 text-xs">
          <div className="flex items-center justify-between">
            <span className="font-bold text-slate-200 flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-sky-400" />
              Venue Asset Manager
            </span>
            <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/20">
              OPTIMIZED
            </span>
          </div>

          <div className="space-y-1 text-[11px] text-slate-300">
            <div className="flex justify-between">
              <span className="text-slate-400">Active Loaded ZIP:</span>
              <span className="font-mono text-sky-300">{activeVenue.zipFile}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Dormant Venues:</span>
              <span className="font-mono text-slate-400">{dormantVenues.length} (Unloaded)</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Rendered Meshes:</span>
              <span className="font-mono text-white">{metrics.active3DMeshCount}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Active Vertices:</span>
              <span className="font-mono text-white">{metrics.activeVerticesCount.toLocaleString()}</span>
            </div>
          </div>
        </div>

        {/* 9-Point Subsystem Health Checks */}
        <div className="bg-slate-950 p-3.5 rounded-2xl border border-white/5 space-y-2 text-xs">
          <span className="font-bold text-slate-200 block">Subsystem Telemetry Health</span>
          <div className="grid grid-cols-3 gap-1.5">
            {Object.entries(metrics.subsystemsHealth).map(([key, value]) => (
              <div
                key={key}
                className="p-2 rounded-xl bg-slate-900 border border-white/5 flex flex-col items-center justify-center text-center"
              >
                <span className="text-[9px] uppercase font-mono text-slate-400 line-clamp-1">{key}</span>
                <span className="text-[10px] font-bold text-emerald-400 mt-0.5">OPTIMAL</span>
              </div>
            ))}
          </div>
        </div>

        {/* Gemini AI Interactive Chat */}
        <div className="space-y-2">
          <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
            <Bot className="w-4 h-4 text-sky-400" />
            Gemini 3.6 Flash AI Terminal
          </span>

          <div className="bg-slate-950 rounded-2xl p-3 border border-white/10 space-y-2.5 max-h-56 overflow-y-auto font-sans text-xs">
            {aiResponses.map((msg, idx) => (
              <div
                key={idx}
                className={`p-2.5 rounded-xl text-xs leading-relaxed ${
                  msg.sender === 'user'
                    ? 'bg-sky-500/20 text-sky-100 ml-6 border border-sky-400/30 font-medium'
                    : 'bg-slate-900 text-slate-200 mr-4 border border-white/5'
                }`}
              >
                {msg.text}
              </div>
            ))}
            {isQuerying && (
              <div className="p-2.5 rounded-xl bg-slate-900 text-sky-400 animate-pulse text-xs">
                Gemini 3.6 Flash analyzing telemetry...
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Query Form Footer */}
      <form onSubmit={handleSendQuery} className="pt-2 shrink-0">
        <div className="flex items-center gap-2">
          <input
            type="text"
            value={userQuery}
            onChange={(e) => setUserQuery(e.target.value)}
            placeholder="Ask Gemini 3.6 Flash for diagnostics..."
            className="flex-1 bg-slate-950 border border-white/10 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-sky-400"
          />
          <button
            type="submit"
            disabled={isQuerying || !userQuery.trim()}
            className="p-2 bg-sky-500 hover:bg-sky-400 disabled:bg-slate-800 text-slate-950 rounded-xl transition-all cursor-pointer font-bold"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </form>
    </div>
  );
};
