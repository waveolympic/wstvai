import React from 'react';
import { Trophy, ShieldCheck, Activity, Cpu } from 'lucide-react';
import { OlympicEvent, VenueMetadata } from '../../types/olympics';

interface Props {
  activeEvent: OlympicEvent;
  activeVenue: VenueMetadata;
  isSimulating: boolean;
  onOpenValidationModal: () => void;
  onOpenAIMonitor: () => void;
}

export const HeaderBranding: React.FC<Props> = ({
  activeEvent,
  activeVenue,
  isSimulating,
  onOpenValidationModal,
  onOpenAIMonitor,
}) => {
  return (
    <header className="absolute top-4 left-4 right-4 z-20 flex flex-wrap items-center justify-between gap-3 pointer-events-none">
      {/* Left: Branding & Competition Badge */}
      <div className="flex items-center gap-3 bg-slate-900/85 backdrop-blur-xl px-4 py-3 rounded-2xl border border-white/15 shadow-2xl pointer-events-auto">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-sky-500 via-blue-600 to-emerald-400 flex items-center justify-center text-slate-950 font-bold shadow-lg shrink-0">
          <Trophy className="w-5 h-5 text-white" />
        </div>
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-base font-black tracking-wide text-white uppercase font-sans">
              WAVESPORTS AI
            </h1>
            <span className="text-[10px] font-bold tracking-wider px-2 py-0.5 rounded-md bg-sky-500/20 text-sky-300 border border-sky-400/30 uppercase">
              Gemini 3.6 Flash Core
            </span>
          </div>
          <p className="text-xs text-slate-300 font-medium">
            1st Pacifica Regional Olympics • {activeEvent.name}
          </p>
        </div>
      </div>

      {/* Right: Quick Action Buttons & Status Indicators */}
      <div className="flex items-center gap-2.5 pointer-events-auto">
        {/* Active Venue Badge */}
        <div className="hidden sm:flex items-center gap-2 px-3 py-2 rounded-xl bg-slate-900/80 backdrop-blur-md border border-white/10 text-xs text-slate-300 shadow-xl">
          <span className="w-2 h-2 rounded-full bg-emerald-400" />
          <span className="font-semibold text-slate-200">{activeVenue.name}</span>
          <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 font-mono">
            {activeVenue.zipFile}
          </span>
        </div>

        {/* 13-Step Validation Checklist Button */}
        <button
          onClick={onOpenValidationModal}
          className="flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-emerald-500/20 border border-emerald-400/50 text-emerald-200 hover:bg-emerald-500/30 transition-all shadow-xl cursor-pointer text-xs font-bold"
        >
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span className="hidden md:inline">Prep Checklist</span>
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
        </button>

        {/* AI System Monitor Toggle Button */}
        <button
          onClick={onOpenAIMonitor}
          className={`flex items-center gap-2 px-3.5 py-2.5 rounded-xl backdrop-blur-md border transition-all shadow-xl cursor-pointer text-xs font-bold ${
            isSimulating
              ? 'bg-sky-500/25 border-sky-400/60 text-sky-200 hover:bg-sky-500/35 shadow-sky-500/20'
              : 'bg-slate-900/80 border-white/15 text-slate-200 hover:bg-slate-800/80'
          }`}
        >
          <Cpu className="w-4 h-4 text-sky-400" />
          <span>AI Monitor</span>
          <Activity className="w-3.5 h-3.5 text-sky-400 animate-pulse" />
        </button>
      </div>
    </header>
  );
};
