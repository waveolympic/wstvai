import React from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  Camera,
  FastForward,
  Activity,
  ChevronUp,
  ChevronDown,
  Video,
  Circle,
  Film,
  SkipBack,
  SkipForward,
  Sparkles,
  SlidersHorizontal,
} from 'lucide-react';
import { CameraPreset } from '../../venues/VenueManager';

interface Props {
  isSimulating: boolean;
  simSpeed: number;
  activePhase: string;
  telemetryValue: number;
  simTimeMs: number;
  unitLabel: string; // 'm' or 's'
  cameraPresets: CameraPreset[];
  activePresetId: string;
  isControlsExpanded: boolean;
  // Replay Props
  isReplaying: boolean;
  replayProgressRatio: number;
  hasRecordedTelemetry: boolean;
  replaySpeed: number;
  // Recording Props
  isRecording: boolean;
  recordingDurationMs: number;
  savedClipsCount: number;
  // Callbacks
  onTogglePlay: () => void;
  onStartPreparation: () => void;
  onSetSpeed: (speed: number) => void;
  onSelectPreset: (presetId: string) => void;
  onToggleExpand: () => void;
  // Replay Callbacks
  onToggleReplay: () => void;
  onScrubReplay: (ratio: number) => void;
  onStepReplay: (deltaRatio: number) => void;
  onSetReplaySpeed: (speed: number) => void;
  // Recording Callbacks
  onToggleRecording: () => void;
  onQuick5sRecord: () => void;
  onOpenHighlightsGallery: () => void;
}

export const SimulationControls: React.FC<Props> = ({
  isSimulating,
  simSpeed,
  activePhase,
  telemetryValue,
  simTimeMs,
  unitLabel,
  cameraPresets,
  activePresetId,
  isControlsExpanded,
  isReplaying,
  replayProgressRatio,
  hasRecordedTelemetry,
  replaySpeed,
  isRecording,
  recordingDurationMs,
  savedClipsCount,
  onTogglePlay,
  onStartPreparation,
  onSetSpeed,
  onSelectPreset,
  onToggleExpand,
  onToggleReplay,
  onScrubReplay,
  onStepReplay,
  onSetReplaySpeed,
  onToggleRecording,
  onQuick5sRecord,
  onOpenHighlightsGallery,
}) => {
  const formatTime = (ms: number) => {
    const totalSec = ms / 1000;
    const mins = Math.floor(totalSec / 60);
    const secs = (totalSec % 60).toFixed(2);
    return `${mins > 0 ? `${mins}:` : ''}${secs.padStart(5, '0')}s`;
  };

  const formatRecTime = (ms: number) => {
    const totalSec = Math.floor(ms / 1000);
    const mins = Math.floor(totalSec / 60);
    const secs = totalSec % 60;
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  return (
    <div className="bg-slate-900/90 backdrop-blur-xl border border-white/15 rounded-3xl p-4 shadow-2xl transition-all duration-300 space-y-3 font-sans">
      {/* Header Bar */}
      <div className="flex items-center justify-between border-b border-white/10 pb-3 flex-wrap gap-2">
        <div className="flex items-center gap-2">
          {/* Start Event Button */}
          <button
            onClick={onStartPreparation}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-gradient-to-r from-emerald-400 to-sky-500 hover:from-emerald-300 hover:to-sky-400 text-slate-950 font-black text-xs shadow-lg shadow-sky-500/20 cursor-pointer"
          >
            <Play className="w-4 h-4 fill-current" />
            <span>START EVENT</span>
          </button>

          {/* Pause / Play Toggle */}
          <button
            onClick={onTogglePlay}
            className="p-2 rounded-xl bg-slate-950/60 border border-white/10 text-slate-200 hover:text-white cursor-pointer"
            title={isSimulating ? "Pause Simulation" : "Resume Simulation"}
          >
            {isSimulating ? <Pause className="w-4 h-4 text-amber-400" /> : <Play className="w-4 h-4 text-emerald-400" />}
          </button>

          {/* Replay Mode Toggle Button */}
          <button
            onClick={onToggleReplay}
            disabled={!hasRecordedTelemetry && !isReplaying}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
              isReplaying
                ? 'bg-purple-500 text-white border-purple-400 shadow-lg shadow-purple-500/30'
                : hasRecordedTelemetry
                ? 'bg-slate-950/60 border-purple-500/40 text-purple-300 hover:bg-purple-500/20'
                : 'bg-slate-950/30 border-white/5 text-slate-600 cursor-not-allowed'
            }`}
            title={
              isReplaying
                ? "Exit Replay Mode"
                : hasRecordedTelemetry
                ? "Replay Last Event Simulation"
                : "Run a simulation first to store telemetry for replay"
            }
          >
            <RotateCcw className={`w-3.5 h-3.5 ${isReplaying ? 'animate-spin' : ''}`} />
            <span>{isReplaying ? 'EXIT REPLAY' : 'REPLAY EVENT'}</span>
          </button>

          {/* Highlight Recording Toggle */}
          <button
            onClick={onToggleRecording}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
              isRecording
                ? 'bg-red-500/20 border-red-500 text-red-400 animate-pulse shadow-lg shadow-red-500/20'
                : 'bg-slate-950/60 border-white/10 text-slate-300 hover:bg-slate-800'
            }`}
            title={isRecording ? "Stop Recording Highlight" : "Record Simulation Video Highlight"}
          >
            <Circle className={`w-3.5 h-3.5 fill-current ${isRecording ? 'text-red-500 animate-ping' : 'text-slate-400'}`} />
            <span>{isRecording ? `REC [${formatRecTime(recordingDurationMs)}]` : 'REC HIGHLIGHT'}</span>
          </button>

          {/* Highlights Gallery Button */}
          <button
            onClick={onOpenHighlightsGallery}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-950/60 hover:bg-slate-800 border border-white/10 text-slate-200 text-xs font-bold transition-all cursor-pointer relative"
            title="Open Recorded Highlights Gallery"
          >
            <Film className="w-3.5 h-3.5 text-sky-400" />
            <span className="hidden sm:inline">REELS</span>
            {savedClipsCount > 0 && (
              <span className="bg-sky-500 text-slate-950 px-1.5 py-0.2 rounded-full text-[10px] font-bold">
                {savedClipsCount}
              </span>
            )}
          </button>
        </div>

        {/* Real-time Telemetry Clock */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-950/70 border border-white/10 font-mono text-xs">
            <Activity className="w-3.5 h-3.5 text-sky-400" />
            <span className="text-slate-400 text-[10px] uppercase font-sans">CLOCK:</span>
            <span className="font-bold text-sky-300">{formatTime(simTimeMs)}</span>
          </div>

          <div className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-950/70 border border-white/10 text-xs">
            <span className="text-slate-400 text-[10px] uppercase">DIST/VAL:</span>
            <span className="font-bold font-mono text-emerald-300">
              {telemetryValue} {unitLabel}
            </span>
          </div>

          <button
            onClick={onToggleExpand}
            className="text-slate-400 hover:text-white p-1.5 rounded-xl hover:bg-white/5 transition-colors cursor-pointer"
          >
            {isControlsExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Replay Mode Telemetry Scrubber Bar */}
      {isReplaying && (
        <div className="p-3 bg-purple-950/40 border border-purple-500/40 rounded-2xl space-y-2 animate-in fade-in duration-200">
          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-purple-400 animate-ping" />
              <span className="font-bold text-purple-200 text-xs flex items-center gap-1.5">
                SLOW-MOTION REPLAY ANALYZER
                <span className="text-[10px] bg-purple-500/30 text-purple-300 px-2 py-0.5 rounded-full font-mono border border-purple-400/30">
                  {replaySpeed}x Speed
                </span>
              </span>
            </div>

            {/* Slow-mo Speed Selectors */}
            <div className="flex items-center bg-slate-950 p-1 rounded-lg border border-purple-500/30 text-[11px] gap-1">
              {[0.25, 0.5, 1.0].map((spd) => (
                <button
                  key={spd}
                  onClick={() => onSetReplaySpeed(spd)}
                  className={`px-2 py-0.5 rounded font-mono font-bold transition-all cursor-pointer ${
                    replaySpeed === spd
                      ? 'bg-purple-500 text-white shadow'
                      : 'text-slate-400 hover:text-purple-200'
                  }`}
                >
                  {spd}x
                </button>
              ))}
            </div>
          </div>

          {/* Timeline Scrubber Slider */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => onStepReplay(-0.02)}
              className="p-1.5 rounded-lg bg-slate-950/80 border border-white/10 text-slate-300 hover:text-white transition-colors cursor-pointer"
              title="Step Back 2%"
            >
              <SkipBack className="w-3.5 h-3.5" />
            </button>

            <input
              type="range"
              min={0}
              max={1}
              step={0.005}
              value={replayProgressRatio}
              onChange={(e) => onScrubReplay(parseFloat(e.target.value))}
              className="w-full accent-purple-400 cursor-pointer h-2 bg-slate-950 rounded-lg"
            />

            <button
              onClick={() => onStepReplay(0.02)}
              className="p-1.5 rounded-lg bg-slate-950/80 border border-white/10 text-slate-300 hover:text-white transition-colors cursor-pointer"
              title="Step Forward 2%"
            >
              <SkipForward className="w-3.5 h-3.5" />
            </button>

            <span className="font-mono text-xs text-purple-300 font-bold shrink-0 min-w-[45px] text-right">
              {Math.round(replayProgressRatio * 100)}%
            </span>
          </div>
        </div>
      )}

      {/* Expanded Controls Drawer */}
      {isControlsExpanded && (
        <div className="space-y-3.5 pt-1">
          {/* Active Phase Badge & Speed Selector */}
          <div className="flex items-center justify-between px-3 py-2 rounded-xl bg-slate-950/60 border border-white/5 text-xs flex-wrap gap-2">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-sky-400 animate-pulse" />
              <span className="text-slate-400 font-medium text-[11px]">ACTIVE PHASE:</span>
              <span className="font-bold text-white">{activePhase}</span>
            </div>
            {/* Speed Multipliers for Live Sim */}
            {!isReplaying && (
              <div className="flex items-center bg-slate-900 p-0.5 rounded-lg border border-white/10 text-[11px]">
                {[0.5, 1.0, 2.0].map((spd) => (
                  <button
                    key={spd}
                    onClick={() => onSetSpeed(spd)}
                    className={`px-2 py-0.5 rounded font-mono font-bold transition-all cursor-pointer ${
                      simSpeed === spd
                        ? 'bg-sky-500 text-slate-950 shadow'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {spd}x
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Camera View Selector Pills */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-[11px] font-bold text-slate-300 uppercase tracking-wider">
              <div className="flex items-center gap-1.5">
                <Camera className="w-3.5 h-3.5 text-sky-400" />
                <span>Broadcast Viewpoints</span>
              </div>
              <button
                onClick={onQuick5sRecord}
                className="flex items-center gap-1 text-purple-300 hover:text-purple-200 text-[10px] font-normal cursor-pointer"
                title="Capture quick 5-second highlight video"
              >
                <Sparkles className="w-3 h-3 text-amber-400" />
                <span>Quick 5s Clip</span>
              </button>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {cameraPresets.map((preset) => {
                const isActive = activePresetId === preset.id;
                return (
                  <button
                    key={preset.id}
                    onClick={() => onSelectPreset(preset.id)}
                    className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                      isActive
                        ? 'bg-sky-500/25 border-sky-400 text-white font-bold shadow-md shadow-sky-500/10'
                        : 'bg-slate-950/40 border-white/5 text-slate-300 hover:bg-slate-800/60'
                    }`}
                  >
                    <div className="text-xs font-bold line-clamp-1">{preset.label}</div>
                    <div className="text-[10px] text-slate-400 line-clamp-1 mt-0.5 font-normal">
                      {preset.description}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

