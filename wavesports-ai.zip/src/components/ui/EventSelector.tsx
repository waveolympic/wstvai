import React from 'react';
import { Layers, CheckCircle2, MapPin } from 'lucide-react';
import { OlympicEvent, VenueId } from '../../types/olympics';
import { OFFICIAL_EVENTS, OFFICIAL_VENUES } from '../../data/officialEvents';

interface Props {
  activeEvent: OlympicEvent;
  onSelectEvent: (event: OlympicEvent) => void;
}

export const EventSelector: React.FC<Props> = ({ activeEvent, onSelectEvent }) => {
  const venues: { id: VenueId; label: string; zip: string }[] = [
    { id: 'klemonserrat', label: 'Klemonserrat Olympic Stadium', zip: 'klemonserrat-olympic-stadium.zip' },
    { id: 'skatbaen', label: 'Skatbaen Athletics Stadium', zip: 'skatbaen-stadium-3d.zip' },
    { id: 'vlaskovich', label: 'Vlaskovich Indoor Arena', zip: 'vlaskovich-indoor-arena-3d.zip' },
  ];

  return (
    <div className="bg-slate-900/85 backdrop-blur-xl border border-white/15 rounded-2xl p-4 shadow-2xl space-y-3">
      <div className="flex items-center justify-between border-b border-white/10 pb-2.5">
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-slate-200">
          <Layers className="w-4 h-4 text-sky-400" />
          <span>Intelligent Event Selector</span>
        </div>
        <span className="text-[11px] font-semibold text-emerald-400 bg-emerald-500/15 px-2 py-0.5 rounded border border-emerald-500/30">
          Auto Venue Mapping
        </span>
      </div>

      <div className="space-y-4">
        {venues.map((venue) => {
          const eventsInVenue = OFFICIAL_EVENTS.filter(e => e.venueId === venue.id);
          const isCurrentVenue = activeEvent.venueId === venue.id;

          return (
            <div key={venue.id} className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5 text-xs font-bold text-slate-300">
                  <MapPin className="w-3.5 h-3.5 text-sky-400" />
                  <span>{venue.label}</span>
                </div>
                <span className="text-[10px] font-mono text-slate-400 bg-slate-950 px-2 py-0.5 rounded border border-white/5">
                  {venue.zip}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2">
                {eventsInVenue.map((evt) => {
                  const isSelected = activeEvent.id === evt.id;
                  return (
                    <button
                      key={evt.id}
                      onClick={() => onSelectEvent(evt)}
                      className={`flex items-center justify-between p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-sky-500/25 border-sky-400 text-white shadow-lg shadow-sky-500/10 font-bold'
                          : 'bg-slate-950/40 border-white/5 text-slate-300 hover:bg-slate-800/60 hover:border-white/15'
                      }`}
                    >
                      <div className="flex items-center gap-2 text-xs">
                        {isSelected ? (
                          <CheckCircle2 className="w-4 h-4 text-sky-400 shrink-0" />
                        ) : (
                          <span className="w-2 h-2 rounded-full bg-slate-600 shrink-0" />
                        )}
                        <span className="line-clamp-1">{evt.name}</span>
                      </div>
                      <span className="text-[10px] uppercase font-mono text-slate-400 bg-slate-900 px-1.5 py-0.5 rounded shrink-0">
                        {evt.discipline}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
