import React, { useEffect, useState, useRef } from 'react';
import { Mic, Volume2, VolumeX, Sparkles, RefreshCw, Radio, Zap } from 'lucide-react';
import { OlympicEvent } from '../../types/olympics';
import { GeminiIntelligenceCore } from '../../services/geminiService';

interface Props {
  event: OlympicEvent;
  activePhase: string;
  telemetryValue: number;
  simTimeMs: number;
  isSimulating: boolean;
}

export const LiveCommentaryTicker: React.FC<Props> = ({
  event,
  activePhase,
  telemetryValue,
  simTimeMs,
  isSimulating,
}) => {
  const [commentary, setCommentary] = useState<string>('');
  const [isFetching, setIsFetching] = useState<boolean>(false);
  const [isAudioMuted, setIsAudioMuted] = useState<boolean>(true);
  const lastPhaseRef = useRef<string>('');

  // Fetch commentary when phase changes or event changes
  useEffect(() => {
    if (activePhase !== lastPhaseRef.current || commentary === '') {
      lastPhaseRef.current = activePhase;
      fetchCommentary();
    }
  }, [activePhase, event.id]);

  const fetchCommentary = async () => {
    setIsFetching(true);
    try {
      const text = await GeminiIntelligenceCore.generateEventCommentary(
        event,
        activePhase,
        telemetryValue,
        simTimeMs
      );
      setCommentary(text);

      // Text to speech if unmuted
      if (!isAudioMuted && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
        const cleanText = text.replace(/\[.*?\]/g, '');
        const utterance = new SpeechSynthesisUtterance(cleanText);
        utterance.rate = 1.05;
        utterance.pitch = 1.0;
        window.speechSynthesis.speak(utterance);
      }
    } catch (err) {
      console.warn('Commentary fetch error:', err);
    } finally {
      setIsFetching(false);
    }
  };

  const toggleAudio = () => {
    const newMuteState = !isAudioMuted;
    setIsAudioMuted(newMuteState);
    if (newMuteState && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
  };

  return (
    <div className="bg-slate-900/90 backdrop-blur-xl border border-sky-500/30 rounded-2xl p-3 shadow-2xl space-y-2 max-w-xl mx-auto font-sans">
      {/* Top Bar */}
      <div className="flex items-center justify-between text-xs">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-lg bg-sky-500/20 border border-sky-400/40 flex items-center justify-center text-sky-400">
            <Radio className="w-3.5 h-3.5 animate-pulse" />
          </div>
          <span className="font-bold text-white uppercase tracking-wider text-[11px] flex items-center gap-1.5">
            Gemini Live Stadium Commentary
            <span className="text-[9px] bg-sky-500/20 text-sky-300 px-1.5 py-0.5 rounded font-mono">
              3.6 Flash
            </span>
          </span>
        </div>

        <div className="flex items-center gap-2">
          {/* Audio TTS Toggle */}
          <button
            onClick={toggleAudio}
            className={`p-1.5 rounded-lg border text-xs font-semibold transition-all cursor-pointer ${
              !isAudioMuted
                ? 'bg-emerald-500/20 border-emerald-400 text-emerald-300'
                : 'bg-slate-950/60 border-white/10 text-slate-400 hover:text-white'
            }`}
            title={isAudioMuted ? "Enable PA Voice Audio" : "Mute PA Voice"}
          >
            {!isAudioMuted ? <Volume2 className="w-3.5 h-3.5 text-emerald-400" /> : <VolumeX className="w-3.5 h-3.5" />}
          </button>

          {/* Regenerate commentary */}
          <button
            onClick={fetchCommentary}
            disabled={isFetching}
            className="p-1.5 rounded-lg bg-slate-950/60 hover:bg-slate-800 border border-white/10 text-slate-300 hover:text-white transition-all cursor-pointer"
            title="Generate Fresh Commentary"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isFetching ? 'animate-spin text-sky-400' : ''}`} />
          </button>
        </div>
      </div>

      {/* Main Commentary Body */}
      <div className="bg-slate-950 p-2.5 rounded-xl border border-white/5 relative overflow-hidden">
        <div className="flex items-start gap-2.5">
          <Mic className="w-4 h-4 text-sky-400 shrink-0 mt-0.5 animate-bounce" />
          <p className="text-xs text-slate-200 leading-relaxed font-medium italic">
            {isFetching ? (
              <span className="text-sky-400 animate-pulse font-sans not-italic">
                Gemini 3.6 Flash analyzing athlete biomechanics and generating play-by-play commentary...
              </span>
            ) : (
              commentary || `[GEMINI AI COMMENTARY] Athletes ready for ${event.name} at ${event.venueName}.`
            )}
          </p>
        </div>
      </div>
    </div>
  );
};
