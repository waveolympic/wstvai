import React, { useState } from 'react';
import { Video, X, Download, Trash2, Play, Calendar, Film, Sparkles, Award, Camera } from 'lucide-react';
import { HighlightClip } from '../../types/olympics';

interface Props {
  clips: HighlightClip[];
  onClose: () => void;
  onDeleteClip: (id: string) => void;
  onTakeSnapshot: () => void;
}

export const HighlightGalleryModal: React.FC<Props> = ({
  clips = [],
  onClose,
  onDeleteClip,
  onTakeSnapshot,
}) => {
  const [selectedClipId, setSelectedClipId] = useState<string | null>(
    clips && clips.length > 0 ? clips[0]?.id || null : null
  );

  const selectedClip = (clips && clips.length > 0)
    ? (clips.find((c) => c && c.id === selectedClipId) || clips[0])
    : null;

  const formatDuration = (ms: number = 0) => {
    const sec = ((ms || 0) / 1000).toFixed(1);
    return `${sec}s`;
  };

  const handleDownload = (clip: HighlightClip) => {
    if (!clip) return;
    const safeTitle = (clip.title || 'highlight').replace(/\s+/g, '_');
    if (clip.videoBlobUrl) {
      const a = document.createElement('a');
      a.href = clip.videoBlobUrl;
      a.download = `${safeTitle}_highlight.webm`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    } else if (clip.snapshotDataUrl) {
      const a = document.createElement('a');
      a.href = clip.snapshotDataUrl;
      a.download = `${safeTitle}_photofinish.png`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-sky-500/30 rounded-3xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden font-sans">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-white/10 bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-purple-500 to-sky-500 p-0.5 shadow-lg shadow-purple-500/20">
              <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center text-sky-400">
                <Film className="w-5 h-5 animate-pulse" />
              </div>
            </div>
            <div>
              <h2 className="text-lg font-black text-white flex items-center gap-2">
                Olympic Highlight Reels & Replays
                <span className="text-xs font-mono bg-purple-500/20 text-purple-300 px-2 py-0.5 rounded-full border border-purple-400/30">
                  HD Recording
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Review recorded video clips, slow-mo telemetry logs, and photofinish captures.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onTakeSnapshot}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-sky-500/20 hover:bg-sky-500/30 border border-sky-400/40 text-sky-300 font-bold text-xs transition-all cursor-pointer"
            >
              <Camera className="w-4 h-4" />
              <span>Snapshot Frame</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Content */}
        <div className="flex-1 overflow-y-auto p-6 grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Video/Snapshot Display */}
          <div className="lg:col-span-2 space-y-4">
            {selectedClip ? (
              <div className="bg-slate-950 rounded-2xl border border-white/10 overflow-hidden shadow-2xl flex flex-col">
                <div className="relative aspect-video bg-black flex items-center justify-center overflow-hidden">
                  {selectedClip.videoBlobUrl ? (
                    <video
                      src={selectedClip.videoBlobUrl}
                      controls
                      autoPlay
                      loop
                      className="w-full h-full object-contain"
                    />
                  ) : selectedClip?.snapshotDataUrl ? (
                    <img
                      src={selectedClip.snapshotDataUrl}
                      alt={selectedClip?.title || 'Highlight'}
                      className="w-full h-full object-contain"
                    />
                  ) : (
                    <div className="text-slate-500 flex flex-col items-center gap-2">
                      <Film className="w-12 h-12 text-slate-600" />
                      <span>No media preview available</span>
                    </div>
                  )}

                  <div className="absolute top-3 left-3 bg-slate-950/80 backdrop-blur-md px-3 py-1 rounded-lg border border-white/10 text-[11px] font-bold text-sky-300 font-mono">
                    {selectedClip?.eventName || ''} • {selectedClip?.venueName || ''}
                  </div>
                </div>

                {/* Clip Meta Info */}
                <div className="p-4 space-y-3 bg-slate-900/90">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="font-black text-white text-base">{selectedClip?.title || 'Highlight Reel'}</h3>
                      <div className="flex items-center gap-3 text-xs text-slate-400 mt-1">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3.5 h-3.5 text-sky-400" />
                          {selectedClip.recordedAt}
                        </span>
                        <span>•</span>
                        <span className="font-mono text-emerald-400 font-bold">
                          Peak: {selectedClip.telemetryValue} {selectedClip.unitLabel}
                        </span>
                        <span>•</span>
                        <span className="font-mono text-purple-300">
                          Length: {formatDuration(selectedClip.durationMs)}
                        </span>
                      </div>
                    </div>

                    <button
                      onClick={() => handleDownload(selectedClip)}
                      className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-sky-500 to-purple-600 hover:from-sky-400 hover:to-purple-500 text-white font-bold text-xs shadow-lg cursor-pointer"
                    >
                      <Download className="w-4 h-4" />
                      <span>Download Clip</span>
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="h-64 rounded-2xl border-2 border-dashed border-white/10 flex flex-col items-center justify-center p-6 text-center text-slate-400">
                <Film className="w-12 h-12 text-slate-600 mb-2 animate-bounce" />
                <p className="font-bold text-slate-200">No Highlight Clips Recorded Yet</p>
                <p className="text-xs text-slate-400 mt-1 max-w-sm">
                  Click the red REC button during simulation or replay to capture broadcast video clips!
                </p>
              </div>
            )}
          </div>

          {/* Clips List Sidebar */}
          <div className="space-y-3 flex flex-col">
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center justify-between">
              <span>Saved Highlights ({clips.length})</span>
            </h4>

            <div className="space-y-2 flex-1 max-h-[480px] overflow-y-auto pr-1">
              {clips.length === 0 ? (
                <div className="p-4 rounded-xl bg-slate-950/50 border border-white/5 text-xs text-slate-500 text-center">
                  Your recorded highlights will appear here.
                </div>
              ) : (
                clips.map((clip) => {
                  const isSelected = selectedClipId === clip.id;
                  return (
                    <div
                      key={clip.id}
                      onClick={() => setSelectedClipId(clip.id)}
                      className={`p-3 rounded-2xl border transition-all cursor-pointer flex items-center justify-between group ${
                        isSelected
                          ? 'bg-sky-500/20 border-sky-400 text-white shadow-lg'
                          : 'bg-slate-950/60 border-white/5 text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-slate-900 border border-white/10 flex items-center justify-center shrink-0">
                          {clip.videoBlobUrl ? (
                            <Play className="w-4 h-4 text-sky-400 fill-sky-400/20" />
                          ) : (
                            <Camera className="w-4 h-4 text-purple-400" />
                          )}
                        </div>
                        <div className="min-w-0">
                          <h5 className="font-bold text-xs truncate text-white">{clip?.title || 'Highlight Clip'}</h5>
                          <p className="text-[11px] text-slate-400 truncate mt-0.5">
                            {clip?.eventName || ''} ({formatDuration(clip?.durationMs)})
                          </p>
                        </div>
                      </div>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onDeleteClip(clip.id);
                        }}
                        className="p-1.5 rounded-lg opacity-0 group-hover:opacity-100 text-slate-500 hover:text-red-400 hover:bg-red-500/10 transition-all"
                        title="Delete clip"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
