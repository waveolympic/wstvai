import React, { useEffect, useState } from 'react';
import {
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  X,
  Play,
  Cpu,
  Layers,
  Wrench
} from 'lucide-react';
import { OlympicEvent, ValidationStep } from '../../types/olympics';
import { GeminiIntelligenceCore } from '../../services/geminiService';
import { OFFICIAL_VENUES } from '../../data/officialEvents';

interface Props {
  event: OlympicEvent;
  onClose: () => void;
  onStartSimulation: () => void;
}

export const PreparationEngineModal: React.FC<Props> = ({
  event,
  onClose,
  onStartSimulation,
}) => {
  const [steps, setSteps] = useState<ValidationStep[]>([]);
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);
  const [isValidationComplete, setIsValidationComplete] = useState<boolean>(false);
  const [diagnosticLogs, setDiagnosticLogs] = useState<string[]>([]);
  const [isAutoRepairing, setIsAutoRepairing] = useState<boolean>(false);

  const venue = OFFICIAL_VENUES[event.venueId];

  useEffect(() => {
    const initialSteps = GeminiIntelligenceCore.generate13StepChecklist(event);
    setSteps(initialSteps);
    setDiagnosticLogs([
      `[Gemini AI Engine] Initializing 13-step preparation sequence for "${event.name}".`,
      `[Intelligent Venue Manager] Loading mandatory archive: "${venue?.zipFile}".`,
    ]);

    let idx = 0;
    const interval = setInterval(() => {
      if (idx < initialSteps.length) {
        setSteps((prev) =>
          prev.map((step, i) => {
            if (i === idx) {
              return { ...step, status: 'success' };
            }
            if (i === idx + 1) {
              return { ...step, status: 'running' };
            }
            return step;
          })
        );

        if (initialSteps[idx]) {
          setDiagnosticLogs((prev) => [
            ...prev,
            `[Validation Step ${idx + 1}/13 PASSED] ${initialSteps[idx]?.title || 'Step'} — Operational.`,
          ]);
        }

        idx++;
        setCurrentStepIndex(idx);
      } else {
        clearInterval(interval);
        setIsValidationComplete(true);
        setDiagnosticLogs((prev) => [
          ...prev,
          `[Gemini AI Engine] All 13 validation checks PASSED 100%. Environment verified for competition start!`,
        ]);
      }
    }, 280);

    return () => clearInterval(interval);
  }, [event.id]);

  const handleSimulateFault = () => {
    setIsAutoRepairing(true);
    setDiagnosticLogs((prev) => [
      ...prev,
      `[SIMULATED ANOMALY DETECTED] Missing UV bump texture map on starting block #4.`,
      `[Gemini Auto-Repair] Generating procedural replacement texture map...`,
      `[Gemini Auto-Repair] Re-binding PBR material channels...`,
      `[Gemini Auto-Repair SUCCESS] Texture restored. Subsystem green.`,
    ]);

    setTimeout(() => {
      setIsAutoRepairing(false);
    }, 1200);
  };

  const progressPercent = Math.min(100, Math.round(((currentStepIndex + 1) / 13) * 100));

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-sky-500/30 rounded-3xl max-w-2xl w-full p-6 shadow-2xl space-y-5 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-white/10 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-sky-500/20 border border-sky-400/40 flex items-center justify-center text-sky-400">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                Event Preparation Engine
                <span className="text-[10px] uppercase font-mono bg-sky-500/20 text-sky-300 px-2 py-0.5 rounded border border-sky-400/30">
                  Gemini 3.6 Flash
                </span>
              </h2>
              <p className="text-xs text-slate-300 font-medium">
                {event.name} • Mandatory Venue Archive: <span className="text-white font-mono">{venue?.zipFile}</span>
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl hover:bg-white/10 text-slate-400 hover:text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Real-time Validation Progress Bar */}
        <div className="space-y-2 bg-slate-950 p-3.5 rounded-2xl border border-white/5">
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold text-slate-200 flex items-center gap-2">
              <Cpu className="w-4 h-4 text-sky-400" />
              Validation Sequence Progress
            </span>
            <span className="font-mono font-bold text-sky-400">{progressPercent}%</span>
          </div>
          <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden p-0.5 border border-white/5">
            <div
              className="bg-gradient-to-r from-sky-500 via-blue-500 to-emerald-400 h-full rounded-full transition-all duration-300 shadow-lg"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>

        {/* 13-Step Checklist Grid */}
        <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
          {steps.map((step) => {
            const isDone = step.status === 'success';
            const isRunning = step.status === 'running';

            return (
              <div
                key={step.id}
                className={`flex items-start gap-3 p-3 rounded-2xl border transition-all ${
                  isDone
                    ? 'bg-slate-950/60 border-emerald-500/30 text-slate-200'
                    : isRunning
                    ? 'bg-sky-500/10 border-sky-400/50 text-sky-200 animate-pulse'
                    : 'bg-slate-950/20 border-white/5 text-slate-500'
                }`}
              >
                {isDone ? (
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                ) : isRunning ? (
                  <RefreshCw className="w-5 h-5 text-sky-400 animate-spin shrink-0 mt-0.5" />
                ) : (
                  <div className="w-5 h-5 rounded-full border border-slate-700 flex items-center justify-center text-[10px] font-mono shrink-0 mt-0.5">
                    {step.id}
                  </div>
                )}
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xs font-bold text-slate-100">
                      Step {step?.id}: {step?.title || ''}
                    </h3>
                    <span className="text-[10px] font-mono uppercase bg-slate-900 px-1.5 py-0.5 rounded text-slate-400">
                      {step.subsystem}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-0.5 font-sans leading-relaxed">
                    {step.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Live Gemini Diagnostic Console Output */}
        <div className="bg-slate-950 rounded-2xl p-3 border border-white/10 font-mono text-[11px] space-y-1 text-slate-300 max-h-28 overflow-y-auto">
          <div className="flex items-center justify-between text-[10px] text-slate-400 font-bold uppercase border-b border-white/5 pb-1">
            <span>Gemini Telemetry Terminal</span>
            <span className="text-emerald-400">SYS_HEALTH: OPTIMAL</span>
          </div>
          {diagnosticLogs.map((log, idx) => (
            <div key={idx} className="leading-tight">
              {log}
            </div>
          ))}
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-between pt-2">
          <button
            onClick={handleSimulateFault}
            disabled={isAutoRepairing}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold cursor-pointer border border-white/10"
          >
            <Wrench className="w-3.5 h-3.5 text-amber-400" />
            <span>Test Auto-Repair</span>
          </button>

          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-slate-400 hover:text-white text-xs font-bold cursor-pointer"
            >
              Cancel
            </button>
            <button
              onClick={() => {
                onStartSimulation();
                onClose();
              }}
              disabled={!isValidationComplete}
              className={`flex items-center gap-2 px-6 py-2.5 rounded-xl font-bold text-xs shadow-lg transition-all cursor-pointer ${
                isValidationComplete
                  ? 'bg-gradient-to-r from-emerald-400 to-sky-500 hover:from-emerald-300 hover:to-sky-400 text-slate-950 shadow-emerald-500/20'
                  : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-white/5'
              }`}
            >
              <Play className="w-4 h-4 fill-current" />
              <span>Begin Official Simulation</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
