import React from 'react';
import { Trophy, Medal, Timer, Flag } from 'lucide-react';
import { OlympicEvent, Athlete } from '../../types/olympics';

interface Props {
  event: OlympicEvent;
  simTimeMs: number;
  isSimulating: boolean;
  telemetryValue: number;
}

export const PhotofinishLeaderboard: React.FC<Props> = ({
  event,
  simTimeMs,
  isSimulating,
  telemetryValue,
}) => {
  // Calculate dynamic live split time / finish projections
  const getSimulatedTime = (athlete: Athlete, idx: number) => {
    if (simTimeMs === 0) return athlete.seasonBest;

    // Add millisecond variance based on athlete seed rank
    const baseSec = (simTimeMs / 1000) + (idx * 0.04);
    if (event.distanceMeters <= 100) {
      return `${baseSec.toFixed(2)}s`;
    } else if (event.distanceMeters <= 400) {
      return `${baseSec.toFixed(2)}s`;
    } else if (event.discipline === 'long-jump') {
      const dist = Math.min(athlete.laneOrPosition * 1.2 + 6.8, 8.95);
      return `${dist.toFixed(2)}m`;
    } else {
      const mins = Math.floor(baseSec / 60);
      const secs = (baseSec % 60).toFixed(2);
      return `${mins > 0 ? `${mins}:` : ''}${secs.padStart(5, '0')}`;
    }
  };

  return (
    <div className="bg-slate-900/85 backdrop-blur-xl border border-white/15 rounded-2xl p-4 shadow-2xl space-y-3">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-white/10 pb-2.5">
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-slate-200">
          <Trophy className="w-4 h-4 text-amber-400" />
          <span>Photofinish Timing Gate</span>
        </div>
        <span className="text-[10px] font-mono text-slate-400 bg-slate-950 px-2 py-0.5 rounded border border-white/5">
          WR: {event.worldRecord}
        </span>
      </div>

      {/* Athletes Leaderboard List */}
      <div className="space-y-1.5 max-h-64 overflow-y-auto pr-1 font-sans">
        {event.athletes.map((athlete, idx) => {
          const isGold = idx === 0;
          const isSilver = idx === 1;
          const isBronze = idx === 2;

          return (
            <div
              key={athlete.id}
              className={`flex items-center justify-between p-2 rounded-xl border text-xs transition-all ${
                isGold
                  ? 'bg-amber-500/15 border-amber-400/40 text-amber-200 font-bold'
                  : isSilver
                  ? 'bg-slate-300/10 border-slate-300/30 text-slate-200 font-semibold'
                  : isBronze
                  ? 'bg-amber-700/15 border-amber-600/30 text-amber-300'
                  : 'bg-slate-950/40 border-white/5 text-slate-300'
              }`}
            >
              <div className="flex items-center gap-2.5">
                {/* Rank Badge */}
                <div
                  className={`w-5 h-5 rounded-lg flex items-center justify-center text-[11px] font-mono font-bold shrink-0 ${
                    isGold
                      ? 'bg-amber-400 text-slate-950'
                      : isSilver
                      ? 'bg-slate-300 text-slate-950'
                      : isBronze
                      ? 'bg-amber-600 text-white'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {idx + 1}
                </div>

                {/* Country Code Pill */}
                <span
                  className="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded border shadow-sm text-white shrink-0"
                  style={{ backgroundColor: athlete.primaryColor, borderColor: athlete.secondaryColor }}
                >
                  {athlete.code}
                </span>

                {/* Name */}
                <span className="line-clamp-1 font-medium">{athlete.name}</span>
              </div>

              {/* Time / Distance Mark */}
              <div className="flex items-center gap-2">
                <span className="text-[10px] text-slate-400 font-mono hidden sm:inline">
                  P:{athlete.laneOrPosition}
                </span>
                <span className="font-mono font-bold text-sky-300">
                  {getSimulatedTime(athlete, idx)}
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
