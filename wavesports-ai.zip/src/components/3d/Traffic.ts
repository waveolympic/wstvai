import * as THREE from 'three';

export interface VehicleData {
  mesh: THREE.Group;
  speed: number;
  radiusX: number;
  radiusZ: number;
  angle: number;
  height: number;
  direction: number;
}

export class TrafficBuilder {
  public vehicles: VehicleData[] = [];

  /**
   * Creates boulevards around the stadium and populates them with moving civilian vehicles
   */
  public buildTraffic(): THREE.Group {
    const trafficGroup = new THREE.Group();
    trafficGroup.name = 'TrafficSystem';

    // Asphalt Road Material
    const asphaltMat = new THREE.MeshStandardMaterial({
      color: 0x222a35,
      roughness: 0.8,
      metalness: 0.1
    });

    const roadMarkingMat = new THREE.MeshBasicMaterial({ color: 0xfef08a });

    // 1. RING ROAD BOULEVARD AROUND STADIUM
    const ringRoadGeo = new THREE.RingGeometry(210, 240, 64, 1);
    const ringRoadMesh = new THREE.Mesh(ringRoadGeo, asphaltMat);
    ringRoadMesh.rotation.x = -Math.PI / 2;
    ringRoadMesh.position.y = 0.1;
    ringRoadMesh.scale.set(1, 1.25, 1);
    ringRoadMesh.receiveShadow = true;
    trafficGroup.add(ringRoadMesh);

    // Yellow Lane Dividers
    const dividerGeo = new THREE.RingGeometry(224.5, 225.5, 64, 1);
    const dividerMesh = new THREE.Mesh(dividerGeo, roadMarkingMat);
    dividerMesh.rotation.x = -Math.PI / 2;
    dividerMesh.position.y = 0.12;
    dividerMesh.scale.set(1, 1.25, 1);
    trafficGroup.add(dividerMesh);

    // 2. VEHICLE MATERIALS
    const carColors = [0xef4444, 0x3b82f6, 0x10b981, 0xf59e0b, 0x6b7280, 0xf8fafc, 0x1e293b];
    const carMaterials = carColors.map(c => new THREE.MeshStandardMaterial({ color: c, roughness: 0.2, metalness: 0.7 }));

    const glassMat = new THREE.MeshStandardMaterial({ color: 0x0284c7, roughness: 0.1, metalness: 0.9 });
    const headlightMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const taillightMat = new THREE.MeshBasicMaterial({ color: 0xff1111 });

    // 3. POPULATE MOVING CARS AND BUSES
    const numVehicles = 42;
    for (let i = 0; i < numVehicles; i++) {
      const isBus = Math.random() > 0.85;
      const carMat = carMaterials[Math.floor(Math.random() * carMaterials.length)];

      const vehicleMesh = new THREE.Group();

      if (isBus) {
        // City Bus
        const busBodyGeo = new THREE.BoxGeometry(4.5, 3.8, 11);
        const busMesh = new THREE.Mesh(busBodyGeo, carMat);
        busMesh.position.y = 2.2;
        vehicleMesh.add(busMesh);

        const busWinGeo = new THREE.BoxGeometry(4.6, 1.5, 9);
        const busWin = new THREE.Mesh(busWinGeo, glassMat);
        busWin.position.y = 2.8;
        vehicleMesh.add(busWin);
      } else {
        // Sedan / SUV
        const bodyGeo = new THREE.BoxGeometry(3.8, 1.8, 7.5);
        const bodyMesh = new THREE.Mesh(bodyGeo, carMat);
        bodyMesh.position.y = 1.1;
        vehicleMesh.add(bodyMesh);

        const cabinGeo = new THREE.BoxGeometry(3.2, 1.2, 4);
        const cabinMesh = new THREE.Mesh(cabinGeo, glassMat);
        cabinMesh.position.set(0, 2.2, -0.4);
        vehicleMesh.add(cabinMesh);
      }

      // Headlights & Taillights
      const hl1 = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.4, 0.2), headlightMat);
      hl1.position.set(-1.2, 1.2, -3.8);
      const hl2 = hl1.clone();
      hl2.position.set(1.2, 1.2, -3.8);

      const tl1 = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.4, 0.2), taillightMat);
      tl1.position.set(-1.2, 1.2, 3.8);
      const tl2 = tl1.clone();
      tl2.position.set(1.2, 1.2, 3.8);

      vehicleMesh.add(hl1, hl2, tl1, tl2);

      const isInnerLane = Math.random() > 0.5;
      const radiusX = isInnerLane ? 217 : 232;
      const radiusZ = (isInnerLane ? 217 : 232) * 1.25;

      const vehicleData: VehicleData = {
        mesh: vehicleMesh,
        speed: (0.15 + Math.random() * 0.1) * (isInnerLane ? 1 : -1),
        radiusX,
        radiusZ,
        angle: Math.random() * Math.PI * 2,
        height: 0.1,
        direction: isInnerLane ? 1 : -1
      };

      trafficGroup.add(vehicleMesh);
      this.vehicles.push(vehicleData);
    }

    return trafficGroup;
  }

  /**
   * Move cars along the boulevard ring road
   */
  public update(delta: number): void {
    this.vehicles.forEach(v => {
      v.angle += v.speed * delta;
      if (v.angle > Math.PI * 2) v.angle -= Math.PI * 2;
      if (v.angle < 0) v.angle += Math.PI * 2;

      const x = Math.cos(v.angle) * v.radiusX;
      const z = Math.sin(v.angle) * v.radiusZ;

      v.mesh.position.set(x, v.height, z);

      // Orientation along tangent
      const nextX = Math.cos(v.angle + 0.02 * v.direction) * v.radiusX;
      const nextZ = Math.sin(v.angle + 0.02 * v.direction) * v.radiusZ;
      v.mesh.lookAt(nextX, v.height, nextZ);
    });
  }
}
