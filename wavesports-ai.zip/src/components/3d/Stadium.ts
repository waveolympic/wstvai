import * as THREE from 'three';
import { TextureGenerator } from './textures';

export class StadiumBuilder {
  /**
   * Constructs the complete 3D Olympic Stadium model according to the reference image
   */
  static buildStadium(): THREE.Group {
    const stadiumGroup = new THREE.Group();
    stadiumGroup.name = 'OlympicStadium';

    // Materials
    const whiteCanopyMat = new THREE.MeshStandardMaterial({
      color: 0xf0f4f8,
      roughness: 0.2,
      metalness: 0.15,
      side: THREE.DoubleSide
    });

    const steelArchMat = new THREE.MeshStandardMaterial({
      color: 0xe2e8f0,
      roughness: 0.25,
      metalness: 0.85
    });

    const etfeRoofMat = new THREE.MeshPhysicalMaterial({
      color: 0xbfdbfe,
      transparent: true,
      opacity: 0.7,
      transmission: 0.65,
      roughness: 0.1,
      ior: 1.45,
      side: THREE.DoubleSide
    });

    const glassFacadeMat = new THREE.MeshPhysicalMaterial({
      color: 0x1e3a8a,
      transparent: true,
      opacity: 0.8,
      transmission: 0.5,
      roughness: 0.15,
      metalness: 0.7,
      reflectivity: 0.9
    });

    const concreteMat = new THREE.MeshStandardMaterial({
      color: 0x94a3b8,
      roughness: 0.7,
      metalness: 0.1
    });

    const seatsTealMat = new THREE.MeshStandardMaterial({
      color: 0x0284c7,
      roughness: 0.5
    });

    const seatsBlueMat = new THREE.MeshStandardMaterial({
      color: 0x0369a1,
      roughness: 0.5
    });

    const seatsDarkBlueMat = new THREE.MeshStandardMaterial({
      color: 0x1e3a8a,
      roughness: 0.5
    });

    const roofGardenGrassMat = new THREE.MeshStandardMaterial({
      color: 0x15803d,
      roughness: 0.8
    });

    const ledScreenMat = new THREE.MeshStandardMaterial({
      map: TextureGenerator.createEmblemTexture(),
      emissive: 0x0077b6,
      emissiveIntensity: 0.6,
      roughness: 0.2
    });

    // 1. BASE PITCH AND ATHLETIC TRACK
    const pitchWidth = 110;
    const pitchLength = 170;

    // Track plane
    const trackGeo = new THREE.PlaneGeometry(pitchLength, pitchWidth, 32, 32);
    const trackTex = TextureGenerator.createTrackTexture();
    const trackMat = new THREE.MeshStandardMaterial({
      map: trackTex,
      roughness: 0.6
    });
    const trackMesh = new THREE.Mesh(trackGeo, trackMat);
    trackMesh.rotation.x = -Math.PI / 2;
    trackMesh.receiveShadow = true;
    stadiumGroup.add(trackMesh);

    // Central Green Turf Field
    const fieldGeo = new THREE.PlaneGeometry(105, 68);
    const fieldTex = TextureGenerator.createFieldTexture();
    const fieldMat = new THREE.MeshStandardMaterial({
      map: fieldTex,
      roughness: 0.7
    });
    const fieldMesh = new THREE.Mesh(fieldGeo, fieldMat);
    fieldMesh.rotation.x = -Math.PI / 2;
    fieldMesh.position.y = 0.05;
    fieldMesh.receiveShadow = true;
    stadiumGroup.add(fieldMesh);

    // 2. SEATING BOWL (Multi-tiered stadium stands)
    const numTiers = 3;
    const segments = 64;

    for (let tier = 0; tier < numTiers; tier++) {
      const innerRadiusX = 60 + tier * 25;
      const innerRadiusZ = 85 + tier * 25;
      const outerRadiusX = innerRadiusX + 22;
      const outerRadiusZ = innerRadiusZ + 22;
      const tierHeight = 12;
      const baseHeight = tier * 14 + 1;

      const standGeo = new THREE.RingGeometry(1, 2, segments, 1);
      const posAttr = standGeo.attributes.position;

      // Transform ring into ellipse with tier elevation
      for (let i = 0; i < posAttr.count; i++) {
        const u = posAttr.getX(i); // r = 1 or 2
        const angle = Math.atan2(posAttr.getY(i), posAttr.getX(i));
        const normalizedAngle = angle;

        const isOuter = (u > 1.5);
        const rx = isOuter ? outerRadiusX : innerRadiusX;
        const rz = isOuter ? outerRadiusZ : innerRadiusZ;

        const x = Math.cos(normalizedAngle) * rx;
        const z = Math.sin(normalizedAngle) * rz;
        const y = baseHeight + (isOuter ? tierHeight : 0);

        posAttr.setXYZ(i, x, y, z);
      }
      standGeo.computeVertexNormals();

      const mat = tier === 0 ? seatsTealMat : (tier === 1 ? seatsBlueMat : seatsDarkBlueMat);
      const standMesh = new THREE.Mesh(standGeo, mat);
      standMesh.castShadow = true;
      standMesh.receiveShadow = true;
      stadiumGroup.add(standMesh);

      // Add concrete steps backing
      const backWallGeo = new THREE.CylinderGeometry(outerRadiusX, outerRadiusX, tierHeight + 2, segments, 1, true);
      backWallGeo.scale(1, 1, outerRadiusZ / outerRadiusX);
      const backWall = new THREE.Mesh(backWallGeo, concreteMat);
      backWall.position.y = baseHeight + tierHeight / 2;
      stadiumGroup.add(backWall);
    }

    // LED Perimeter Ribbon
    const ribbonGeo = new THREE.CylinderGeometry(61, 61, 1.8, segments, 1, true);
    ribbonGeo.scale(1, 1, 86 / 61);
    const ribbonMat = new THREE.MeshBasicMaterial({
      color: 0x00b4d8,
      wireframe: false
    });
    const ribbonMesh = new THREE.Mesh(ribbonGeo, ribbonMat);
    ribbonMesh.position.y = 1.2;
    stadiumGroup.add(ribbonMesh);

    // 3. OUTER GLASS FACADE
    const facadeGeo = new THREE.CylinderGeometry(140, 142, 45, segments, 1, true);
    facadeGeo.scale(1, 1, 165 / 140);
    const facadeMesh = new THREE.Mesh(facadeGeo, glassFacadeMat);
    facadeMesh.position.y = 22.5;
    stadiumGroup.add(facadeMesh);

    // Facade Structural Columns / Diagonal Steel Trusses
    const numTrusses = 32;
    for (let i = 0; i < numTrusses; i++) {
      const angle = (i / numTrusses) * Math.PI * 2;
      const x = Math.cos(angle) * 141;
      const z = Math.sin(angle) * 166;

      const columnGeo = new THREE.CylinderGeometry(1.2, 1.2, 46, 8);
      const column = new THREE.Mesh(columnGeo, steelArchMat);
      column.position.set(x, 23, z);
      column.rotation.z = Math.sin(angle) * 0.15;
      column.rotation.x = Math.cos(angle) * 0.15;
      stadiumGroup.add(column);
    }

    // 4. ICONIC SWOOPING CANOPY ARCHES & ROOFTOP GARDENS
    // Double swooping outer ribbons
    const curvePoints: THREE.Vector3[] = [];
    const numCurvePoints = 120;

    for (let i = 0; i <= numCurvePoints; i++) {
      const t = i / numCurvePoints;
      const angle = t * Math.PI * 2;

      // Base ellipse radii
      const rx = 145 + Math.sin(angle * 2) * 10;
      const rz = 172;

      // Wave height: rises steeply at the north end (z = -172)
      let h = 42 + Math.cos(angle) * 12;
      if (Math.sin(angle) < -0.3) {
        // Grand north arch peak
        h += Math.pow(Math.abs(Math.sin(angle) + 0.3), 2) * 55;
      }

      const x = Math.sin(angle) * rx;
      const z = Math.cos(angle) * rz;
      curvePoints.push(new THREE.Vector3(x, h, z));
    }

    const curve = new THREE.CatmullRomCurve3(curvePoints, true);
    const archTubeGeo = new THREE.TubeGeometry(curve, 180, 5.5, 12, true);
    const archTubeMesh = new THREE.Mesh(archTubeGeo, whiteCanopyMat);
    archTubeMesh.castShadow = true;
    archTubeMesh.receiveShadow = true;
    stadiumGroup.add(archTubeMesh);

    // Inner secondary arch tube
    const innerCurvePoints = curvePoints.map(p => new THREE.Vector3(p.x * 0.88, p.y * 0.92, p.z * 0.88));
    const innerCurve = new THREE.CatmullRomCurve3(innerCurvePoints, true);
    const innerTubeGeo = new THREE.TubeGeometry(innerCurve, 180, 3.8, 10, true);
    const innerTubeMesh = new THREE.Mesh(innerTubeGeo, steelArchMat);
    stadiumGroup.add(innerTubeMesh);

    // 5. ETFE TRANSLUCENT ROOF CANOPY PANELS
    const roofRingGeo = new THREE.RingGeometry(85, 142, segments, 1);
    const roofPos = roofRingGeo.attributes.position;

    for (let i = 0; i < roofPos.count; i++) {
      const u = roofPos.getX(i);
      const angle = Math.atan2(roofPos.getY(i), roofPos.getX(i));
      const isOuter = u > 1.5;

      const rx = isOuter ? 142 : 88;
      const rz = isOuter ? 168 : 110;

      const x = Math.cos(angle) * rx;
      const z = Math.sin(angle) * rz;

      // Match canopy height profile
      let h = 42 + Math.cos(angle) * 10;
      if (Math.sin(angle) < -0.3) {
        h += Math.pow(Math.abs(Math.sin(angle) + 0.3), 2) * 35;
      }
      if (!isOuter) h -= 12; // Slopes downward toward inner oval opening

      roofPos.setXYZ(i, x, h, z);
    }
    roofRingGeo.computeVertexNormals();

    const etfeRoofMesh = new THREE.Mesh(roofRingGeo, etfeRoofMat);
    etfeRoofMesh.castShadow = true;
    stadiumGroup.add(etfeRoofMesh);

    // 6. ROOFTOP GARDEN STRIPS ON THE SWOOPING CANOPY
    const gardenGeo = new THREE.RingGeometry(132, 144, 48, 1);
    const gardenPos = gardenGeo.attributes.position;
    for (let i = 0; i < gardenPos.count; i++) {
      const u = gardenPos.getX(i);
      const angle = Math.atan2(gardenPos.getY(i), gardenPos.getX(i));
      const isOuter = u > 1.5;
      const rx = isOuter ? 144 : 132;
      const rz = isOuter ? 170 : 156;

      const x = Math.cos(angle) * rx;
      const z = Math.sin(angle) * rz;
      let h = 43 + Math.cos(angle) * 11;
      if (Math.sin(angle) < -0.3) {
        h += Math.pow(Math.abs(Math.sin(angle) + 0.3), 2) * 45;
      }

      gardenPos.setXYZ(i, x, h + 0.4, z);
    }
    gardenGeo.computeVertexNormals();
    const gardenMesh = new THREE.Mesh(gardenGeo, roofGardenGrassMat);
    stadiumGroup.add(gardenMesh);

    // 7. GRAND NORTH ARCH & CIRCULAR LED SCREEN
    // North Arch rising high above the stadium end
    const northArchCurve = new THREE.QuadraticBezierCurve3(
      new THREE.Vector3(-90, 45, -165),
      new THREE.Vector3(0, 115, -170),
      new THREE.Vector3(90, 45, -165)
    );
    const northArchGeo = new THREE.TubeGeometry(northArchCurve, 40, 6, 12, false);
    const northArchMesh = new THREE.Mesh(northArchGeo, whiteCanopyMat);
    northArchMesh.castShadow = true;
    stadiumGroup.add(northArchMesh);

    // Main North LED Screen Frame
    const screenFrameGeo = new THREE.CylinderGeometry(24, 24, 3, 32);
    const screenFrameMesh = new THREE.Mesh(screenFrameGeo, steelArchMat);
    screenFrameMesh.position.set(0, 82, -162);
    screenFrameMesh.rotation.x = Math.PI / 2;
    stadiumGroup.add(screenFrameMesh);

    // Main North LED Screen Display
    const screenDisplayGeo = new THREE.CircleGeometry(22, 32);
    const screenDisplayMesh = new THREE.Mesh(screenDisplayGeo, ledScreenMat);
    screenDisplayMesh.position.set(0, 82, -160.4);
    screenDisplayMesh.rotation.y = 0;
    stadiumGroup.add(screenDisplayMesh);

    // Secondary South LED Screen
    const southScreenGeo = new THREE.PlaneGeometry(36, 18);
    const southScreenMesh = new THREE.Mesh(southScreenGeo, ledScreenMat);
    southScreenMesh.position.set(0, 45, 160);
    southScreenMesh.rotation.y = Math.PI;
    stadiumGroup.add(southScreenMesh);

    return stadiumGroup;
  }
}
