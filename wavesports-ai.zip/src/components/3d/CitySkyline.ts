import * as THREE from 'three';
import { TextureGenerator } from './textures';

export class CitySkylineBuilder {
  public monorailTrain!: THREE.Group;

  /**
   * Builds the surrounding city skyline, bay, marina, bridges, monorail, and mountain backdrop
   */
  public buildCitySkyline(): THREE.Group {
    const group = new THREE.Group();
    group.name = 'CitySkyline';

    // Materials
    const buildingWinTex = TextureGenerator.createBuildingWindowTexture();
    buildingWinTex.repeat.set(4, 12);

    const glassTowerMat = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      roughness: 0.1,
      metalness: 0.8,
      map: buildingWinTex
    });

    const whiteConcreteMat = new THREE.MeshStandardMaterial({
      color: 0xf1f5f9,
      roughness: 0.3,
      metalness: 0.1
    });

    const darkSteelMat = new THREE.MeshStandardMaterial({
      color: 0x334155,
      roughness: 0.2,
      metalness: 0.85
    });

    const bridgeCableMat = new THREE.MeshBasicMaterial({ color: 0xffffff });

    const mountainMat = new THREE.MeshStandardMaterial({
      color: 0x1e1b4b,
      roughness: 0.95,
      metalness: 0.05
    });

    const marinaHullMat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.2,
      metalness: 0.3
    });

    // 1. WATERFRONT BAY & OCEAN PLANE
    const oceanGeo = new THREE.PlaneGeometry(3000, 2000, 64, 64);
    const oceanWaterMat = new THREE.MeshPhysicalMaterial({
      color: 0x0369a1,
      roughness: 0.08,
      metalness: 0.2,
      transmission: 0.6,
      transparent: true,
      opacity: 0.95,
      reflectivity: 0.9,
      ior: 1.333,
      normalMap: TextureGenerator.createWaterNormalTexture(),
      normalScale: new THREE.Vector2(0.4, 0.4)
    });

    const oceanMesh = new THREE.Mesh(oceanGeo, oceanWaterMat);
    oceanMesh.rotation.x = -Math.PI / 2;
    oceanMesh.position.set(0, -0.2, -600);
    oceanMesh.receiveShadow = true;
    group.add(oceanMesh);

    // 2. BACKGROUND MOUNTAIN RANGE
    const mountainGeo = new THREE.PlaneGeometry(3200, 350, 128, 1);
    const mtnPos = mountainGeo.attributes.position;
    for (let i = 0; i < mtnPos.count; i++) {
      const x = mtnPos.getX(i);
      const y = mtnPos.getY(i);
      if (y > 0) {
        // Procedural mountain ridge profile
        const ridge = Math.sin(x * 0.005) * 80 + Math.sin(x * 0.012) * 45 + Math.cos(x * 0.002) * 110;
        mtnPos.setY(i, y + Math.abs(ridge));
      }
    }
    mountainGeo.computeVertexNormals();
    const mountainMesh = new THREE.Mesh(mountainGeo, mountainMat);
    mountainMesh.position.set(0, 80, -1450);
    group.add(mountainMesh);

    // 3. SKYSCRAPERS & CITY BUILDINGS (INSTANCED & VARIED ARCHITECTURE)
    const numBuildings = 140;
    const buildingGeometries = [
      new THREE.BoxGeometry(1, 1, 1),
      new THREE.CylinderGeometry(0.5, 0.5, 1, 16),
      new THREE.CylinderGeometry(0.2, 0.6, 1, 8)
    ];

    // Instanced mesh for office skyscrapers
    const boxInstMesh = new THREE.InstancedMesh(buildingGeometries[0], glassTowerMat, numBuildings);
    boxInstMesh.castShadow = true;
    boxInstMesh.receiveShadow = true;

    const dummy = new THREE.Object3D();

    for (let i = 0; i < numBuildings; i++) {
      // Distribute along the bay shoreline and background hills
      const side = Math.random() > 0.3 ? 1 : -1;
      const x = side * (250 + Math.random() * 900);
      const z = -350 - Math.random() * 800;

      const w = 30 + Math.random() * 45;
      const d = 30 + Math.random() * 45;
      const h = 80 + Math.pow(Math.random(), 2) * 320; // Some mega tall towers

      dummy.position.set(x, h / 2, z);
      dummy.scale.set(w, h, d);
      dummy.rotation.y = (Math.floor(Math.random() * 4) * Math.PI) / 2;
      dummy.updateMatrix();

      boxInstMesh.setMatrixAt(i, dummy.matrix);
    }
    boxInstMesh.instanceMatrix.needsUpdate = true;
    group.add(boxInstMesh);

    // Landmark Iconic Twisting Sky Tower (Center Waterfront)
    const twistTowerGroup = new THREE.Group();
    twistTowerGroup.position.set(-180, 0, -450);

    const floors = 25;
    for (let f = 0; f < floors; f++) {
      const floorGeo = new THREE.BoxGeometry(45, 12, 45);
      const floorMesh = new THREE.Mesh(floorGeo, glassTowerMat);
      floorMesh.position.y = f * 11 + 6;
      floorMesh.rotation.y = f * 0.08;
      twistTowerGroup.add(floorMesh);
    }
    group.add(twistTowerGroup);

    // 4. SUSPENSION BRIDGES ACROSS THE BAY
    const bridgeGroup = new THREE.Group();
    bridgeGroup.position.set(-550, 0, -800);

    // Bridge Deck
    const bridgeDeckGeo = new THREE.BoxGeometry(1200, 6, 32);
    const bridgeDeck = new THREE.Mesh(bridgeDeckGeo, darkSteelMat);
    bridgeDeck.position.set(0, 25, 0);
    bridgeGroup.add(bridgeDeck);

    // A-Frame Towers
    for (let tx = -250; tx <= 250; tx += 500) {
      const towerGroup = new THREE.Group();
      towerGroup.position.set(tx, 25, 0);

      const p1 = new THREE.Mesh(new THREE.CylinderGeometry(3, 5, 140, 8), whiteConcreteMat);
      p1.position.set(-10, 70, 0);
      p1.rotation.z = -0.1;
      towerGroup.add(p1);

      const p2 = p1.clone();
      p2.position.set(10, 70, 0);
      p2.rotation.z = 0.1;
      towerGroup.add(p2);

      bridgeGroup.add(towerGroup);

      // Suspension Cables
      for (let c = -200; c <= 200; c += 40) {
        if (Math.abs(c) < 20) continue;
        const cableCurve = new THREE.Line3(
          new THREE.Vector3(tx, 160, 0),
          new THREE.Vector3(tx + c, 28, 0)
        );
        const cableGeo = new THREE.BufferGeometry().setFromPoints([cableCurve.start, cableCurve.end]);
        const cableLine = new THREE.Line(cableGeo, bridgeCableMat);
        bridgeGroup.add(cableLine);
      }
    }
    group.add(bridgeGroup);

    // 5. MARINA & YACHTS (LEFT BAY WATERFRONT)
    const marinaGroup = new THREE.Group();
    marinaGroup.position.set(-450, 0, -320);

    // Pier Docks
    for (let p = 0; p < 4; p++) {
      const pierGeo = new THREE.BoxGeometry(180, 3, 12);
      const pier = new THREE.Mesh(pierGeo, darkSteelMat);
      pier.position.set(0, 1.5, p * 45);
      marinaGroup.add(pier);

      // Yachts docked at piers
      for (let y = -70; y <= 70; y += 35) {
        const yachtGeo = new THREE.ConeGeometry(5, 22, 8);
        const yacht = new THREE.Mesh(yachtGeo, marinaHullMat);
        yacht.rotation.z = Math.PI / 2;
        yacht.rotation.y = (p % 2 === 0 ? 0 : Math.PI);
        yacht.position.set(y, 2, p * 45 + (p % 2 === 0 ? 16 : -16));
        marinaGroup.add(yacht);
      }
    }
    group.add(marinaGroup);

    // 6. ELEVATED MONORAIL TRANSIT LINE & MOVING TRAIN
    const monorailGroup = new THREE.Group();

    // Curved Track Beam
    const trackCurvePoints: THREE.Vector3[] = [];
    for (let i = 0; i <= 60; i++) {
      const t = i / 60;
      const angle = t * Math.PI * 0.8 - 0.2;
      const x = Math.cos(angle) * 320;
      const z = Math.sin(angle) * 320 - 100;
      trackCurvePoints.push(new THREE.Vector3(x, 18, z));
    }
    const monorailCurve = new THREE.CatmullRomCurve3(trackCurvePoints);
    const monorailBeamGeo = new THREE.TubeGeometry(monorailCurve, 80, 2.2, 8, false);
    const monorailBeam = new THREE.Mesh(monorailBeamGeo, whiteConcreteMat);
    monorailGroup.add(monorailBeam);

    // Monorail Support Pillars
    const numPillars = 20;
    for (let i = 0; i <= numPillars; i++) {
      const pt = monorailCurve.getPoint(i / numPillars);
      const pillarGeo = new THREE.CylinderGeometry(2, 2.5, pt.y, 8);
      const pillar = new THREE.Mesh(pillarGeo, darkSteelMat);
      pillar.position.set(pt.x, pt.y / 2, pt.z);
      monorailGroup.add(pillar);
    }

    // Monorail Bullet Train
    this.monorailTrain = new THREE.Group();
    const trainBodyGeo = new THREE.CylinderGeometry(2.2, 2.2, 36, 12);
    trainBodyGeo.rotateZ(Math.PI / 2);
    const trainMesh = new THREE.Mesh(trainBodyGeo, whiteConcreteMat);

    // Glowing LED Stripe on Train
    const stripeGeo = new THREE.BoxGeometry(34, 0.4, 2.4);
    const stripeMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });
    const stripeMesh = new THREE.Mesh(stripeGeo, stripeMat);
    stripeMesh.position.y = 0.2;
    this.monorailTrain.add(trainMesh);
    this.monorailTrain.add(stripeMesh);

    monorailGroup.add(this.monorailTrain);
    group.add(monorailGroup);

    return group;
  }

  /**
   * Updates monorail train movement along the curved track beam
   */
  public update(time: number): void {
    if (this.monorailTrain) {
      const progress = (time * 0.05) % 1.0;
      const trackCurvePoints: THREE.Vector3[] = [];
      for (let i = 0; i <= 60; i++) {
        const t = i / 60;
        const angle = t * Math.PI * 0.8 - 0.2;
        const x = Math.cos(angle) * 320;
        const z = Math.sin(angle) * 320 - 100;
        trackCurvePoints.push(new THREE.Vector3(x, 18, z));
      }
      const curve = new THREE.CatmullRomCurve3(trackCurvePoints);
      const pos = curve.getPoint(progress);
      const tangent = curve.getTangent(progress);

      this.monorailTrain.position.copy(pos);
      this.monorailTrain.lookAt(pos.clone().add(tangent));
    }
  }
}
