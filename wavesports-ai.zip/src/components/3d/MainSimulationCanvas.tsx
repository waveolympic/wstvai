import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { OlympicEvent, TelemetryFrame, HighlightClip } from '../../types/olympics';
import { VenueManager, CameraPreset } from '../../venues/VenueManager';

interface Props {
  activeEvent: OlympicEvent;
  isSimulating: boolean;
  isReplaying?: boolean;
  replayProgressRatio?: number;
  simSpeed: number; // 0.5, 1.0, 2.0
  activePresetId: string;
  isRecording?: boolean;
  onPresetsLoaded: (presets: CameraPreset[]) => void;
  onTelemetryUpdate: (telemetry: {
    phase: string;
    telemetryValue: number;
    elapsedSimTimeMs: number;
    fps: number;
    meshCount: number;
    vertexCount: number;
  }) => void;
  onTelemetryFrameRecorded?: (frame: TelemetryFrame) => void;
  onClipRecorded?: (clip: HighlightClip) => void;
  takeSnapshotRef?: React.MutableRefObject<(() => string | null) | null>;
}

export const MainSimulationCanvas: React.FC<Props> = ({
  activeEvent,
  isSimulating,
  isReplaying = false,
  replayProgressRatio = 0,
  simSpeed,
  activePresetId,
  isRecording = false,
  onPresetsLoaded,
  onTelemetryUpdate,
  onTelemetryFrameRecorded,
  onClipRecorded,
  takeSnapshotRef,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);

  // Three.js Core Refs
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const venueManagerRef = useRef<VenueManager | null>(null);

  // Animation & Simulation State
  const animationFrameIdRef = useRef<number | null>(null);
  const clockRef = useRef<THREE.Clock>(new THREE.Clock());
  const progressRatioRef = useRef<number>(0);
  const simTimeMsRef = useRef<number>(0);

  // Latest props refs for high-performance animation loop
  const isSimulatingRef = useRef<boolean>(isSimulating);
  const isReplayingRef = useRef<boolean>(isReplaying);
  const replayProgressRatioRef = useRef<number>(replayProgressRatio);
  const simSpeedRef = useRef<number>(simSpeed);
  const activeEventRef = useRef<OlympicEvent>(activeEvent);

  // Media Recorder refs
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);
  const recordingStartTimeRef = useRef<number>(0);
  const maxRecordedTelemetryValueRef = useRef<number>(0);

  useEffect(() => {
    isSimulatingRef.current = isSimulating;
  }, [isSimulating]);

  useEffect(() => {
    isReplayingRef.current = isReplaying;
  }, [isReplaying]);

  useEffect(() => {
    replayProgressRatioRef.current = replayProgressRatio;
  }, [replayProgressRatio]);

  useEffect(() => {
    simSpeedRef.current = simSpeed;
  }, [simSpeed]);

  useEffect(() => {
    activeEventRef.current = activeEvent;
  }, [activeEvent]);

  // Camera lerp targets
  const targetPosRef = useRef<THREE.Vector3>(new THREE.Vector3(0, 32, 48));
  const targetLookRef = useRef<THREE.Vector3>(new THREE.Vector3(0, 1.2, 0));
  const isTransitioningRef = useRef<boolean>(false);

  // Frame telemetry tracking
  const frameCountRef = useRef<number>(0);
  const lastFpsTimeRef = useRef<number>(performance.now());
  const currentFpsRef = useRef<number>(60);

  // Initialize Scene
  useEffect(() => {
    if (!containerRef.current) return;
    const container = containerRef.current;

    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || window.innerHeight;

    // 1. Scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0b111e);
    sceneRef.current = scene;

    // 2. Camera
    const camera = new THREE.PerspectiveCamera(46, width / height, 0.5, 3000);
    camera.position.set(0, 32, 48);
    cameraRef.current = camera;

    // 3. Renderer
    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      powerPreference: 'high-performance',
      precision: 'highp',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    rendererRef.current = renderer;

    container.appendChild(renderer.domElement);

    // 4. OrbitControls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.maxPolarAngle = Math.PI / 2 - 0.02;
    controls.minDistance = 2;
    controls.maxDistance = 1200;
    controls.target.set(0, 1.2, 0);
    controlsRef.current = controls;

    // 5. VenueManager
    const venueManager = new VenueManager(scene);
    venueManagerRef.current = venueManager;

    // Load initial venue
    const { presets } = venueManager.loadVenueForEvent(activeEvent);
    onPresetsLoaded(presets);

    if (presets.length > 0) {
      targetPosRef.current.copy(presets[0].position);
      targetLookRef.current.copy(presets[0].target);
      camera.position.copy(presets[0].position);
      controls.target.copy(presets[0].target);
    }

    // Window Resize Observer
    const handleResize = () => {
      if (!containerRef.current || !rendererRef.current || !cameraRef.current) return;
      const w = containerRef.current.clientWidth;
      const h = containerRef.current.clientHeight;
      cameraRef.current.aspect = w / h;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    // 6. Animation Loop
    const renderLoop = () => {
      animationFrameIdRef.current = requestAnimationFrame(renderLoop);

      const delta = clockRef.current.getDelta();
      const elapsedTime = clockRef.current.getElapsedTime();

      // Measure FPS
      frameCountRef.current++;
      const now = performance.now();
      if (now - lastFpsTimeRef.current >= 500) {
        currentFpsRef.current = Math.round((frameCountRef.current * 1000) / (now - lastFpsTimeRef.current));
        frameCountRef.current = 0;
        lastFpsTimeRef.current = now;
      }

      // Camera lerp
      if (isTransitioningRef.current && cameraRef.current && controlsRef.current) {
        cameraRef.current.position.lerp(targetPosRef.current, 0.06);
        controlsRef.current.target.lerp(targetLookRef.current, 0.06);

        if (
          cameraRef.current.position.distanceTo(targetPosRef.current) < 0.2 &&
          controlsRef.current.target.distanceTo(targetLookRef.current) < 0.2
        ) {
          cameraRef.current.position.copy(targetPosRef.current);
          controlsRef.current.target.copy(targetLookRef.current);
          isTransitioningRef.current = false;
        }
      }

      controlsRef.current?.update();

      // Simulation or Replay Progress
      if (isReplayingRef.current) {
        progressRatioRef.current = replayProgressRatioRef.current;
      } else if (isSimulatingRef.current) {
        // Increment progress based on speed
        const durationSec = activeEventRef.current.distanceMeters <= 100 ? 10 : activeEventRef.current.distanceMeters <= 400 ? 44 : 105;
        const progressIncrement = (delta * simSpeedRef.current) / durationSec;
        progressRatioRef.current = (progressRatioRef.current + progressIncrement) % 1.0;
        simTimeMsRef.current += delta * 1000 * simSpeedRef.current;
      }

      // Update Venue Animations & Telemetry
      if (venueManagerRef.current) {
        const animState = venueManagerRef.current.updateAnimation(
          elapsedTime,
          delta,
          progressRatioRef.current,
          activeEventRef.current
        );

        if (animState.telemetryValue > maxRecordedTelemetryValueRef.current) {
          maxRecordedTelemetryValueRef.current = animState.telemetryValue;
        }

        // Emit recorded frame during active live simulation
        if (isSimulatingRef.current && onTelemetryFrameRecorded) {
          onTelemetryFrameRecorded({
            progressRatio: progressRatioRef.current,
            simTimeMs: Math.round(simTimeMsRef.current),
            phase: animState.phase,
            telemetryValue: animState.telemetryValue,
            timestampMs: performance.now(),
          });
        }

        // Count active meshes & vertices
        let meshCount = 0;
        let vertexCount = 0;
        scene.traverse((obj) => {
          if (obj instanceof THREE.Mesh) {
            meshCount++;
            if (obj.geometry) {
              vertexCount += obj.geometry.attributes.position ? obj.geometry.attributes.position.count : 0;
            }
          }
        });

        onTelemetryUpdate({
          phase: animState.phase,
          telemetryValue: animState.telemetryValue,
          elapsedSimTimeMs: Math.round(simTimeMsRef.current),
          fps: currentFpsRef.current,
          meshCount,
          vertexCount,
        });
      }

      renderer.render(scene, camera);
    };

    renderLoop();

    return () => {
      if (animationFrameIdRef.current !== null) {
        cancelAnimationFrame(animationFrameIdRef.current);
      }
      window.removeEventListener('resize', handleResize);
      controls.dispose();
      renderer.dispose();
      if (renderer.domElement && container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  // Handle Event Change -> Reload Venue
  useEffect(() => {
    if (!venueManagerRef.current) return;
    progressRatioRef.current = 0;
    simTimeMsRef.current = 0;

    const { presets } = venueManagerRef.current.loadVenueForEvent(activeEvent);
    onPresetsLoaded(presets);

    if (presets.length > 0) {
      targetPosRef.current.copy(presets[0].position);
      targetLookRef.current.copy(presets[0].target);
      isTransitioningRef.current = true;
    }
  }, [activeEvent.id]);

  // Bind Take Snapshot function
  useEffect(() => {
    if (takeSnapshotRef) {
      takeSnapshotRef.current = () => {
        if (rendererRef.current && sceneRef.current && cameraRef.current) {
          rendererRef.current.render(sceneRef.current, cameraRef.current);
          return rendererRef.current.domElement.toDataURL('image/png');
        }
        return null;
      };
    }
  }, [takeSnapshotRef]);

  // MediaRecorder for Highlight Clips
  useEffect(() => {
    if (isRecording) {
      if (rendererRef.current && 'captureStream' in rendererRef.current.domElement) {
        try {
          const stream = (rendererRef.current.domElement as any).captureStream(30);
          recordedChunksRef.current = [];
          recordingStartTimeRef.current = Date.now();

          let options: MediaRecorderOptions = { mimeType: 'video/webm;codecs=vp9' };
          if (typeof MediaRecorder.isTypeSupported === 'function' && !MediaRecorder.isTypeSupported(options.mimeType!)) {
            options = { mimeType: 'video/webm' };
          }

          const recorder = new MediaRecorder(stream, options);
          recorder.ondataavailable = (e) => {
            if (e.data && e.data.size > 0) {
              recordedChunksRef.current.push(e.data);
            }
          };

          recorder.onstop = () => {
            const duration = Date.now() - recordingStartTimeRef.current;
            const blob = new Blob(recordedChunksRef.current, { type: 'video/webm' });
            const videoUrl = URL.createObjectURL(blob);
            const snapshotUrl = rendererRef.current?.domElement.toDataURL('image/png');

            const clip: HighlightClip = {
              id: `clip-${Date.now()}`,
              title: `${activeEvent.name} Reel`,
              eventName: activeEvent.name,
              venueName: activeEvent.venueName,
              durationMs: duration,
              videoBlobUrl: videoUrl,
              snapshotDataUrl: snapshotUrl,
              recordedAt: new Date().toLocaleTimeString(),
              telemetryValue: maxRecordedTelemetryValueRef.current || 10.0,
              unitLabel: activeEvent.discipline === 'long-jump' ? 'm' : 'm',
            };

            if (onClipRecorded) {
              onClipRecorded(clip);
            }
          };

          recorder.start(500);
          mediaRecorderRef.current = recorder;
        } catch (err) {
          console.warn('MediaRecorder recording error:', err);
        }
      }
    } else {
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
        mediaRecorderRef.current.stop();
        mediaRecorderRef.current = null;
      }
    }
  }, [isRecording, activeEvent]);

  // Handle Camera Preset Switch
  useEffect(() => {
    if (!venueManagerRef.current) return;
    const presets = venueManagerRef.current.getCameraPresetsForVenue(activeEvent.venueId);
    const found = presets.find(p => p.id === activePresetId);
    if (found) {
      targetPosRef.current.copy(found.position);
      targetLookRef.current.copy(found.target);
      isTransitioningRef.current = true;
    }
  }, [activePresetId]);

  return (
    <div
      ref={containerRef}
      className="w-full h-full absolute inset-0 z-0 bg-[#0b111e]"
    />
  );
};
