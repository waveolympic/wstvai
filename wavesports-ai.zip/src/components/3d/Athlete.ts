import * as THREE from 'three';
import { TextureGenerator } from './textures';

export interface AthleteData {
  lane: number;          // 1 to 8
  name: string;          // Athlete Full Name
  nation: string;        // Country Code (e.g., PAC, USA, JAM)
  bibNumber: number;     // e.g. 101, 102...
  kitColors: {
    primary: number;
    secondary: number;
    accent: number;
  };
  heightScale: number;
  skinTone: number;
}

export const SPRINTER_PROFILES: AthleteData[] = [
  {
    lane: 1,
    name: 'Noah Vance',
    nation: 'PAC',
    bibNumber: 101,
    kitColors: { primary: 0x0284c7, secondary: 0x0369a1, accent: 0xfacc15 },
    heightScale: 1.0,
    skinTone: 0x8d5524
  },
  {
    lane: 2,
    name: 'Christian King',
    nation: 'USA',
    bibNumber: 102,
    kitColors: { primary: 0x1e3a8a, secondary: 0xb91c1c, accent: 0xffffff },
    heightScale: 1.02,
    skinTone: 0xc68642
  },
  {
    lane: 3,
    name: 'Kishane Bolt',
    nation: 'JAM',
    bibNumber: 103,
    kitColors: { primary: 0xeab308, secondary: 0x15803d, accent: 0x000000 },
    heightScale: 1.04,
    skinTone: 0x3d2314
  },
  {
    lane: 4,
    name: 'Hughes Sterling',
    nation: 'GBR',
    bibNumber: 104,
    kitColors: { primary: 0xf8fafc, secondary: 0x1e40af, accent: 0xd97706 },
    heightScale: 0.99,
    skinTone: 0xe0ac69
  },
  {
    lane: 5,
    name: 'Omanyala Kip',
    nation: 'KEN',
    bibNumber: 105,
    kitColors: { primary: 0x15803d, secondary: 0xb91c1c, accent: 0x000000 },
    heightScale: 1.01,
    skinTone: 0x2b1704
  },
  {
    lane: 6,
    name: 'De Grasse Andre',
    nation: 'CAN',
    bibNumber: 106,
    kitColors: { primary: 0xd97706, secondary: 0xffffff, accent: 0xb91c1c },
    heightScale: 0.98,
    skinTone: 0x8d5524
  },
  {
    lane: 7,
    name: 'Sani Brown',
    nation: 'JPN',
    bibNumber: 107,
    kitColors: { primary: 0xffffff, secondary: 0x991b1b, accent: 0xd97706 },
    heightScale: 1.03,
    skinTone: 0x7a431d
  },
  {
    lane: 8,
    name: 'Rohan Browning',
    nation: 'AUS',
    bibNumber: 108,
    kitColors: { primary: 0x166534, secondary: 0xfacc15, accent: 0xffffff },
    heightScale: 0.99,
    skinTone: 0xf1c27d
  }
];

export class AthleteBuilder {
  /**
   * Constructs an animation-ready, modular 3D Sprinter model with skeleton,
   * attachments, country bibs, spikes, and precise collision grounding.
   */
  static createAthlete(data: AthleteData): THREE.Group {
    const athleteGroup = new THREE.Group();
    athleteGroup.name = `Sprinter_Lane_${data.lane}_${data.name.replace(/\s+/g, '_')}`;

    // 1. SKELETAL RIG HIERARCHY
    const hipsBone = new THREE.Bone();
    hipsBone.name = 'Hips';
    hipsBone.position.set(0, 0.95, 0);

    const spineBone = new THREE.Bone();
    spineBone.name = 'Spine';
    spineBone.position.set(0, 0.15, 0);

    const chestBone = new THREE.Bone();
    chestBone.name = 'Chest';
    chestBone.position.set(0, 0.25, 0);

    const neckBone = new THREE.Bone();
    neckBone.name = 'Neck';
    neckBone.position.set(0, 0.25, 0);

    const headBone = new THREE.Bone();
    headBone.name = 'Head';
    headBone.position.set(0, 0.15, 0);

    // Arms
    const clavicleL = new THREE.Bone();
    clavicleL.name = 'Clavicle_L';
    clavicleL.position.set(-0.12, 0.2, 0);

    const upperArmL = new THREE.Bone();
    upperArmL.name = 'UpperArm_L';
    upperArmL.position.set(-0.15, 0, 0);

    const foreArmL = new THREE.Bone();
    foreArmL.name = 'Forearm_L';
    foreArmL.position.set(-0.25, 0, 0);

    const handL = new THREE.Bone();
    handL.name = 'Hand_L';
    handL.position.set(-0.22, 0, 0);

    const clavicleR = new THREE.Bone();
    clavicleR.name = 'Clavicle_R';
    clavicleR.position.set(0.12, 0.2, 0);

    const upperArmR = new THREE.Bone();
    upperArmR.name = 'UpperArm_R';
    upperArmR.position.set(0.15, 0, 0);

    const foreArmR = new THREE.Bone();
    foreArmR.name = 'Forearm_R';
    foreArmR.position.set(0.25, 0, 0);

    const handR = new THREE.Bone();
    handR.name = 'Hand_R';
    handR.position.set(0.22, 0, 0);

    // Legs
    const thighL = new THREE.Bone();
    thighL.name = 'Thigh_L';
    thighL.position.set(-0.12, -0.05, 0);

    const shinL = new THREE.Bone();
    shinL.name = 'Shin_L';
    shinL.position.set(0, -0.42, 0);

    const footL = new THREE.Bone();
    footL.name = 'Foot_L';
    footL.position.set(0, -0.42, 0.05);

    const thighR = new THREE.Bone();
    thighR.name = 'Thigh_R';
    thighR.position.set(0.12, -0.05, 0);

    const shinR = new THREE.Bone();
    shinR.name = 'Shin_R';
    shinR.position.set(0, -0.42, 0);

    const footR = new THREE.Bone();
    footR.name = 'Foot_R';
    footR.position.set(0, -0.42, 0.05);

    // Assemble Bone Structure
    hipsBone.add(spineBone);
    spineBone.add(chestBone);
    chestBone.add(neckBone);
    neckBone.add(headBone);

    chestBone.add(clavicleL);
    clavicleL.add(upperArmL);
    upperArmL.add(foreArmL);
    foreArmL.add(handL);

    chestBone.add(clavicleR);
    clavicleR.add(upperArmR);
    upperArmR.add(foreArmR);
    foreArmR.add(handR);

    hipsBone.add(thighL);
    thighL.add(shinL);
    shinL.add(footL);

    hipsBone.add(thighR);
    thighR.add(shinR);
    shinR.add(footR);

    const skeleton = new THREE.Skeleton([
      hipsBone, spineBone, chestBone, neckBone, headBone,
      clavicleL, upperArmL, foreArmL, handL,
      clavicleR, upperArmR, foreArmR, handR,
      thighL, shinL, footL,
      thighR, shinR, footR
    ]);

    athleteGroup.add(hipsBone);

    // 2. MATERIALS & TEXTURES
    const skinMat = new THREE.MeshStandardMaterial({
      color: data.skinTone,
      roughness: 0.55,
      metalness: 0.08
    });

    const kitMat = new THREE.MeshStandardMaterial({
      color: data.kitColors.primary,
      roughness: 0.4,
      metalness: 0.1
    });

    const kitSecondaryMat = new THREE.MeshStandardMaterial({
      color: data.kitColors.secondary,
      roughness: 0.4
    });

    const spikeShoeMat = new THREE.MeshStandardMaterial({
      color: data.kitColors.accent,
      roughness: 0.2,
      metalness: 0.6
    });

    const bibTex = TextureGenerator.createAthleteBibTexture(data.nation, data.bibNumber, data.name);
    const bibMat = new THREE.MeshStandardMaterial({
      map: bibTex,
      roughness: 0.3
    });

    // 3. ATHLETE MESHES
    // Torso (Chest & Abdomen in Compression Suit)
    const torsoGeo = new THREE.CylinderGeometry(0.24, 0.19, 0.55, 12);
    const torsoMesh = new THREE.Mesh(torsoGeo, kitMat);
    torsoMesh.position.set(0, 1.28, 0);
    torsoMesh.castShadow = true;
    athleteGroup.add(torsoMesh);

    // Head & Hair
    const headGeo = new THREE.SphereGeometry(0.12, 16, 16);
    headGeo.scale(1, 1.2, 1);
    const headMesh = new THREE.Mesh(headGeo, skinMat);
    headMesh.position.set(0, 1.72, 0);
    headMesh.castShadow = true;
    athleteGroup.add(headMesh);

    // Hair cap
    const hairGeo = new THREE.SphereGeometry(0.123, 16, 12, 0, Math.PI * 2, 0, Math.PI / 2.2);
    const hairMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.9 });
    const hairMesh = new THREE.Mesh(hairGeo, hairMat);
    hairMesh.position.set(0, 1.73, 0);
    athleteGroup.add(hairMesh);

    // Muscle Arms
    const upperArmGeo = new THREE.CylinderGeometry(0.07, 0.06, 0.32, 10);
    const foreArmGeo = new THREE.CylinderGeometry(0.06, 0.045, 0.3, 10);

    const leftArmGroup = new THREE.Group();
    leftArmGroup.position.set(-0.3, 1.42, 0);

    const leftUpperArm = new THREE.Mesh(upperArmGeo, skinMat);
    leftUpperArm.position.set(0, -0.16, 0);
    leftArmGroup.add(leftUpperArm);

    const leftForeArm = new THREE.Mesh(foreArmGeo, skinMat);
    leftForeArm.position.set(0, -0.42, 0);
    leftArmGroup.add(leftForeArm);

    leftArmGroup.rotation.z = 0.2; // Slight A-pose arm angle
    athleteGroup.add(leftArmGroup);

    const rightArmGroup = new THREE.Group();
    rightArmGroup.position.set(0.3, 1.42, 0);

    const rightUpperArm = new THREE.Mesh(upperArmGeo, skinMat);
    rightUpperArm.position.set(0, -0.16, 0);
    rightArmGroup.add(rightUpperArm);

    const rightForeArm = new THREE.Mesh(foreArmGeo, skinMat);
    rightForeArm.position.set(0, -0.42, 0);
    rightArmGroup.add(rightForeArm);

    rightArmGroup.rotation.z = -0.2;
    athleteGroup.add(rightArmGroup);

    // Muscular Legs (Thighs & Shins)
    const thighGeo = new THREE.CylinderGeometry(0.11, 0.08, 0.45, 12);
    const shinGeo = new THREE.CylinderGeometry(0.08, 0.055, 0.42, 10);

    const leftLegGroup = new THREE.Group();
    leftLegGroup.position.set(-0.13, 0.95, 0);

    const leftThigh = new THREE.Mesh(thighGeo, kitSecondaryMat);
    leftThigh.position.set(0, -0.22, 0);
    leftLegGroup.add(leftThigh);

    const leftShin = new THREE.Mesh(shinGeo, skinMat);
    leftShin.position.set(0, -0.62, 0);
    leftLegGroup.add(leftShin);

    athleteGroup.add(leftLegGroup);

    const rightLegGroup = new THREE.Group();
    rightLegGroup.position.set(0.13, 0.95, 0);

    const rightThigh = new THREE.Mesh(thighGeo, kitSecondaryMat);
    rightThigh.position.set(0, -0.22, 0);
    rightLegGroup.add(rightThigh);

    const rightShin = new THREE.Mesh(shinGeo, skinMat);
    rightShin.position.set(0, -0.62, 0);
    rightLegGroup.add(rightShin);

    athleteGroup.add(rightLegGroup);

    // Professional Track Spikes / Shoes
    const shoeGeo = new THREE.BoxGeometry(0.09, 0.08, 0.24);
    
    const leftShoe = new THREE.Mesh(shoeGeo, spikeShoeMat);
    leftShoe.position.set(-0.13, 0.04, 0.06);
    leftShoe.castShadow = true;
    athleteGroup.add(leftShoe);

    const rightShoe = new THREE.Mesh(shoeGeo, spikeShoeMat);
    rightShoe.position.set(0.13, 0.04, 0.06);
    rightShoe.castShadow = true;
    athleteGroup.add(rightShoe);

    // 4. ATTACHMENT POINTS (Chest & Back Bibs)
    const bibPlaneGeo = new THREE.PlaneGeometry(0.26, 0.20);

    // Chest Bib Attachment
    const chestBib = new THREE.Mesh(bibPlaneGeo, bibMat);
    chestBib.name = 'ChestBibAttachment';
    chestBib.position.set(0, 1.34, 0.125);
    athleteGroup.add(chestBib);

    // Back Bib Attachment
    const backBib = new THREE.Mesh(bibPlaneGeo, bibMat);
    backBib.name = 'BackBibAttachment';
    backBib.position.set(0, 1.34, -0.125);
    backBib.rotation.y = Math.PI;
    athleteGroup.add(backBib);

    // Apply height scale
    athleteGroup.scale.set(1, data.heightScale, 1);

    // Attach metadata reference
    athleteGroup.userData = {
      lane: data.lane,
      athleteData: data,
      skeleton: skeleton,
      attachments: {
        chestBib,
        backBib,
        leftShoe,
        rightShoe
      }
    };

    return athleteGroup;
  }
}
