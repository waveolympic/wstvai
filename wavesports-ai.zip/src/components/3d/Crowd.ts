import * as THREE from 'three';

export interface SpectatorData {
  index: number;
  baseX: number;
  baseY: number;
  baseZ: number;
  angle: number;
  tier: number;
  phase: number;
  jumpSpeed: number;
}

export class CrowdBuilder {
  public crowdGroup: THREE.Group;
  public instancedMesh!: THREE.InstancedMesh;
  public spectatorData: SpectatorData[] = [];
  public totalSpectators = 0;
  private isAnimated = true;
  private isVisible = true;

  // Temp objects to prevent GC thrashing during render update
  private dummy = new THREE.Object3D();
  private matrix = new THREE.Matrix4();

  constructor() {
    this.crowdGroup = new THREE.Group();
    this.crowdGroup.name = 'StadiumCrowd';
  }

  /**
   * Generates low-poly spectators populated across the 3 seating tiers
   */
  public buildCrowd(): THREE.Group {
    // Low-poly spectator geometry (merged body cylinder + head sphere)
    const bodyGeo = new THREE.CylinderGeometry(0.22, 0.28, 0.75, 6);
    bodyGeo.translate(0, 0.375, 0);

    const headGeo = new THREE.SphereGeometry(0.2, 6, 6);
    headGeo.translate(0, 0.9, 0);

    // Merge body and head geometries into a single low-poly figure geometry
    const spectatorGeo = this.mergeGeometries([bodyGeo, headGeo]);

    // Material with high roughness and vertex coloring support
    const spectatorMat = new THREE.MeshStandardMaterial({
      roughness: 0.6,
      metalness: 0.1,
      flatShading: true
    });

    // Calculate positions along 3 seating tiers
    const tempPositions: { x: number; y: number; z: number; angle: number; tier: number }[] = [];

    const numTiers = 3;
    const rowsPerTier = 6;

    for (let tier = 0; tier < numTiers; tier++) {
      const innerRadiusX = 60 + tier * 25;
      const innerRadiusZ = 85 + tier * 25;
      const outerRadiusX = innerRadiusX + 22;
      const outerRadiusZ = innerRadiusZ + 22;
      const tierHeight = 12;
      const baseHeight = tier * 14 + 1;

      for (let r = 0; r < rowsPerTier; r++) {
        const fr = (r + 0.5) / rowsPerTier;
        const rx = innerRadiusX + fr * (outerRadiusX - innerRadiusX);
        const rz = innerRadiusZ + fr * (outerRadiusZ - innerRadiusZ);
        const baseY = baseHeight + fr * tierHeight;

        // Density spacing (~1.3 units between spectators)
        const avgRadius = (rx + rz) / 2;
        const countInRow = Math.floor((2 * Math.PI * avgRadius) / 1.35);

        for (let s = 0; s < countInRow; s++) {
          const angle = (s / countInRow) * Math.PI * 2;
          
          // Skip small gaps for entrance aisles every 45 degrees
          if (Math.abs((angle % (Math.PI / 4)) - (Math.PI / 8)) < 0.08) {
            continue;
          }

          const x = Math.cos(angle) * rx;
          const z = Math.sin(angle) * rz;

          tempPositions.push({
            x,
            y: baseY + 0.2,
            z,
            angle,
            tier
          });
        }
      }
    }

    this.totalSpectators = tempPositions.length;

    // Create InstancedMesh for high performance
    this.instancedMesh = new THREE.InstancedMesh(
      spectatorGeo,
      spectatorMat,
      this.totalSpectators
    );
    this.instancedMesh.castShadow = true;
    this.instancedMesh.receiveShadow = true;

    // Palette of vibrant Olympic team shirt colors
    const colors = [
      new THREE.Color(0xef4444), // Red
      new THREE.Color(0x3b82f6), // Blue
      new THREE.Color(0x10b981), // Green
      new THREE.Color(0xf59e0b), // Gold / Yellow
      new THREE.Color(0x06b6d4), // Cyan
      new THREE.Color(0x8b5cf6), // Purple
      new THREE.Color(0xf8fafc), // White
      new THREE.Color(0xf97316)  // Orange
    ];

    // Initialize instance matrices and colors
    tempPositions.forEach((pos, idx) => {
      this.dummy.position.set(pos.x, pos.y, pos.z);
      // Face toward center pitch
      this.dummy.rotation.y = Math.atan2(-pos.x, -pos.z) + (Math.random() - 0.5) * 0.2;
      
      // Random subtle height variation
      const scaleY = 0.9 + Math.random() * 0.25;
      this.dummy.scale.set(1, scaleY, 1);
      this.dummy.updateMatrix();

      this.instancedMesh.setMatrixAt(idx, this.dummy.matrix);

      // Assign colorful shirt
      const color = colors[Math.floor(Math.random() * colors.length)];
      this.instancedMesh.setColorAt(idx, color);

      this.spectatorData.push({
        index: idx,
        baseX: pos.x,
        baseY: pos.y,
        baseZ: pos.z,
        angle: pos.angle,
        tier: pos.tier,
        phase: Math.random() * Math.PI * 2,
        jumpSpeed: 6 + Math.random() * 6
      });
    });

    this.instancedMesh.instanceMatrix.needsUpdate = true;
    if (this.instancedMesh.instanceColor) {
      this.instancedMesh.instanceColor.needsUpdate = true;
    }

    this.crowdGroup.add(this.instancedMesh);

    return this.crowdGroup;
  }

  public setAnimated(animated: boolean): void {
    this.isAnimated = animated;
  }

  public setVisible(visible: boolean): void {
    this.isVisible = visible;
    this.crowdGroup.visible = visible;
  }

  public getIsAnimated(): boolean {
    return this.isAnimated;
  }

  public getIsVisible(): boolean {
    return this.isVisible;
  }

  /**
   * Updates crowd animation: Stadium Waves & Cheering Jumps
   */
  public update(elapsedTime: number): void {
    if (!this.isVisible || !this.isAnimated || !this.instancedMesh) return;

    const waveSpeed = 2.8;
    const currentWaveAngle = (elapsedTime * waveSpeed) % (Math.PI * 2);

    for (let i = 0; i < this.totalSpectators; i++) {
      const spec = this.spectatorData[i];

      // Calculate stadium wave jump (stadium wave passing around theta)
      let angleDiff = Math.abs(spec.angle - currentWaveAngle);
      if (angleDiff > Math.PI) angleDiff = Math.PI * 2 - angleDiff;

      let waveJump = 0;
      if (angleDiff < 0.4) {
        waveJump = Math.sin((1 - angleDiff / 0.4) * Math.PI) * 2.2;
      }

      // Individual cheering jump
      const cheerJump = Math.max(0, Math.sin(elapsedTime * spec.jumpSpeed + spec.phase)) * 0.45;

      const totalJump = waveJump > 0.2 ? waveJump : cheerJump;

      // Update position matrix
      this.dummy.position.set(
        spec.baseX,
        spec.baseY + totalJump,
        spec.baseZ
      );
      this.dummy.rotation.y = Math.atan2(-spec.baseX, -spec.baseZ);
      
      // Stretch slightly when jumping up
      const stretch = 1 + (totalJump > 0.5 ? 0.25 : 0);
      this.dummy.scale.set(1, stretch, 1);
      this.dummy.updateMatrix();

      this.instancedMesh.setMatrixAt(i, this.dummy.matrix);
    }

    this.instancedMesh.instanceMatrix.needsUpdate = true;
  }

  /**
   * Helper to merge buffer geometries without external imports
   */
  private mergeGeometries(geometries: THREE.BufferGeometry[]): THREE.BufferGeometry {
    let totalVertices = 0;
    let totalIndices = 0;

    geometries.forEach(geo => {
      totalVertices += geo.attributes.position.count;
      if (geo.index) totalIndices += geo.index.count;
    });

    const mergedPos = new Float32Array(totalVertices * 3);
    const mergedNorm = new Float32Array(totalVertices * 3);
    const mergedIndices = new Uint32Array(totalIndices);

    let vertOffset = 0;
    let indexOffset = 0;

    geometries.forEach(geo => {
      const pos = geo.attributes.position;
      const norm = geo.attributes.normal;
      const count = pos.count;

      for (let i = 0; i < count; i++) {
        mergedPos[(vertOffset + i) * 3] = pos.getX(i);
        mergedPos[(vertOffset + i) * 3 + 1] = pos.getY(i);
        mergedPos[(vertOffset + i) * 3 + 2] = pos.getZ(i);

        if (norm) {
          mergedNorm[(vertOffset + i) * 3] = norm.getX(i);
          mergedNorm[(vertOffset + i) * 3 + 1] = norm.getY(i);
          mergedNorm[(vertOffset + i) * 3 + 2] = norm.getZ(i);
        }
      }

      if (geo.index) {
        const idx = geo.index;
        for (let i = 0; i < idx.count; i++) {
          mergedIndices[indexOffset + i] = idx.getX(i) + vertOffset;
        }
        indexOffset += idx.count;
      }

      vertOffset += count;
    });

    const mergedGeo = new THREE.BufferGeometry();
    mergedGeo.setAttribute('position', new THREE.BufferAttribute(mergedPos, 3));
    mergedGeo.setAttribute('normal', new THREE.BufferAttribute(mergedNorm, 3));
    mergedGeo.setIndex(new THREE.BufferAttribute(mergedIndices, 1));

    return mergedGeo;
  }
}
