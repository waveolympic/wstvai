import * as THREE from 'three';
import { TextureGenerator } from './textures';

export class ForecourtBuilder {
  public fountainJets: THREE.Mesh[] = [];
  public flameParticles: THREE.Points[] = [];
  public flameLights: THREE.PointLight[] = [];

  /**
   * Builds the stadium forecourt plaza, pools, fountains, Olympic cauldrons, and gardens
   */
  public buildForecourt(): THREE.Group {
    const group = new THREE.Group();
    group.name = 'Forecourt';

    // Materials
    const plazaPavingMat = new THREE.MeshStandardMaterial({
      color: 0xd1d5db,
      roughness: 0.4,
      metalness: 0.1
    });

    const poolBorderMat = new THREE.MeshStandardMaterial({
      color: 0x111827,
      roughness: 0.2,
      metalness: 0.8
    });

    const poolWaterMat = new THREE.MeshPhysicalMaterial({
      color: 0x0284c7,
      roughness: 0.05,
      transmission: 0.85,
      transparent: true,
      opacity: 0.9,
      ior: 1.333,
      metalness: 0.1,
      normalMap: TextureGenerator.createWaterNormalTexture(),
      normalScale: new THREE.Vector2(0.2, 0.2)
    });

    const cauldronSteelMat = new THREE.MeshStandardMaterial({
      color: 0xe2e8f0,
      metalness: 0.9,
      roughness: 0.15
    });

    const grassMat = new THREE.MeshStandardMaterial({
      color: 0x16a34a,
      roughness: 0.8
    });

    const hedgeMat = new THREE.MeshStandardMaterial({
      color: 0x14532d,
      roughness: 0.9
    });

    const palmTrunkMat = new THREE.MeshStandardMaterial({
      color: 0x78350f,
      roughness: 0.8
    });

    const palmLeafMat = new THREE.MeshStandardMaterial({
      color: 0x15803d,
      roughness: 0.5,
      side: THREE.DoubleSide
    });

    // 1. PLAZA CONCOURSE GROUND PLANE
    const plazaGeo = new THREE.PlaneGeometry(500, 300);
    const plazaMesh = new THREE.Mesh(plazaGeo, plazaPavingMat);
    plazaMesh.rotation.x = -Math.PI / 2;
    plazaMesh.position.set(0, 0.02, 280);
    plazaMesh.receiveShadow = true;
    group.add(plazaMesh);

    // Concourse Decorative Pattern Inlays
    const inlayGeo = new THREE.RingGeometry(20, 45, 32);
    const inlayMat = new THREE.MeshStandardMaterial({ color: 0x9ca3af, roughness: 0.5 });
    const inlayLeft = new THREE.Mesh(inlayGeo, inlayMat);
    inlayLeft.rotation.x = -Math.PI / 2;
    inlayLeft.position.set(-130, 0.04, 260);
    group.add(inlayLeft);

    const inlayRight = inlayLeft.clone();
    inlayRight.position.set(130, 0.04, 260);
    group.add(inlayRight);

    // 2. REFLECTING WATER POOLS & FOUNTAINS
    const poolWidth = 140;
    const poolLength = 65;

    // Left Pool
    const poolBorderGeo = new THREE.BoxGeometry(poolWidth, 2, poolLength);
    const leftPoolBorder = new THREE.Mesh(poolBorderGeo, poolBorderMat);
    leftPoolBorder.position.set(-130, 0.8, 300);
    group.add(leftPoolBorder);

    const leftPoolWaterGeo = new THREE.PlaneGeometry(poolWidth - 4, poolLength - 4);
    const leftPoolWater = new THREE.Mesh(leftPoolWaterGeo, poolWaterMat);
    leftPoolWater.rotation.x = -Math.PI / 2;
    leftPoolWater.position.set(-130, 1.8, 300);
    group.add(leftPoolWater);

    // Right Pool
    const rightPoolBorder = leftPoolBorder.clone();
    rightPoolBorder.position.set(130, 0.8, 300);
    group.add(rightPoolBorder);

    const rightPoolWater = leftPoolWater.clone();
    rightPoolWater.position.set(130, 1.8, 300);
    group.add(rightPoolWater);

    // Central Square Reflecting Basin
    const centerBasinBorder = new THREE.Mesh(new THREE.BoxGeometry(110, 2, 55), poolBorderMat);
    centerBasinBorder.position.set(0, 0.8, 350);
    group.add(centerBasinBorder);

    const centerBasinWater = new THREE.Mesh(new THREE.PlaneGeometry(106, 51), poolWaterMat);
    centerBasinWater.rotation.x = -Math.PI / 2;
    centerBasinWater.position.set(0, 1.8, 350);
    group.add(centerBasinWater);

    // FOUNTAIN WATER JETS
    const fountainMat = new THREE.MeshStandardMaterial({
      color: 0xe0f2fe,
      roughness: 0.1,
      transparent: true,
      opacity: 0.85,
      emissive: 0x38bdf8,
      emissiveIntensity: 0.2
    });

    const fountainPositions = [
      // Left Pool jets
      { x: -160, z: 300 }, { x: -130, z: 300 }, { x: -100, z: 300 },
      // Right Pool jets
      { x: 100, z: 300 }, { x: 130, z: 300 }, { x: 160, z: 300 },
      // Center basin jets
      { x: -30, z: 350 }, { x: 0, z: 350 }, { x: 30, z: 350 }
    ];

    fountainPositions.forEach(pos => {
      const jetGeo = new THREE.CylinderGeometry(0.8, 2.5, 14, 12);
      const jet = new THREE.Mesh(jetGeo, fountainMat);
      jet.position.set(pos.x, 8.5, pos.z);
      group.add(jet);
      this.fountainJets.push(jet);
    });

    // 3. OLYMPIC CAULDRONS & BURNING FLAME
    const cauldronPositions = [
      { x: -210, z: 270 },
      { x: 210, z: 270 }
    ];

    cauldronPositions.forEach(pos => {
      // Sculptural Tripod Base
      const tripodGroup = new THREE.Group();
      tripodGroup.position.set(pos.x, 0, pos.z);

      // 3 Curved Legs
      for (let i = 0; i < 3; i++) {
        const legAngle = (i / 3) * Math.PI * 2;
        const legCurve = new THREE.QuadraticBezierCurve3(
          new THREE.Vector3(Math.cos(legAngle) * 12, 0, Math.sin(legAngle) * 12),
          new THREE.Vector3(Math.cos(legAngle) * 4, 14, Math.sin(legAngle) * 4),
          new THREE.Vector3(Math.cos(legAngle) * 8, 24, Math.sin(legAngle) * 8)
        );
        const legGeo = new THREE.TubeGeometry(legCurve, 20, 1.2, 8, false);
        const legMesh = new THREE.Mesh(legGeo, cauldronSteelMat);
        tripodGroup.add(legMesh);
      }

      // Cauldron Bowl
      const bowlGeo = new THREE.CylinderGeometry(10, 5, 6, 24);
      const bowlMesh = new THREE.Mesh(bowlGeo, cauldronSteelMat);
      bowlMesh.position.y = 26;
      tripodGroup.add(bowlMesh);

      // Burning Flame Particle System
      const particleCount = 120;
      const flameGeo = new THREE.BufferGeometry();
      const positions = new Float32Array(particleCount * 3);
      const colors = new Float32Array(particleCount * 3);

      for (let i = 0; i < particleCount; i++) {
        positions[i * 3] = (Math.random() - 0.5) * 8;
        positions[i * 3 + 1] = 29 + Math.random() * 12;
        positions[i * 3 + 2] = (Math.random() - 0.5) * 8;

        // Orange/Gold flame color gradient
        colors[i * 3] = 1.0;
        colors[i * 3 + 1] = 0.4 + Math.random() * 0.5;
        colors[i * 3 + 2] = 0.0;
      }

      flameGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
      flameGeo.setAttribute('color', new THREE.BufferAttribute(colors, 3));

      const flameMat = new THREE.PointsMaterial({
        size: 3.5,
        vertexColors: true,
        transparent: true,
        opacity: 0.85,
        blending: THREE.AdditiveBlending
      });

      const flamePoints = new THREE.Points(flameGeo, flameMat);
      tripodGroup.add(flamePoints);
      this.flameParticles.push(flamePoints);

      // Warm Flame Light
      const flameLight = new THREE.PointLight(0xff7700, 3, 80);
      flameLight.position.set(0, 32, 0);
      tripodGroup.add(flameLight);
      this.flameLights.push(flameLight);

      group.add(tripodGroup);
    });

    // 4. LANDSCAPED GARDEN BEDS & PALM TREES
    const numPalms = 24;
    for (let i = 0; i < numPalms; i++) {
      const isLeft = i % 2 === 0;
      const x = (isLeft ? -1 : 1) * (70 + (i % 6) * 28);
      const z = 220 + Math.floor(i / 2) * 22;

      const palmGroup = new THREE.Group();
      palmGroup.position.set(x, 0, z);

      // Trunk
      const trunkGeo = new THREE.CylinderGeometry(0.8, 1.2, 16, 8);
      const trunkMesh = new THREE.Mesh(trunkGeo, palmTrunkMat);
      trunkMesh.position.y = 8;
      trunkMesh.rotation.z = (Math.random() - 0.5) * 0.15;
      palmGroup.add(trunkMesh);

      // Fronds / Canopy
      for (let f = 0; f < 7; f++) {
        const frondAngle = (f / 7) * Math.PI * 2;
        const frondCurve = new THREE.QuadraticBezierCurve3(
          new THREE.Vector3(0, 16, 0),
          new THREE.Vector3(Math.cos(frondAngle) * 6, 18, Math.sin(frondAngle) * 6),
          new THREE.Vector3(Math.cos(frondAngle) * 11, 14, Math.sin(frondAngle) * 11)
        );
        const frondGeo = new THREE.TubeGeometry(frondCurve, 10, 0.8, 6, false);
        const frondMesh = new THREE.Mesh(frondGeo, palmLeafMat);
        palmGroup.add(frondMesh);
      }

      group.add(palmGroup);
    }

    // Curving Floral Hedges
    for (let side = -1; side <= 1; side += 2) {
      const gardenBedGeo = new THREE.CylinderGeometry(40, 40, 0.8, 32);
      const gardenBed = new THREE.Mesh(gardenBedGeo, grassMat);
      gardenBed.scale.set(2.5, 1, 0.8);
      gardenBed.position.set(side * 130, 0.4, 380);
      group.add(gardenBed);

      const hedgeGeo = new THREE.TorusGeometry(32, 2.5, 8, 32, Math.PI);
      const hedgeMesh = new THREE.Mesh(hedgeGeo, hedgeMat);
      hedgeMesh.rotation.x = Math.PI / 2;
      hedgeMesh.position.set(side * 130, 1.2, 380);
      group.add(hedgeMesh);
    }

    return group;
  }

  /**
   * Animate water jets, fountains, and cauldron flame particles
   */
  public update(time: number): void {
    // Animate fountain water jets
    this.fountainJets.forEach((jet, idx) => {
      const scaleY = 1 + Math.sin(time * 4 + idx) * 0.18;
      jet.scale.set(1, scaleY, 1);
    });

    // Animate burning cauldron flame particles
    this.flameParticles.forEach(flame => {
      const posAttr = flame.geometry.attributes.position as THREE.BufferAttribute;
      const count = posAttr.count;

      for (let i = 0; i < count; i++) {
        let y = posAttr.getY(i);
        y += 0.3 + Math.random() * 0.2;
        if (y > 42) {
          y = 28 + Math.random() * 2;
          posAttr.setX(i, (Math.random() - 0.5) * 8);
          posAttr.setZ(i, (Math.random() - 0.5) * 8);
        }
        posAttr.setY(i, y);
      }
      posAttr.needsUpdate = true;
    });

    // Flicker flame lights
    this.flameLights.forEach((light, i) => {
      light.intensity = 2.8 + Math.sin(time * 12 + i) * 0.6;
    });
  }
}
