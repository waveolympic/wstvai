import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { StadiumBuilder } from './Stadium';
import { ForecourtBuilder } from './Forecourt';
import { CitySkylineBuilder } from './CitySkyline';
import { TrafficBuilder } from './Traffic';
import { EnvironmentBuilder } from './Environment';
import { CrowdBuilder } from './Crowd';
import { Track100mBuilder } from './Track100m';

export interface CameraPreset {
  id: string;
  label: string;
  category: 'exterior' | 'track' | 'interactive';
  description: string;
  position: THREE.Vector3;
  target: THREE.Vector3;
}

export const CAMERA_PRESETS: CameraPreset[] = [
  {
    id: 'sprint-overview',
    label: '100m Track Overview',
    category: 'track',
    description: 'High broadcast angle showing full 100m straightaway from start to finish line',
    position: new THREE.Vector3(0, 32, 48),
    target: new THREE.Vector3(0, 1.2, 0)
  },
  {
    id: 'start-line',
    label: 'Start Line View',
    category: 'track',
    description: 'Broadcast start line camera facing sprinters lined up on starting blocks',
    position: new THREE.Vector3(-62, 3.2, 0),
    target: new THREE.Vector3(-49, 1.2, 0)
  },
  {
    id: 'finish-line',
    label: 'Finish Line Camera',
    category: 'track',
    description: 'High-speed photo-finish camera aligned precisely along the finish line plane',
    position: new THREE.Vector3(51.2, 2.5, 18),
    target: new THREE.Vector3(50, 1.2, -18)
  },
  {
    id: 'trackside',
    label: 'Trackside Tracking Angle',
    category: 'track',
    description: 'Low tracking camera at the 50m mark looking along Lane 4',
    position: new THREE.Vector3(0, 1.8, -18),
    target: new THREE.Vector3(12, 1.4, 0)
  },
  {
    id: 'athlete-closeup',
    label: 'Sprinter Close-Up (Lane 4)',
    category: 'track',
    description: 'Broadcast zoom camera focused on Lane 4 sprinter Hughes Sterling (GBR)',
    position: new THREE.Vector3(-47.5, 1.6, 2.8),
    target: new THREE.Vector3(-49.8, 1.2, 1.6)
  },
  {
    id: 'overhead',
    label: 'Overhead Bird\'s-Eye',
    category: 'track',
    description: 'Top-down orthogonal camera looking directly down at all 8 competition lanes',
    position: new THREE.Vector3(0, 68, 0.1),
    target: new THREE.Vector3(0, 0, 0)
  },
  {
    id: 'exterior-overview',
    label: 'Stadium Aerial Overview',
    category: 'exterior',
    description: 'Panoramic aerial shot showing stadium, city bay, and sunset skyline',
    position: new THREE.Vector3(0, 168, 318),
    target: new THREE.Vector3(0, 12, -45)
  },
  {
    id: 'exterior-plaza',
    label: 'Plaza & Torches',
    category: 'exterior',
    description: 'Ground view from the forecourt pools and burning Olympic cauldrons',
    position: new THREE.Vector3(-110, 18, 320),
    target: new THREE.Vector3(0, 35, 100)
  },
  {
    id: 'exterior-skyline',
    label: 'Bay & Monorail',
    category: 'exterior',
    description: 'Panoramic view looking across the bay bridge and monorail transit',
    position: new THREE.Vector3(260, 90, 180),
    target: new THREE.Vector3(-80, 20, -200)
  }
];

export class SceneManager {
  private container: HTMLDivElement;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private renderer: THREE.WebGLRenderer;
  private controls: OrbitControls;
  private clock: THREE.Clock;

  private forecourtBuilder: ForecourtBuilder;
  private citySkylineBuilder: CitySkylineBuilder;
  private trafficBuilder: TrafficBuilder;
  private environmentBuilder: EnvironmentBuilder;
  private crowdBuilder: CrowdBuilder;
  private track100mBuilder: Track100mBuilder;

  private animationFrameId: number | null = null;

  // Camera transition state
  private targetPos = new THREE.Vector3();
  private targetLook = new THREE.Vector3();
  private isTransitioning = false;
  private currentPresetId = 'sprint-overview';
  private onPresetChangeCallback?: (presetId: string) => void;

  constructor(container: HTMLDivElement, onPresetChange?: (presetId: string) => void) {
    this.container = container;
    this.onPresetChangeCallback = onPresetChange;

    // 1. SCENE SETUP
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0b111e);
    this.clock = new THREE.Clock();

    // 2. CAMERA SETUP
    const aspect = window.innerWidth / window.innerHeight;
    this.camera = new THREE.PerspectiveCamera(46, aspect, 1, 3500);

    const initialPreset = CAMERA_PRESETS[0]; // sprint-overview
    this.camera.position.copy(initialPreset.position);
    this.targetPos.copy(initialPreset.position);
    this.targetLook.copy(initialPreset.target);

    // 3. RENDERER SETUP
    this.renderer = new THREE.WebGLRenderer({
      antialias: true,
      powerPreference: 'high-performance',
      precision: 'highp'
    });
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;

    // Append canvas to DOM
    this.container.appendChild(this.renderer.domElement);

    // 4. ORBIT CONTROLS SETUP
    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.enableDamping = true;
    this.controls.dampingFactor = 0.05;
    this.controls.maxPolarAngle = Math.PI / 2 - 0.02; // Prevent camera going below ground
    this.controls.minDistance = 2;
    this.controls.maxDistance = 1200;
    this.controls.target.copy(initialPreset.target);

    // If user manually rotates or pans, mark preset as 'free'
    this.controls.addEventListener('start', () => {
      this.isTransitioning = false;
      this.setPresetId('free');
    });

    // 5. BUILD SCENE COMPONENTS
    // Environment
    this.environmentBuilder = new EnvironmentBuilder();
    this.environmentBuilder.setupEnvironment(this.scene);

    // Main Stadium
    const stadium = StadiumBuilder.buildStadium();
    this.scene.add(stadium);

    // 100m Sprint Venue (Athletics Track, 8 Lanes, Starting Blocks, Sprinters, Officials)
    this.track100mBuilder = new Track100mBuilder();
    const track100m = this.track100mBuilder.build100mVenue();
    this.scene.add(track100m);

    // Forecourt Plaza, Fountains, Olympic Torches
    this.forecourtBuilder = new ForecourtBuilder();
    const forecourt = this.forecourtBuilder.buildForecourt();
    this.scene.add(forecourt);

    // Surrounding City Skyline, Bay, Marina, Monorail & Bridges
    this.citySkylineBuilder = new CitySkylineBuilder();
    const citySkyline = this.citySkylineBuilder.buildCitySkyline();
    this.scene.add(citySkyline);

    // Traffic System
    this.trafficBuilder = new TrafficBuilder();
    const traffic = this.trafficBuilder.buildTraffic();
    this.scene.add(traffic);

    // Stadium Crowd Simulation
    this.crowdBuilder = new CrowdBuilder();
    const crowd = this.crowdBuilder.buildCrowd();
    this.scene.add(crowd);

    // 6. EVENT LISTENERS
    window.addEventListener('resize', this.onWindowResize);

    // 7. START ANIMATION LOOP
    this.animate();
  }

  public setPreset(presetId: string): void {
    const preset = CAMERA_PRESETS.find(p => p.id === presetId);
    if (!preset) return;

    this.targetPos.copy(preset.position);
    this.targetLook.copy(preset.target);
    this.isTransitioning = true;
    this.setPresetId(presetId);
  }

  public focusLane(lane: number): void {
    const laneWidth = 3.2;
    const laneZ = (lane - 1 - 3.5) * laneWidth;
    const startX = -50;

    this.targetPos.set(startX + 2.5, 1.8, laneZ + 1.8);
    this.targetLook.set(startX + 0.1, 1.1, laneZ);
    this.isTransitioning = true;
    this.setPresetId(`lane-${lane}`);
  }

  public setCrowdAnimated(animated: boolean): void {
    if (this.crowdBuilder) {
      this.crowdBuilder.setAnimated(animated);
    }
  }

  public setCrowdVisible(visible: boolean): void {
    if (this.crowdBuilder) {
      this.crowdBuilder.setVisible(visible);
    }
  }

  private setPresetId(id: string): void {
    if (this.currentPresetId !== id) {
      this.currentPresetId = id;
      if (this.onPresetChangeCallback) {
        this.onPresetChangeCallback(id);
      }
    }
  }

  private onWindowResize = (): void => {
    if (!this.container) return;
    const width = window.innerWidth;
    const height = window.innerHeight;

    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();

    this.renderer.setSize(width, height);
  };

  private animate = (): void => {
    this.animationFrameId = requestAnimationFrame(this.animate);

    const delta = this.clock.getDelta();
    const elapsedTime = this.clock.getElapsedTime();

    // Camera transition interpolation
    if (this.isTransitioning) {
      const lerpSpeed = 0.05;
      this.camera.position.lerp(this.targetPos, lerpSpeed);
      this.controls.target.lerp(this.targetLook, lerpSpeed);

      if (
        this.camera.position.distanceTo(this.targetPos) < 0.5 &&
        this.controls.target.distanceTo(this.targetLook) < 0.5
      ) {
        this.camera.position.copy(this.targetPos);
        this.controls.target.copy(this.targetLook);
        this.isTransitioning = false;
      }
    }

    this.controls.update();

    // Subtle environmental animations
    this.forecourtBuilder.update(elapsedTime);
    this.citySkylineBuilder.update(elapsedTime);
    this.trafficBuilder.update(delta);
    this.environmentBuilder.update(delta);
    this.crowdBuilder.update(elapsedTime);

    // Render frame
    this.renderer.render(this.scene, this.camera);
  };

  public destroy(): void {
    if (this.animationFrameId !== null) {
      cancelAnimationFrame(this.animationFrameId);
    }
    window.removeEventListener('resize', this.onWindowResize);
    this.controls.dispose();
    if (this.renderer && this.renderer.domElement) {
      this.renderer.domElement.remove();
      this.renderer.dispose();
    }
  }
}

