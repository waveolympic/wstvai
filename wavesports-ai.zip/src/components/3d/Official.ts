import * as THREE from 'three';

export type OfficialRole = 'Starter' | 'AssistantStarter' | 'TrackOfficial' | 'FinishJudge' | 'Timekeeper';

export interface OfficialData {
  role: OfficialRole;
  title: string;
  position: THREE.Vector3;
  rotationY: number;
}

export class OfficialBuilder {
  /**
   * Constructs high-detail 3D Olympic Track Officials with formal uniforms,
   * lanyards, equipment (stopwatches, starter transducers, clipboards),
   * and precise floor collision alignment.
   */
  static createOfficial(data: OfficialData): THREE.Group {
    const officialGroup = new THREE.Group();
    const safeRole = data?.role || 'Official';
    const safeTitle = data?.title || 'Track Official';
    officialGroup.name = `Official_${safeRole}_${safeTitle.replace(/\s+/g, '_')}`;

    // Uniform Materials
    const blazerMat = new THREE.MeshStandardMaterial({
      color: 0x1e3a8a, // Olympic Navy Blazer
      roughness: 0.5
    });

    const shirtMat = new THREE.MeshStandardMaterial({
      color: 0xffffff, // Crisp White Shirt
      roughness: 0.3
    });

    const trousersMat = new THREE.MeshStandardMaterial({
      color: 0x334155, // Charcoal Slacks
      roughness: 0.6
    });

    const skinMat = new THREE.MeshStandardMaterial({
      color: 0xd2b48c,
      roughness: 0.6
    });

    const shoeMat = new THREE.MeshStandardMaterial({
      color: 0x0f172a, // Black Dress Shoes
      roughness: 0.3
    });

    const goldMat = new THREE.MeshStandardMaterial({
      color: 0xfacc15,
      metalness: 0.8,
      roughness: 0.2
    });

    // Torso (Navy Blazer & Shirt)
    const torsoGeo = new THREE.CylinderGeometry(0.25, 0.21, 0.6, 12);
    const torsoMesh = new THREE.Mesh(torsoGeo, blazerMat);
    torsoMesh.position.set(0, 1.25, 0);
    torsoMesh.castShadow = true;
    officialGroup.add(torsoMesh);

    // Inner Shirt Collar & Tie
    const shirtGeo = new THREE.CylinderGeometry(0.12, 0.14, 0.2, 8);
    const shirtMesh = new THREE.Mesh(shirtGeo, shirtMat);
    shirtMesh.position.set(0, 1.48, 0.08);
    officialGroup.add(shirtMesh);

    // Head & Hair
    const headGeo = new THREE.SphereGeometry(0.12, 16, 16);
    headGeo.scale(1, 1.15, 1);
    const headMesh = new THREE.Mesh(headGeo, skinMat);
    headMesh.position.set(0, 1.72, 0);
    headMesh.castShadow = true;
    officialGroup.add(headMesh);

    // Official Hat / Cap
    const capGeo = new THREE.CylinderGeometry(0.13, 0.13, 0.06, 16);
    const capBrimGeo = new THREE.BoxGeometry(0.16, 0.02, 0.12);
    const capMat = new THREE.MeshStandardMaterial({ color: 0x1e3a8a });

    const capMesh = new THREE.Mesh(capGeo, capMat);
    capMesh.position.set(0, 1.82, 0);
    officialGroup.add(capMesh);

    const capBrimMesh = new THREE.Mesh(capBrimGeo, capMat);
    capBrimMesh.position.set(0, 1.80, 0.1);
    officialGroup.add(capBrimMesh);

    // Official ID Lanyard
    const lanyardGeo = new THREE.TorusGeometry(0.18, 0.012, 8, 16);
    const lanyardMat = new THREE.MeshStandardMaterial({ color: 0xd97706 }); // Golden yellow strap
    const lanyardMesh = new THREE.Mesh(lanyardGeo, lanyardMat);
    lanyardMesh.position.set(0, 1.42, 0.06);
    lanyardMesh.rotation.x = Math.PI / 3;
    officialGroup.add(lanyardMesh);

    // Arms
    const armGeo = new THREE.CylinderGeometry(0.065, 0.055, 0.55, 8);

    const leftArm = new THREE.Mesh(armGeo, blazerMat);
    leftArm.position.set(-0.28, 1.2, 0);
    leftArm.rotation.z = 0.15;
    officialGroup.add(leftArm);

    const rightArm = new THREE.Mesh(armGeo, blazerMat);
    rightArm.position.set(0.28, 1.2, 0);
    rightArm.rotation.z = -0.15;
    officialGroup.add(rightArm);

    // Legs (Trousers)
    const legGeo = new THREE.CylinderGeometry(0.09, 0.07, 0.85, 10);

    const leftLeg = new THREE.Mesh(legGeo, trousersMat);
    leftLeg.position.set(-0.12, 0.48, 0);
    officialGroup.add(leftLeg);

    const rightLeg = new THREE.Mesh(legGeo, trousersMat);
    rightLeg.position.set(0.12, 0.48, 0);
    officialGroup.add(rightLeg);

    // Dress Shoes
    const shoeGeo = new THREE.BoxGeometry(0.09, 0.08, 0.22);

    const leftShoe = new THREE.Mesh(shoeGeo, shoeMat);
    leftShoe.position.set(-0.12, 0.04, 0.04);
    officialGroup.add(leftShoe);

    const rightShoe = new THREE.Mesh(shoeGeo, shoeMat);
    rightShoe.position.set(0.12, 0.04, 0.04);
    officialGroup.add(rightShoe);

    // ROLE SPECIFIC EQUIPMENT ACCESSORY
    if (data.role === 'Starter') {
      // Starter Electronic Transducer / Pistol
      const starterDeviceGeo = new THREE.BoxGeometry(0.06, 0.18, 0.06);
      const starterDevice = new THREE.Mesh(starterDeviceGeo, goldMat);
      starterDevice.position.set(0.35, 1.35, 0.1);
      officialGroup.add(starterDevice);
    } else if (data.role === 'TrackOfficial' || data.role === 'AssistantStarter') {
      // Official Clipboard
      const boardGeo = new THREE.BoxGeometry(0.18, 0.25, 0.02);
      const boardMat = new THREE.MeshStandardMaterial({ color: 0x78350f });
      const board = new THREE.Mesh(boardGeo, boardMat);
      board.position.set(-0.25, 1.05, 0.2);
      board.rotation.x = 0.5;
      officialGroup.add(board);
    }

    // Set position and orientation
    officialGroup.position.copy(data.position);
    officialGroup.rotation.y = data.rotationY;

    officialGroup.userData = {
      role: data?.role || 'Official',
      title: data?.title || 'Track Official'
    };

    return officialGroup;
  }
}
