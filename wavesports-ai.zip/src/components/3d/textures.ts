import * as THREE from 'three';

/**
 * Utility class to generate high-quality procedural textures at runtime
 * for PBR materials without relying on external file downloads.
 */
export class TextureGenerator {
  /**
   * Generates a realistic water normal map canvas texture
   */
  static createWaterNormalTexture(): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 512;
    const ctx = canvas.getContext('2d')!;
    
    const imgData = ctx.createImageData(512, 512);
    const data = imgData.data;

    for (let y = 0; y < 512; y++) {
      for (let x = 0; x < 512; x++) {
        const index = (y * 512 + x) * 4;
        const nx = Math.sin(x * 0.05) * Math.cos(y * 0.03) * 0.5 + 0.5;
        const ny = Math.cos(x * 0.04) * Math.sin(y * 0.06) * 0.5 + 0.5;
        
        data[index] = Math.floor(nx * 255);     // Red (X normal)
        data[index + 1] = Math.floor(ny * 255); // Green (Y normal)
        data[index + 2] = 255;                  // Blue (Z normal)
        data[index + 3] = 255;
      }
    }
    ctx.putImageData(imgData, 0, 0);

    const texture = new THREE.CanvasTexture(canvas);
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    texture.repeat.set(8, 8);
    return texture;
  }

  /**
   * Creates an Olympic Track texture with blue lane lines and white stripes
   */
  static createTrackTexture(): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = 1024;
    canvas.height = 1024;
    const ctx = canvas.getContext('2d')!;

    // Rich Olympic blue background
    ctx.fillStyle = '#1052a0';
    ctx.fillRect(0, 0, 1024, 1024);

    // Oval track lanes
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 3;

    const centerX = 512;
    const centerY = 512;
    const numLanes = 8;
    const baseRadiusX = 380;
    const baseRadiusY = 240;

    for (let i = 0; i < numLanes; i++) {
      const rx = baseRadiusX - i * 16;
      const ry = baseRadiusY - i * 16;
      ctx.beginPath();
      ctx.ellipse(centerX, centerY, rx, ry, 0, 0, Math.PI * 2);
      ctx.stroke();
    }

    // Start / finish lines
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(centerX - 10, centerY + 180, 20, 80);

    const texture = new THREE.CanvasTexture(canvas);
    texture.anisotropy = 8;
    return texture;
  }

  /**
   * Generates a high-precision 100m sprint straightaway track surface texture
   * with 8 distinct competition lanes, lane numbers 1-8, start line, finish line,
   * and World Athletics measurement markings.
   */
  static createSprint100mTrackTexture(): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = 2048;
    canvas.height = 1024;
    const ctx = canvas.getContext('2d')!;

    // World Athletics Terracotta Red / Olympic Blue track surface
    ctx.fillStyle = '#b93829'; // Terracotta track red
    ctx.fillRect(0, 0, 2048, 1024);

    // Subtle track rubber grain texture
    ctx.fillStyle = 'rgba(0, 0, 0, 0.04)';
    for (let i = 0; i < 8000; i++) {
      const rx = Math.random() * 2048;
      const ry = Math.random() * 1024;
      ctx.fillRect(rx, ry, 2, 2);
    }

    const numLanes = 8;
    const laneHeight = 1024 / numLanes; // 128px per lane

    // White lane divider lines
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 6;

    for (let i = 0; i <= numLanes; i++) {
      const y = i * laneHeight;
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(2048, y);
      ctx.stroke();
    }

    // START LINE (at X = 300)
    const startX = 300;
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(startX - 6, 0, 12, 1024);

    // FINISH LINE (at X = 1750) - World Athletics Checkered Finish
    const finishX = 1750;
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(finishX - 6, 0, 12, 1024);
    
    // Red/White checkered finish line accents
    const squareSize = laneHeight / 4;
    for (let l = 0; l < numLanes; l++) {
      for (let sq = 0; sq < 4; sq++) {
        const isRed = (l + sq) % 2 === 0;
        ctx.fillStyle = isRed ? '#d90429' : '#ffffff';
        ctx.fillRect(finishX - 6, l * laneHeight + sq * squareSize, 12, squareSize);
      }
    }

    // PAINTED LANE NUMBERS 1 THROUGH 8 (Placed behind start line, facing sprinters)
    ctx.font = 'bold 72px "Plus Jakarta Sans", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = '#ffffff';

    for (let l = 0; l < numLanes; l++) {
      const laneNum = l + 1;
      const centerY = l * laneHeight + laneHeight / 2;
      
      // Paint lane number on track surface before start line
      ctx.save();
      ctx.translate(startX - 100, centerY);
      ctx.scale(1.2, 0.9); // Stretched paint effect
      ctx.fillText(`${laneNum}`, 0, 0);
      ctx.restore();

      // Repeat lane numbers past finish line
      ctx.save();
      ctx.translate(finishX + 120, centerY);
      ctx.scale(1.2, 0.9);
      ctx.fillText(`${laneNum}`, 0, 0);
      ctx.restore();
    }

    // Start / Finish textual floor markings
    ctx.font = 'bold 24px sans-serif';
    ctx.fillStyle = 'rgba(255, 255, 255, 0.85)';
    ctx.fillText('START 100M', startX - 210, 40);
    ctx.fillText('FINISH', finishX + 40, 40);

    const texture = new THREE.CanvasTexture(canvas);
    texture.anisotropy = 16;
    return texture;
  }

  /**
   * Generates a high-detail athlete race bib texture for chest/back mounting
   */
  static createAthleteBibTexture(nationCode: string, bibNumber: number, athleteName: string): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 384;
    const ctx = canvas.getContext('2d')!;

    // Clean white bib background with rounded corners
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, 512, 384);

    // Top Pacifica Regional Olympics header bar
    const grad = ctx.createLinearGradient(0, 0, 512, 0);
    grad.addColorStop(0, '#0077b6');
    grad.addColorStop(1, '#00b4d8');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 512, 80);

    // Header Text
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 22px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('PACIFICA OLYMPICS 2026', 256, 36);

    ctx.font = 'bold 16px sans-serif';
    ctx.fillStyle = '#ffd166';
    ctx.fillText('KLEMONSERRAT STADIUM', 256, 62);

    // Nation Flag Bar Accent
    ctx.fillStyle = '#0b3954';
    ctx.fillRect(30, 95, 120, 40);
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 24px sans-serif';
    ctx.fillText(nationCode, 90, 123);

    // Athlete Name
    ctx.fillStyle = '#1e293b';
    ctx.font = 'bold 22px sans-serif';
    ctx.textAlign = 'left';
    ctx.fillText(athleteName.toUpperCase(), 170, 123);

    // Giant Bib Number
    ctx.fillStyle = '#0f172a';
    ctx.font = '900 130px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(`${bibNumber}`, 256, 275);

    // Bottom Sponsor Logo
    ctx.fillStyle = '#64748b';
    ctx.font = 'bold 16px sans-serif';
    ctx.fillText('WAVESPORTS AI • OFFICIAL TIMING', 256, 350);

    // Bib safety pins in corners
    ctx.fillStyle = '#94a3b8';
    ctx.beginPath();
    ctx.arc(20, 20, 6, 0, Math.PI * 2);
    ctx.arc(492, 20, 6, 0, Math.PI * 2);
    ctx.arc(20, 364, 6, 0, Math.PI * 2);
    ctx.arc(492, 364, 6, 0, Math.PI * 2);
    ctx.fill();

    const texture = new THREE.CanvasTexture(canvas);
    return texture;
  }

  /**
   * Generates a digital LED scoreboard texture for wind gauges & timing clocks
   */
  static createDigitalDisplayTexture(title: string, mainValue: string, statusText: string): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 256;
    const ctx = canvas.getContext('2d')!;

    // Black matrix LED board background
    ctx.fillStyle = '#050811';
    ctx.fillRect(0, 0, 512, 256);

    // Subtle grid lines for LED matrix
    ctx.strokeStyle = '#0f172a';
    ctx.lineWidth = 1;
    for (let x = 0; x < 512; x += 8) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, 256);
      ctx.stroke();
    }
    for (let y = 0; y < 256; y += 8) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(512, y);
      ctx.stroke();
    }

    // Outer neon frame
    ctx.strokeStyle = '#00b4d8';
    ctx.lineWidth = 6;
    ctx.strokeRect(4, 4, 504, 248);

    // Header Title
    ctx.fillStyle = '#38bdf8';
    ctx.font = 'bold 22px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(title, 256, 40);

    // Glowing LED Main Value (e.g., "+0.8 m/s" or "00:09.58")
    ctx.fillStyle = '#facc15'; // Amber/Gold LED glow
    ctx.shadowColor = '#eab308';
    ctx.shadowBlur = 12;
    ctx.font = 'bold 64px monospace';
    ctx.fillText(mainValue, 256, 140);
    ctx.shadowBlur = 0;

    // Status / Subtext
    ctx.fillStyle = '#4ade80'; // Emerald active green
    ctx.font = 'bold 20px sans-serif';
    ctx.fillText(statusText, 256, 215);

    const texture = new THREE.CanvasTexture(canvas);
    return texture;
  }

  /**
   * Generates trackside Olympic perimeter branding banner texture
   */
  static createBrandingBannerTexture(): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = 1024;
    canvas.height = 128;
    const ctx = canvas.getContext('2d')!;

    const grad = ctx.createLinearGradient(0, 0, 1024, 0);
    grad.addColorStop(0, '#03045e');
    grad.addColorStop(0.5, '#0077b6');
    grad.addColorStop(1, '#03045e');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 1024, 128);

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 32px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('1ST PACIFICA REGIONAL OLYMPICS • KLEMONSERRAT STADIUM • MEN\'S 100M SPRINT', 512, 75);

    const texture = new THREE.CanvasTexture(canvas);
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    return texture;
  }

  /**
   * Creates the central field turf texture with Olympic crest pattern
   */
  static createFieldTexture(): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = 1024;
    canvas.height = 1024;
    const ctx = canvas.getContext('2d')!;

    // Dark lush green grass pitch
    ctx.fillStyle = '#1e6629';
    ctx.fillRect(0, 0, 1024, 1024);

    // Lighter lawn stripes
    ctx.fillStyle = '#278034';
    const stripeWidth = 64;
    for (let x = 0; x < 1024; x += stripeWidth * 2) {
      ctx.fillRect(x, 0, stripeWidth, 1024);
    }

    // Central golden ornament circular emblem matching reference
    ctx.save();
    ctx.translate(512, 512);

    // Gold outer ring
    ctx.strokeStyle = '#dfa53b';
    ctx.lineWidth = 12;
    ctx.beginPath();
    ctx.arc(0, 0, 180, 0, Math.PI * 2);
    ctx.stroke();

    // Inner blue crest circle
    ctx.fillStyle = '#0b3954';
    ctx.beginPath();
    ctx.arc(0, 0, 140, 0, Math.PI * 2);
    ctx.fill();

    // Gold filigree swirls
    ctx.strokeStyle = '#f4d068';
    ctx.lineWidth = 6;
    for (let a = 0; a < Math.PI * 2; a += Math.PI / 3) {
      ctx.beginPath();
      ctx.arc(Math.cos(a) * 80, Math.sin(a) * 80, 40, 0, Math.PI * 2);
      ctx.stroke();
    }

    ctx.restore();

    const texture = new THREE.CanvasTexture(canvas);
    return texture;
  }

  /**
   * Creates a high-res LED screen emblem texture (Pacifica Regional Olympics)
   */
  static createEmblemTexture(): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 512;
    const ctx = canvas.getContext('2d')!;

    // Deep cyan gradient background
    const grad = ctx.createRadialGradient(256, 256, 20, 256, 256, 250);
    grad.addColorStop(0, '#00b4d8');
    grad.addColorStop(0.6, '#0077b6');
    grad.addColorStop(1, '#03045e');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 512, 512);

    // Glowing cyan ring
    ctx.strokeStyle = '#90e0ef';
    ctx.lineWidth = 8;
    ctx.beginPath();
    ctx.arc(256, 256, 210, 0, Math.PI * 2);
    ctx.stroke();

    // Shield outline
    ctx.fillStyle = '#ffffff';
    ctx.strokeStyle = '#e0a938';
    ctx.lineWidth = 10;
    ctx.beginPath();
    ctx.moveTo(256, 120);
    ctx.lineTo(330, 170);
    ctx.lineTo(330, 280);
    ctx.lineTo(256, 360);
    ctx.lineTo(182, 280);
    ctx.lineTo(182, 170);
    ctx.closePath();
    ctx.stroke();

    // Text arc
    ctx.fillStyle = '#90e0ef';
    ctx.font = 'bold 22px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('1ST PACIFICA REGIONAL OLYMPICS', 256, 80);
    ctx.fillStyle = '#e0a938';
    ctx.fillText('NEW PLEADLAND', 256, 420);

    const texture = new THREE.CanvasTexture(canvas);
    return texture;
  }

  /**
   * Creates window pattern texture for skyscraper facades
   */
  static createBuildingWindowTexture(): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 512;
    const ctx = canvas.getContext('2d')!;

    ctx.fillStyle = '#1c2430';
    ctx.fillRect(0, 0, 256, 512);

    const cols = 16;
    const rows = 32;
    const w = 256 / cols;
    const h = 512 / rows;

    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        if (Math.random() > 0.35) {
          // Warm sunset reflection / warm office light
          const isWarm = Math.random() > 0.5;
          ctx.fillStyle = isWarm ? '#ffd166' : '#70e000';
          ctx.globalAlpha = 0.4 + Math.random() * 0.5;
          ctx.fillRect(c * w + 2, r * h + 2, w - 4, h - 4);
        }
      }
    }

    const texture = new THREE.CanvasTexture(canvas);
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    return texture;
  }

  /**
   * Creates gradient sunset sky background texture
   */
  static createSunsetSkyTexture(): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = 1024;
    canvas.height = 1024;
    const ctx = canvas.getContext('2d')!;

    // Golden hour dusk gradient
    const grad = ctx.createLinearGradient(0, 1024, 0, 0);
    grad.addColorStop(0.0, '#ff9e00'); // Horizon warm yellow/gold
    grad.addColorStop(0.2, '#ff6000'); // Sunset orange
    grad.addColorStop(0.45, '#c77dff'); // Coral violet
    grad.addColorStop(0.7, '#3a0ca3');  // Deep dusk purple
    grad.addColorStop(1.0, '#03045e');  // Zenith night blue

    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 1024, 1024);

    // Glowing sun disk
    const sunGrad = ctx.createRadialGradient(250, 820, 10, 250, 820, 180);
    sunGrad.addColorStop(0, 'rgba(255, 255, 230, 1)');
    sunGrad.addColorStop(0.3, 'rgba(255, 180, 80, 0.8)');
    sunGrad.addColorStop(1, 'rgba(255, 100, 0, 0)');
    ctx.fillStyle = sunGrad;
    ctx.beginPath();
    ctx.arc(250, 820, 180, 0, Math.PI * 2);
    ctx.fill();

    const texture = new THREE.CanvasTexture(canvas);
    return texture;
  }
}
