import * as THREE from 'three';
import { TextureGenerator } from './textures';
import { AthleteBuilder, SPRINTER_PROFILES } from './Athlete';
import { OfficialBuilder, OfficialData } from './Official';

export class Track100mBuilder {
  public trackGroup: THREE.Group;
  public athletesGroup: THREE.Group;
  public officialsGroup: THREE.Group;
  public startingBlocks: THREE.Group[] = [];

  constructor() {
    this.trackGroup = new THREE.Group();
    this.trackGroup.name = 'Track100mEnvironment';

    this.athletesGroup = new THREE.Group();
    this.athletesGroup.name = 'SprintersGroup';

    this.officialsGroup = new THREE.Group();
    this.officialsGroup.name = 'OfficialsGroup';
  }

  /**
   * Constructs the complete World Athletics 100m Sprint Venue
   * inside Klemonserrat Stadium.
   */
  public build100mVenue(): THREE.Group {
    // Track Geometry Specs
    const numLanes = 8;
    const laneWidth = 3.2; // 3.2m lane width in 3D scale
    const totalTrackWidth = numLanes * laneWidth; // 25.6m
    const straightLength = 160; // 100m race + 15m start run-up + 45m finish run-off
    const startX = -50;  // 100m Start Line X position
    const finishX = 50;  // 100m Finish Line X position (Distance = 100 units)

    // 1. STRAIGHTAWAY TRACK SURFACE
    const trackGeo = new THREE.PlaneGeometry(straightLength, totalTrackWidth, 64, 32);
    const trackTex = TextureGenerator.createSprint100mTrackTexture();
    const trackMat = new THREE.MeshStandardMaterial({
      map: trackTex,
      roughness: 0.65,
      metalness: 0.05
    });

    const trackMesh = new THREE.Mesh(trackGeo, trackMat);
    trackMesh.rotation.x = -Math.PI / 2;
    trackMesh.position.set(0, 0.08, 0); // Positioned right above pitch
    trackMesh.receiveShadow = true;
    this.trackGroup.add(trackMesh);

    // 2. INFIELD & OUTFIELD GRASS / PADDING BORDER
    const paddingGeo = new THREE.PlaneGeometry(straightLength + 20, totalTrackWidth + 12);
    const paddingMat = new THREE.MeshStandardMaterial({
      color: 0x15803d, // Dark athletic turf green
      roughness: 0.8
    });
    const paddingMesh = new THREE.Mesh(paddingGeo, paddingMat);
    paddingMesh.rotation.x = -Math.PI / 2;
    paddingMesh.position.set(0, 0.06, 0);
    this.trackGroup.add(paddingMesh);

    // 3. STARTING BLOCKS (8 Lanes)
    const blockMat = new THREE.MeshStandardMaterial({
      color: 0x334155, // Cast Aluminum frame
      metalness: 0.85,
      roughness: 0.2
    });

    const padMat = new THREE.MeshStandardMaterial({
      color: 0x1e293b, // Rubber pedal pads
      roughness: 0.9
    });

    const sensorMat = new THREE.MeshStandardMaterial({
      color: 0x0284c7, // Blue False-Start Sensor Housing
      metalness: 0.5,
      roughness: 0.3
    });

    for (let lane = 0; lane < numLanes; lane++) {
      const laneZ = (lane - (numLanes - 1) / 2) * laneWidth;
      const blockGroup = new THREE.Group();
      blockGroup.name = `StartingBlock_Lane_${lane + 1}`;

      // Central Spine Rail
      const spineGeo = new THREE.BoxGeometry(1.6, 0.08, 0.16);
      const spine = new THREE.Mesh(spineGeo, blockMat);
      spine.position.set(-0.8, 0.04, 0);
      blockGroup.add(spine);

      // Left & Right Inclined Foot Pedals
      const pedalGeo = new THREE.BoxGeometry(0.35, 0.28, 0.14);
      pedalGeo.rotateZ(Math.PI / 5); // 36-degree inclined block pedal

      const leftPedal = new THREE.Mesh(pedalGeo, padMat);
      leftPedal.position.set(-1.1, 0.15, -0.12);
      blockGroup.add(leftPedal);

      const rightPedal = new THREE.Mesh(pedalGeo, padMat);
      rightPedal.position.set(-0.6, 0.15, 0.12);
      blockGroup.add(rightPedal);

      // False-Start Pressure Sensor Box behind block
      const sensorGeo = new THREE.BoxGeometry(0.22, 0.14, 0.2);
      const sensorBox = new THREE.Mesh(sensorGeo, sensorMat);
      sensorBox.position.set(-1.65, 0.09, 0);
      blockGroup.add(sensorBox);

      // Position block in assigned lane
      blockGroup.position.set(startX - 0.2, 0.08, laneZ);
      this.trackGroup.add(blockGroup);
      this.startingBlocks.push(blockGroup);
    }

    // 4. STARTER PODIUM & PA SOUND SYSTEM
    const podiumMat = new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      roughness: 0.4
    });

    // Starter Podium (Located next to Lane 8 at Start Line)
    const podiumGeo = new THREE.BoxGeometry(2.4, 1.2, 2.4);
    const podium = new THREE.Mesh(podiumGeo, podiumMat);
    podium.position.set(startX - 3, 0.68, (totalTrackWidth / 2) + 3.5);
    podium.castShadow = true;
    this.trackGroup.add(podium);

    // Starter Podium Railing
    const railGeo = new THREE.CylinderGeometry(0.04, 0.04, 1.0);
    const railMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, metalness: 0.9 });
    const rail1 = new THREE.Mesh(railGeo, railMat);
    rail1.position.set(startX - 4, 1.7, (totalTrackWidth / 2) + 2.4);
    this.trackGroup.add(rail1);

    const rail2 = new THREE.Mesh(railGeo, railMat);
    rail2.position.set(startX - 2, 1.7, (totalTrackWidth / 2) + 2.4);
    this.trackGroup.add(rail2);

    // PA Start Speakers behind blocks
    const speakerGeo = new THREE.BoxGeometry(0.3, 0.5, 0.3);
    const speakerMat = new THREE.MeshStandardMaterial({ color: 0x1e293b });

    for (let lane = 0; lane < numLanes; lane++) {
      const laneZ = (lane - (numLanes - 1) / 2) * laneWidth;
      const speaker = new THREE.Mesh(speakerGeo, speakerMat);
      speaker.position.set(startX - 2.8, 0.33, laneZ);
      this.trackGroup.add(speaker);
    }

    // 5. DIGITAL WIND GAUGE (ANEMOMETER) AT 50M MARK
    const windGaugeGroup = new THREE.Group();
    windGaugeGroup.position.set(0, 0.08, -(totalTrackWidth / 2) - 3.2);

    // Wind Sensor Stand
    const standGeo = new THREE.CylinderGeometry(0.08, 0.12, 1.6);
    const standMat = new THREE.MeshStandardMaterial({ color: 0x475569, metalness: 0.8 });
    const stand = new THREE.Mesh(standGeo, standMat);
    stand.position.y = 0.8;
    windGaugeGroup.add(stand);

    // Ultrasonic Sensor Unit
    const sensorUnitGeo = new THREE.CylinderGeometry(0.2, 0.2, 0.3, 12);
    const sensorUnit = new THREE.Mesh(sensorUnitGeo, blockMat);
    sensorUnit.position.y = 1.65;
    windGaugeGroup.add(sensorUnit);

    // Wind Display LED Board
    const displayTex = TextureGenerator.createDigitalDisplayTexture('WIND SPEED', '+0.8 m/s', 'LEGAL ≤ +2.0');
    const displayMat = new THREE.MeshStandardMaterial({ map: displayTex, roughness: 0.2 });
    const displayGeo = new THREE.BoxGeometry(1.8, 0.9, 0.15);
    const displayBox = new THREE.Mesh(displayGeo, displayMat);
    displayBox.position.set(0, 1.2, 0.2);
    windGaugeGroup.add(displayBox);

    this.trackGroup.add(windGaugeGroup);

    // 6. ELECTRONIC PHOTO-FINISH CAMERA TOWERS (FINISH LINE)
    const cameraMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, metalness: 0.8, roughness: 0.2 });
    const lensMat = new THREE.MeshStandardMaterial({ color: 0x38bdf8, metalness: 0.9, roughness: 0.1 });

    const createFinishCameraTower = (zPos: number, isNorth: boolean) => {
      const towerGroup = new THREE.Group();
      towerGroup.position.set(finishX, 0.08, zPos);

      // Vertical Steel Column
      const colGeo = new THREE.CylinderGeometry(0.12, 0.16, 3.8);
      const col = new THREE.Mesh(colGeo, standMat);
      col.position.y = 1.9;
      towerGroup.add(col);

      // Micro-Scan High Speed Photofinish Camera Box
      const camBoxGeo = new THREE.BoxGeometry(0.6, 0.4, 0.4);
      const camBox = new THREE.Mesh(camBoxGeo, cameraMat);
      camBox.position.set(0, 3.6, 0);
      towerGroup.add(camBox);

      // Camera Precision Optical Lens pointed across finish line
      const lensGeo = new THREE.CylinderGeometry(0.12, 0.12, 0.2, 16);
      const lens = new THREE.Mesh(lensGeo, lensMat);
      lens.rotation.z = Math.PI / 2;
      lens.position.set(0, 3.6, isNorth ? 0.25 : -0.25);
      towerGroup.add(lens);

      return towerGroup;
    };

    this.trackGroup.add(createFinishCameraTower((totalTrackWidth / 2) + 2.5, false));
    this.trackGroup.add(createFinishCameraTower(-(totalTrackWidth / 2) - 2.5, true));

    // Finish Line LED Timing Scoreboard
    const finishClockTex = TextureGenerator.createDigitalDisplayTexture('100M OLYMPIC FINAL', '00:09.58', 'WORLD RECORD READY');
    const finishClockMat = new THREE.MeshStandardMaterial({ map: finishClockTex, roughness: 0.2 });
    const finishClockGeo = new THREE.BoxGeometry(3.6, 1.8, 0.25);
    const finishClock = new THREE.Mesh(finishClockGeo, finishClockMat);
    finishClock.position.set(finishX + 8, 1.8, -(totalTrackWidth / 2) - 4.5);
    finishClock.rotation.y = -Math.PI / 6;
    this.trackGroup.add(finishClock);

    // 7. ATHLETE CALL AREA (Behind Start Line)
    const callAreaGroup = new THREE.Group();
    callAreaGroup.position.set(startX - 18, 0.08, 0);

    // Call Room Tent Canopy
    const tentGeo = new THREE.BoxGeometry(8, 3.5, totalTrackWidth + 4);
    const tentMat = new THREE.MeshStandardMaterial({
      color: 0x0284c7, // Pacifica Blue Call Tent
      roughness: 0.4,
      transparent: true,
      opacity: 0.85
    });
    const tent = new THREE.Mesh(tentGeo, tentMat);
    tent.position.y = 1.75;
    callAreaGroup.add(tent);

    // Athlete Baskets for Gear
    const basketGeo = new THREE.BoxGeometry(0.6, 0.4, 0.5);
    const basketMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8 });

    for (let lane = 0; lane < numLanes; lane++) {
      const laneZ = (lane - (numLanes - 1) / 2) * laneWidth;
      const basket = new THREE.Mesh(basketGeo, basketMat);
      basket.position.set(2, 0.2, laneZ);
      callAreaGroup.add(basket);
    }

    this.trackGroup.add(callAreaGroup);

    // 8. TRACKSIDE BRANDING PERIMETER BANNERS
    const bannerTex = TextureGenerator.createBrandingBannerTexture();
    const bannerMat = new THREE.MeshStandardMaterial({ map: bannerTex, roughness: 0.3 });
    const bannerGeo = new THREE.PlaneGeometry(straightLength, 1.2);

    const bannerNorth = new THREE.Mesh(bannerGeo, bannerMat);
    bannerNorth.position.set(0, 0.68, -(totalTrackWidth / 2) - 0.2);
    this.trackGroup.add(bannerNorth);

    const bannerSouth = new THREE.Mesh(bannerGeo, bannerMat);
    bannerSouth.position.set(0, 0.68, (totalTrackWidth / 2) + 0.2);
    bannerSouth.rotation.y = Math.PI;
    this.trackGroup.add(bannerSouth);

    // 9. SPAWN EIGHT MALE SPRINTERS IN LANES 1-8
    SPRINTER_PROFILES.forEach((profile) => {
      const athleteMesh = AthleteBuilder.createAthlete(profile);
      const laneZ = (profile.lane - 1 - (numLanes - 1) / 2) * laneWidth;

      // Position Sprinter directly in front of block, standing on track surface without clipping
      // Track surface Y is at 0.08. Feet contact offset is 0.00.
      athleteMesh.position.set(startX + 0.1, 0.08, laneZ);
      athleteMesh.rotation.y = Math.PI / 2; // Facing towards finish line (+X direction)

      this.athletesGroup.add(athleteMesh);
    });

    this.trackGroup.add(this.athletesGroup);

    // 10. SPAWN PLACEHOLDER OFFICIALS
    const officialsDataList: OfficialData[] = [
      {
        role: 'Starter',
        title: 'Chief Starter',
        position: new THREE.Vector3(startX - 3, 1.28, (totalTrackWidth / 2) + 3.5),
        rotationY: Math.PI / 4
      },
      {
        role: 'AssistantStarter',
        title: 'Assistant Starter',
        position: new THREE.Vector3(startX - 3.5, 0.08, -(totalTrackWidth / 2) - 2),
        rotationY: Math.PI / 3
      },
      {
        role: 'TrackOfficial',
        title: 'Lane Judge 1',
        position: new THREE.Vector3(-10, 0.08, -(totalTrackWidth / 2) - 1.8),
        rotationY: Math.PI / 2
      },
      {
        role: 'TrackOfficial',
        title: 'Lane Judge 2',
        position: new THREE.Vector3(15, 0.08, (totalTrackWidth / 2) + 1.8),
        rotationY: -Math.PI / 2
      },
      {
        role: 'FinishJudge',
        title: 'Chief Finish Judge',
        position: new THREE.Vector3(finishX + 1.5, 0.08, (totalTrackWidth / 2) + 2.8),
        rotationY: -Math.PI / 3
      },
      {
        role: 'Timekeeper',
        title: 'Timing Console Manager',
        position: new THREE.Vector3(finishX + 6, 0.08, -(totalTrackWidth / 2) - 3.2),
        rotationY: -Math.PI / 4
      }
    ];

    officialsDataList.forEach((offData) => {
      const officialMesh = OfficialBuilder.createOfficial(offData);
      this.officialsGroup.add(officialMesh);
    });

    this.trackGroup.add(this.officialsGroup);

    return this.trackGroup;
  }
}
