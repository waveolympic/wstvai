import * as THREE from 'three';
import { TextureGenerator } from './textures';

export class EnvironmentBuilder {
  public cloudGroup!: THREE.Group;

  /**
   * Sets up lighting, shadows, sky dome, and atmospheric environment
   */
  public setupEnvironment(scene: THREE.Scene): void {
    // 1. DIRECTIONAL SUN LIGHT (Golden Hour / Sunset)
    const sunLight = new THREE.DirectionalLight(0xffdfa9, 3.4);
    sunLight.position.set(-350, 220, -380);
    sunLight.castShadow = true;

    // Shadow configuration
    sunLight.shadow.mapSize.width = 2048;
    sunLight.shadow.mapSize.height = 2048;
    sunLight.shadow.camera.near = 10;
    sunLight.shadow.camera.far = 1000;
    const shadowD = 350;
    sunLight.shadow.camera.left = -shadowD;
    sunLight.shadow.camera.right = shadowD;
    sunLight.shadow.camera.top = shadowD;
    sunLight.shadow.camera.bottom = -shadowD;
    sunLight.shadow.bias = -0.0002;

    scene.add(sunLight);

    // 2. HEMISPHERE AMBIENT SKY LIGHT
    const hemiLight = new THREE.HemisphereLight(0x7dd3fc, 0x1e1b4b, 1.4);
    scene.add(hemiLight);

    // Ambient Fill Light
    const ambientLight = new THREE.AmbientLight(0x38bdf8, 0.4);
    scene.add(ambientLight);

    // 3. SKY DOME
    const skyGeo = new THREE.SphereGeometry(1800, 32, 32);
    const skyTex = TextureGenerator.createSunsetSkyTexture();
    const skyMat = new THREE.MeshBasicMaterial({
      map: skyTex,
      side: THREE.BackSide
    });
    const skyMesh = new THREE.Mesh(skyGeo, skyMat);
    scene.add(skyMesh);

    // 4. PROCEDURAL SLOW-MOVING SUNSET CLOUDS
    this.cloudGroup = new THREE.Group();
    const cloudMat = new THREE.MeshStandardMaterial({
      color: 0xfed7aa,
      transparent: true,
      opacity: 0.65,
      roughness: 0.9,
      emissive: 0xea580c,
      emissiveIntensity: 0.15
    });

    const numClouds = 18;
    for (let i = 0; i < numClouds; i++) {
      const cloudPuffGroup = new THREE.Group();
      const numPuffs = 5 + Math.floor(Math.random() * 6);

      for (let p = 0; p < numPuffs; p++) {
        const puffGeo = new THREE.DodecahedronGeometry(25 + Math.random() * 35, 1);
        const puffMesh = new THREE.Mesh(puffGeo, cloudMat);
        puffMesh.position.set(
          (p - numPuffs / 2) * 22,
          (Math.random() - 0.5) * 12,
          (Math.random() - 0.5) * 20
        );
        cloudPuffGroup.add(puffMesh);
      }

      const cx = (Math.random() - 0.5) * 1800;
      const cy = 250 + Math.random() * 200;
      const cz = -300 - Math.random() * 900;

      cloudPuffGroup.position.set(cx, cy, cz);
      this.cloudGroup.add(cloudPuffGroup);
    }

    scene.add(this.cloudGroup);
  }

  /**
   * Slow subtle cloud drift animation
   */
  public update(delta: number): void {
    if (this.cloudGroup) {
      this.cloudGroup.children.forEach(c => {
        c.position.x += delta * 2.5;
        if (c.position.x > 1000) c.position.x = -1000;
      });
    }
  }
}
